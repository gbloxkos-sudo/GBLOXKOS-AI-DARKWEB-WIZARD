"""Regression tests for the hardened archive extraction path.

These lock in the fix for the Zip-Slip / symlink-escape class of bugs:
WIZARD-X downloads archives straight from hostile dark web hosts, so an
extraction routine that trusts member paths is a remote arbitrary-write.
"""

import io
import tarfile
import zipfile

import pytest

from download_manager import DownloadItem, DownloadManager


@pytest.fixture
def manager(tmp_path):
    return DownloadManager(base_download_dir=str(tmp_path / "dl"))


def _item():
    return DownloadItem(url="http://example.invalid/evil", title="evil")


# ── ZIP ──────────────────────────────────────────────────────────────────────

def test_zip_traversal_is_rejected(manager, tmp_path):
    """`../../` members must never be written outside the destination."""
    archive = tmp_path / "evil.zip"
    canary = tmp_path.parent / "PWNED_ZIP"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("../../../../PWNED_ZIP", "owned")
        zf.writestr("safe.txt", "fine")

    item = _item()
    manager._extract_archive(item, archive)

    assert not canary.exists(), "path traversal escaped the extraction directory"
    assert item.metadata["extracted_files"] == ["safe.txt"]
    assert item.metadata["rejected_members"] == 1


def test_zip_absolute_path_is_rejected(manager, tmp_path):
    archive = tmp_path / "abs.zip"
    target = tmp_path / "abs_pwned.txt"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr(f"/{target}", "owned")

    item = _item()
    manager._extract_archive(item, archive)

    # The archive targeted an absolute path outside tmp_path; nothing may land there.
    assert item.metadata["extracted_files"] == []
    assert not (tmp_path.parent / target.name).exists()


def test_zip_legitimate_nested_content_extracts(manager, tmp_path):
    archive = tmp_path / "good.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("sub/dir/hello.txt", "hi")

    item = _item()
    manager._extract_archive(item, archive)

    extracted = tmp_path / "good_extracted" / "sub" / "dir" / "hello.txt"
    assert extracted.read_text() == "hi"
    assert item.metadata["extracted_count"] == 1


# ── TAR ──────────────────────────────────────────────────────────────────────

def test_tar_traversal_is_rejected(manager, tmp_path):
    archive = tmp_path / "evil.tar.gz"
    canary = tmp_path.parent / "PWNED_TAR"
    with tarfile.open(archive, "w:gz") as tf:
        info = tarfile.TarInfo("../../../../PWNED_TAR")
        info.size = 4
        tf.addfile(info, io.BytesIO(b"owned"))

    item = _item()
    manager._extract_archive(item, archive)

    assert not canary.exists()
    assert item.metadata["extracted_files"] == []


def test_tar_symlink_escape_is_rejected(manager, tmp_path):
    """A symlink to /etc/passwd must never be materialised."""
    archive = tmp_path / "link.tar"
    with tarfile.open(archive, "w") as tf:
        link = tarfile.TarInfo("evil_link")
        link.type = tarfile.SYMTYPE
        link.linkname = "/etc/passwd"
        tf.addfile(link)

    item = _item()
    manager._extract_archive(item, archive)

    assert not (tmp_path / "evil.tar_extracted" / "evil_link").exists()
    assert item.metadata["extracted_files"] == []
    assert item.metadata["rejected_members"] == 1


def test_tar_device_node_is_rejected(manager, tmp_path):
    archive = tmp_path / "dev.tar"
    with tarfile.open(archive, "w") as tf:
        dev = tarfile.TarInfo("evil_dev")
        dev.type = tarfile.CHRTYPE
        dev.devmajor, dev.devminor = 1, 3
        tf.addfile(dev)

    item = _item()
    manager._extract_archive(item, archive)

    assert not (tmp_path / "dev_extracted" / "evil_dev").exists()
    assert item.metadata["extracted_files"] == []


def test_tar_regular_file_extracts(manager, tmp_path):
    archive = tmp_path / "ok.tar.gz"
    with tarfile.open(archive, "w:gz") as tf:
        info = tarfile.TarInfo("ok.txt")
        info.size = 3
        tf.addfile(info, io.BytesIO(b"yes"))

    item = _item()
    manager._extract_archive(item, archive)

    # ``Path('ok.tar.gz').stem`` is 'ok.tar'
    assert (tmp_path / "ok.tar_extracted" / "ok.txt").read_text() == "yes"
    assert item.metadata["extracted_count"] == 1


# ── containment helper ───────────────────────────────────────────────────────

def test_is_within_rejects_sibling_prefix(tmp_path):
    """The classic ``startswith`` bug: ``<base>_evil`` shares ``<base>``'s prefix."""
    base = tmp_path / "data_extracted"
    base.mkdir()
    sibling = tmp_path / "data_extracted_evil"
    assert DownloadManager._is_within(base, base / "ok.txt") is True
    assert DownloadManager._is_within(base, sibling / "x.txt") is False
    assert DownloadManager._is_within(base, tmp_path / "elsewhere.txt") is False
