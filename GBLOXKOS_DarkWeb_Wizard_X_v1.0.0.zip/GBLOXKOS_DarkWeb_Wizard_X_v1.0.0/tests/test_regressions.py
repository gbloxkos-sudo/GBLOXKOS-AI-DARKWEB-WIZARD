"""Regression tests for the bug fixes shipped in v1.0.0.

Each test pins a specific defect that was present before the release so it
cannot silently come back.
"""

import inspect
import tempfile
from pathlib import Path

import pytest

import config
import download_manager as dm_mod
import llm
import search

pkg = __import__("__init__")


# ── __init__ shim ────────────────────────────────────────────────────────────

def test_metadata_is_exposed():
    assert pkg.__version__ == "1.0.0"
    assert pkg.__company__ == "GBLOXKOS LLC"
    assert pkg.__developer__ == "GBLOXKOS LLC"
    assert pkg.__license__ == "MIT"


def test_load_rejects_unknown_module():
    with pytest.raises(KeyError):
        pkg.load("definitely_not_a_module")


def test_module_list_is_complete():
    for name in ("config", "session", "llm", "search", "scrape", "agents", "ui"):
        assert name in pkg.MODULES


# ── async_download ───────────────────────────────────────────────────────────

def test_async_download_signature_exposes_progress_callback():
    sig = inspect.signature(dm_mod.async_download)
    assert "progress_callback" in sig.parameters
    doc = dm_mod.async_download.__doc__ or ""
    assert "progress_callback" in doc
    assert "downloaded_bytes" in doc


def test_async_download_reports_failure_without_raising():
    """Connection errors must be reported in the dict, never propagated."""
    import asyncio

    async def run():
        return await dm_mod.async_download(
            "http://127.0.0.1:1/nope",
            Path(tempfile.gettempdir()) / "should-not-exist.bin",
            timeout=1,
        )

    result = asyncio.run(run())
    assert result["success"] is False
    assert "error" in result


def test_async_download_tolerates_bad_content_length():
    """A malformed Content-Length degrades to 'unknown size', it must not raise."""
    assert "except (TypeError, ValueError):" in inspect.getsource(dm_mod.async_download)


# ── suggest_pivots honours its preset ────────────────────────────────────────

def test_suggest_pivots_uses_preset(monkeypatch):
    captured = {}

    class FakeChain:
        def __or__(self, other):
            return self

        def __ror__(self, other):
            return self

    def _fake_template(*_args, **_kwargs):
        return FakeChain()

    def _fake_parser():
        return object()

    def fake_invoke(chain, variables, **kwargs):
        captured["model_name"] = kwargs.get("model_name", "")
        return '["alpha bravo charlie"]'

    monkeypatch.setattr(llm, "_invoke_with_retry", fake_invoke)
    monkeypatch.setattr(llm, "ChatPromptTemplate", _fake_template)
    monkeypatch.setattr(llm, "StrOutputParser", _fake_parser)

    out = llm.suggest_pivots(object(), "q", "data", preset="ransomware_malware")
    assert out == ["alpha bravo charlie"]
    # the preset must reach the circuit-breaker key
    assert "ransomware_malware" in captured["model_name"]


def test_followup_personas_cover_every_preset():
    for key in llm.PRESET_PROMPTS:
        assert key in llm._FOLLOWUP_PERSONAS, f"{key} missing a follow-up persona"


# ── search helpers ───────────────────────────────────────────────────────────

def test_extract_onion_links_drops_query_string():
    html = '<a href="http://abcdefghij234567.onion/path?q=1#frag">Long enough title</a>'
    links = search.extract_onion_links(html)
    assert len(links) == 1
    assert links[0]["link"] == "http://abcdefghij234567.onion/path"


def test_extract_onion_links_takes_no_dead_base_url():
    assert "base_url" not in inspect.signature(search.extract_onion_links).parameters


def test_all_parsers_share_one_signature():
    """Every parser is invoked as ``parser(soup, query)`` - keep them uniform."""
    for name, parser in search.PARSERS.items():
        params = list(inspect.signature(parser).parameters)
        assert params[0] == "soup", f"{name} first arg drifted"
        assert len(params) == 2, f"{name} must accept exactly (soup, query)"


# ── download manager plumbing ────────────────────────────────────────────────

def test_shutdown_imports_close_sessions_from_session():
    """It must not depend on scrape re-exporting session helpers."""
    src = inspect.getsource(dm_mod.DownloadManager.shutdown)
    assert "from session import close_all_sessions" in src
    assert "from scrape import close_all_sessions" not in src


def test_job_id_uses_non_weak_hash():
    """BLAKE2b replaced MD5 for job identifiers."""
    src = inspect.getsource(dm_mod.DownloadManager.create_job)
    assert "md5" not in src
    assert "blake2b" in src


def test_get_filename_fallback_is_non_weak():
    """The disambiguating fallback hash must not be MD5."""
    src = inspect.getsource(dm_mod.DownloadManager._sanitize_filename)
    assert "md5" not in src

    mgr = dm_mod.DownloadManager(base_download_dir=str(Path(tempfile.gettempdir()) / "dl_test"))
    assert mgr._sanitize_filename("///")  # must always produce something usable


# ── config ───────────────────────────────────────────────────────────────────

def test_clean_env_strips_quotes_and_whitespace(monkeypatch):
    monkeypatch.setenv("GBLOXKOS_T", '  "spaced value"  ')
    assert config._clean_env("GBLOXKOS_T") == "spaced value"


def test_clean_env_maps_placeholders_to_empty(monkeypatch):
    """Placeholder values become None, which is_valid_api_key treats as absent."""
    monkeypatch.setenv("GBLOXKOS_U", "your_openai_api_key")
    assert config._clean_env("GBLOXKOS_U") is None
    assert config.is_valid_api_key(config._clean_env("GBLOXKOS_U")) is False


def test_clean_env_missing_var_is_none(monkeypatch):
    monkeypatch.delenv("GBLOXKOS_ABSENT", raising=False)
    assert config._clean_env("GBLOXKOS_ABSENT") is None
