"""Shared pytest fixtures for GBLOXKOS AI DARKWEB WIZARD X."""

import os
import sys
from pathlib import Path

import pytest

APP_ROOT = Path(__file__).resolve().parent.parent

# The application is a flat set of sibling modules, so the repo root has to be
# importable for `import llm`, `import ui`, ... to resolve.
if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))


@pytest.fixture(autouse=True)
def _isolate_env(monkeypatch, tmp_path):
    """Keep every test away from the developer's real credentials."""
    for key in list(os.environ):
        if key.endswith(("_API_KEY", "_BASE_URL")) or key in ("OLLAMA_BASE_URL",):
            monkeypatch.delenv(key, raising=False)
    yield


@pytest.fixture
def tmp_download_root(tmp_path, monkeypatch):
    """Redirect the download manager at a throwaway directory."""
    root = tmp_path / "downloads"
    root.mkdir(parents=True, exist_ok=True)
    import download_manager as dm

    monkeypatch.setattr(dm.download_manager, "base_download_dir", root)
    return root
