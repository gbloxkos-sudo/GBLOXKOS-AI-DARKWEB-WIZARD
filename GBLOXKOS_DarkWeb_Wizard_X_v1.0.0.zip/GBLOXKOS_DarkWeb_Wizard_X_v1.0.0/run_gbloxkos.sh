#!/bin/bash
set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$PROJECT_DIR/.venv"
TOR_PID=""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

cleanup() {
    echo -e "\n${YELLOW}Shutting down...${NC}"
    
    # Kill Tor if we started it
    if [ -n "$TOR_PID" ] && kill -0 "$TOR_PID" 2>/dev/null; then
        echo -e "${BLUE}Stopping Tor (PID: $TOR_PID)...${NC}"
        kill "$TOR_PID" 2>/dev/null
        # Wait for Tor to stop gracefully
        for i in {1..10}; do
            if ! kill -0 "$TOR_PID" 2>/dev/null; then
                break
            fi
            sleep 0.5
        done
        # Force kill if still running
        if kill -0 "$TOR_PID" 2>/dev/null; then
            kill -9 "$TOR_PID" 2>/dev/null
        fi
        echo -e "${GREEN}Tor stopped${NC}"
    fi
    
    echo -e "${GREEN}Goodbye!${NC}"
    exit 0
}

# Trap signals for clean shutdown
trap cleanup SIGINT SIGTERM EXIT

echo -e "${BLUE}=== GBLOXKOS AI DARKWEB WIZARD X ===${NC}"
echo -e "${BLUE}Project directory: $PROJECT_DIR${NC}"

# Check if virtual environment exists
if [ ! -d "$VENV_DIR" ]; then
    echo -e "${RED}Virtual environment not found. Run ./setup.sh first.${NC}"
    exit 1
fi

# Activate virtual environment
source "$VENV_DIR/bin/activate"
cd "$PROJECT_DIR"

# Suppress noisy warnings from libraries
export PYTHONWARNINGS="ignore::DeprecationWarning"
export STREAMLIT_LOG_LEVEL="error"
export LLAMA_CPP_BASE_URL=""  # Disable llama.cpp if not running
export PYTHONPATH="$PROJECT_DIR:$PYTHONPATH"

# Configure logging to suppress urllib3 connection errors
export GRPC_VERBOSITY=ERROR
export GRPC_TRACE=

# Check if Ollama is running
echo -e "${BLUE}Checking Ollama...${NC}"
if ! curl -s http://127.0.0.1:11434/api/tags > /dev/null 2>&1; then
    echo -e "${YELLOW}Ollama not running. Starting Ollama server...${NC}"
    OLLAMA_HOST=0.0.0.0 ollama serve &
    OLLAMA_PID=$!
    sleep 3
    if ! curl -s http://127.0.0.1:11434/api/tags > /dev/null 2>&1; then
        echo -e "${RED}Failed to start Ollama. Please run 'ollama serve' manually.${NC}"
        exit 1
    fi
    echo -e "${GREEN}Ollama started (PID: $OLLAMA_PID)${NC}"
    # Add Ollama PID to cleanup
    trap "kill $OLLAMA_PID 2>/dev/null; cleanup" SIGINT SIGTERM EXIT
else
    echo -e "${GREEN}Ollama is running${NC}"
fi

# Check .env file
if [ ! -f "$PROJECT_DIR/.env" ]; then
    echo -e "${YELLOW}No .env file found. Creating default with Ollama...${NC}"
    cat > "$PROJECT_DIR/.env" << 'EOF'
OLLAMA_BASE_URL=http://127.0.0.1:11434
EOF
fi

# Start Tor (reuse system tor if already listening on 9050 — prevents bind fail)
TOR_PID=""
if python3 -c "import socket; s=socket.socket(); s.settimeout(1); s.connect(('127.0.0.1', 9050)); s.close()" 2>/dev/null; then
    echo -e "${GREEN}Tor already listening on 127.0.0.1:9050 — reusing system tor${NC}"
else
    echo -e "${BLUE}Starting Tor...${NC}"
    tor &
    TOR_PID=$!
fi

# Wait for Tor to be ready (port 9050)
echo -e "${BLUE}Waiting for Tor to be ready on 127.0.0.1:9050...${NC}"
for i in {1..30}; do
    if python3 -c "import socket; s=socket.socket(); s.settimeout(2); s.connect(('127.0.0.1', 9050)); s.close()" 2>/dev/null; then
        echo -e "${GREEN}Tor is ready (PID: $TOR_PID)${NC}"
        break
    fi
    if [ $i -eq 30 ]; then
        echo -e "${RED}ERROR: Tor failed to start or is not listening on port 9050.${NC}"
        kill "$TOR_PID" 2>/dev/null
        exit 1
    fi
    echo -n "."
    sleep 1
done
echo ""

# Verify Tor is working by making a test request
echo -e "${BLUE}Verifying Tor connectivity...${NC}"
if python3 -c "
import requests
session = requests.Session()
session.proxies = {'http': 'socks5h://127.0.0.1:9050', 'https': 'socks5h://127.0.0.1:9050'}
try:
    r = session.get('http://httpbin.org/ip', timeout=15)
    if r.status_code == 200:
        print('Tor IP:', r.json().get('origin', 'unknown'))
    else:
        print('Tor check failed:', r.status_code)
except Exception as e:
    print('Tor check error:', e)
" 2>/dev/null; then
    echo -e "${GREEN}Tor connectivity verified${NC}"
else
    echo -e "${YELLOW}Tor started but verification failed. Continuing anyway...${NC}"
fi

# Check available models
echo -e "${BLUE}Available Ollama models:${NC}"
curl -s http://127.0.0.1:11434/api/tags | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    for m in d.get('models', []):
        print(f'  - {m[\"name\"]}')
except:
    print('  (none)')
"

echo ""
echo -e "${GREEN}Starting GBLOXKOS AI DARKWEB WIZARD X UI...${NC}"
echo -e "${BLUE}Open your browser at: http://localhost:8501${NC}"
echo -e "${YELLOW}Press Ctrl+C to stop the application and Tor${NC}"
echo ""

# Run Streamlit using venv python
"$VENV_DIR/bin/streamlit" run ui.py --server.port=8501 --server.address=0.0.0.0