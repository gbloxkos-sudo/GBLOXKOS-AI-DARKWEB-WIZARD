import logging
import os
from dotenv import load_dotenv

load_dotenv()

# Configure logging
log_level = os.getenv("LOG_LEVEL", "INFO").upper()
logging.basicConfig(
    level=getattr(logging, log_level, logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

def _clean_env(name: str, default: str | None = None) -> str | None:
    """Clean environment variable value."""
    value = os.getenv(name, default)
    if value is None:
        return None
    value = str(value).strip()
    # Support accidentally quoted values copied into .env
    if len(value) >= 2 and (
        (value[0] == value[-1] == '"') or (value[0] == value[-1] == "'")
    ):
        value = value[1:-1].strip()
    # Filter out placeholder values
    if value.lower().startswith("your_") or value.lower() in ("none", "null", ""):
        return None
    return value

def is_valid_api_key(key: str | None) -> bool:
    """Check if API key is valid (not None, not empty, not a placeholder)."""
    if key is None:
        return False
    key = str(key).strip()
    if not key:
        return False
    if key.lower().startswith("your_"):
        return False
    return key.lower() not in ("none", "null", "")

def is_valid_url(url: str | None) -> bool:
    """Check if URL is valid."""
    if url is None:
        return False
    url = str(url).strip()
    if not url:
        return False
    return url.startswith(("http://", "https://"))

# Configuration variables loaded from the .env file
OPENAI_API_KEY = _clean_env("OPENAI_API_KEY")
GOOGLE_API_KEY = _clean_env("GOOGLE_API_KEY")
ANTHROPIC_API_KEY = _clean_env("ANTHROPIC_API_KEY")
OLLAMA_BASE_URL = _clean_env("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
OPENROUTER_BASE_URL = _clean_env("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
OPENROUTER_API_KEY = _clean_env("OPENROUTER_API_KEY")
LLAMA_CPP_BASE_URL = _clean_env("LLAMA_CPP_BASE_URL", "http://127.0.0.1:8080")
CUSTOM_API_BASE_URL = _clean_env("CUSTOM_API_BASE_URL")
CUSTOM_API_KEY = _clean_env("CUSTOM_API_KEY")
CUSTOM_API_MODEL = _clean_env("CUSTOM_API_MODEL")

# Validate configuration on import
def validate_config() -> dict:
    """Validate configuration and return status of each provider."""
    return {
        "openai": is_valid_api_key(OPENAI_API_KEY),
        "anthropic": is_valid_api_key(ANTHROPIC_API_KEY),
        "google": is_valid_api_key(GOOGLE_API_KEY),
        "openrouter": is_valid_api_key(OPENROUTER_API_KEY) and is_valid_url(OPENROUTER_BASE_URL),
        "ollama": is_valid_url(OLLAMA_BASE_URL),
        "llama_cpp": is_valid_url(LLAMA_CPP_BASE_URL),
        "custom": is_valid_url(CUSTOM_API_BASE_URL),
    }

# Export validation functions
__all__ = [
    "OPENAI_API_KEY", "GOOGLE_API_KEY", "ANTHROPIC_API_KEY",
    "OLLAMA_BASE_URL", "OPENROUTER_BASE_URL", "OPENROUTER_API_KEY",
    "LLAMA_CPP_BASE_URL", "CUSTOM_API_BASE_URL", "CUSTOM_API_KEY", "CUSTOM_API_MODEL",
    "is_valid_api_key", "is_valid_url", "validate_config",
]
