"""
Hardening Module - Production-grade security, rate limiting, input validation, and app polish.
"""
import html
import hashlib
import logging
import os
import re
import secrets
import threading
import time
import weakref
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from functools import wraps
from typing import Any, Callable, Dict, List, Tuple

logger = logging.getLogger(__name__)

# Module-level constants
MAX_RATE_LIMIT_ENTRIES = 10000
MAX_SECURITY_EVENTS = 10000
MAX_SESSION_TOKENS = 1000
MAX_CSRF_TOKENS = 1000
CLEANUP_INTERVAL = 3600  # 1 hour
SESSION_TOKEN_TTL = 24 * 3600  # 24 hours
CSRF_TOKEN_TTL = 3600  # 1 hour


# ── Security Events ──────────────────────────────────────────────────────

@dataclass
class SecurityEvent:
    timestamp: str
    event_type: str
    severity: str  # low, medium, high, critical
    source_ip: str
    user_agent: str
    details: Dict[str, Any]
    blocked: bool = False
    request_id: str = ""


@dataclass
class RateLimitBucket:
    tokens: float
    last_refill: float
    max_tokens: int
    refill_rate: float  # tokens per second


# ── Security Hardening ───────────────────────────────────────────────────

class SecurityHardening:
    """Comprehensive security hardening with rate limiting, input validation, and audit logging."""
    
    def __init__(
        self,
        default_rate_limit: int = 100,
        default_window: int = 60,
        max_events: int = MAX_SECURITY_EVENTS,
        enable_csrf: bool = True,
    ):
        self.default_rate_limit = default_rate_limit
        self.default_window = default_window
        self.max_events = max_events
        self.enable_csrf = enable_csrf
        
        self.rate_limits: Dict[str, RateLimitBucket] = defaultdict(
            lambda: RateLimitBucket(
                tokens=float(default_rate_limit),
                last_refill=time.time(),
                max_tokens=default_rate_limit,
                refill_rate=default_rate_limit / default_window,
            )
        )
        self.rate_limit_weakrefs: Dict[str, weakref.ref] = {}
        self.security_events: List[SecurityEvent] = []
        self.blocked_ips: set = set()
        self.suspicious_patterns = [
            (r"(?i)(union|select|insert|update|delete|drop|alter|create)\s+", "sql_injection"),
            (r"(?i)(script|onerror|onload|onclick|javascript:|vbscript:)", "xss"),
            (r"(?i)(etc/passwd|etc/shadow|boot\.ini|win\.ini)", "path_traversal"),
            (r"(?i)(\.\./|\.\.\\)", "path_traversal"),
            (r"(?i)(cmd\.exe|powershell|bash|sh\s+-c)", "command_injection"),
            (r"(?i)(eval\(|exec\(|system\(|shell_exec)", "code_injection"),
            (r"(?i)(<iframe|<object|<embed|<applet)", "html_injection"),
            (r"(?i)(document\.cookie|localStorage|sessionStorage)", "data_exfiltration"),
            (r"(?i)(base64_decode|gzinflate|str_rot13)", "obfuscation"),
        ]
        self.compiled_patterns = [(re.compile(p), t) for p, t in self.suspicious_patterns]
        self._lock = threading.RLock()
        self.session_tokens: Dict[str, Dict] = {}
        self.session_token_weakrefs: Dict[str, weakref.ref] = {}
        self.csrf_tokens: Dict[str, Dict] = {}  # Store token with timestamp
        self.request_counts: Dict[str, List[float]] = defaultdict(list)
        self._last_cleanup = time.time()
    
    def _cleanup_expired_entries(self) -> None:
        """Clean up expired entries to prevent memory growth."""
        now = time.time()
        if now - self._last_cleanup < CLEANUP_INTERVAL:
            return
        
        # Cleanup rate limits
        expired_keys = []
        for key, bucket in self.rate_limits.items():
            if now - bucket.last_refill > self.default_window * 2:
                expired_keys.append(key)
        for key in expired_keys:
            self.rate_limits.pop(key, None)
            self.rate_limit_weakrefs.pop(key, None)
        
        # Limit rate limit entries
        if len(self.rate_limits) > MAX_RATE_LIMIT_ENTRIES:
            # Remove oldest entries
            keys_to_remove = list(self.rate_limits.keys())[:len(self.rate_limits) - MAX_RATE_LIMIT_ENTRIES]
            for key in keys_to_remove:
                self.rate_limits.pop(key, None)
                self.rate_limit_weakrefs.pop(key, None)
        
        # Cleanup session tokens
        expired_sessions = []
        for token, session in self.session_tokens.items():
            try:
                expires = datetime.fromisoformat(session["expires"])
                if datetime.now() > expires:
                    expired_sessions.append(token)
            except Exception:
                expired_sessions.append(token)
        for token in expired_sessions:
            self.session_tokens.pop(token, None)
            self.session_token_weakrefs.pop(token, None)
        
        # Limit session tokens
        if len(self.session_tokens) > MAX_SESSION_TOKENS:
            keys_to_remove = list(self.session_tokens.keys())[:len(self.session_tokens) - MAX_SESSION_TOKENS]
            for key in keys_to_remove:
                self.session_tokens.pop(key, None)
                self.session_token_weakrefs.pop(key, None)
        
        # Cleanup CSRF tokens
        expired_csrf = []
        for session_id, token_data in self.csrf_tokens.items():
            if isinstance(token_data, dict):
                created = token_data.get("created", 0)
                if now - created > CSRF_TOKEN_TTL:
                    expired_csrf.append(session_id)
            else:
                # Old format without timestamp
                expired_csrf.append(session_id)
        for session_id in expired_csrf:
            self.csrf_tokens.pop(session_id, None)
        
        # Limit CSRF tokens
        if len(self.csrf_tokens) > MAX_CSRF_TOKENS:
            keys_to_remove = list(self.csrf_tokens.keys())[:len(self.csrf_tokens) - MAX_CSRF_TOKENS]
            for key in keys_to_remove:
                self.csrf_tokens.pop(key, None)
        
        # Cleanup security events
        if len(self.security_events) > self.max_events:
            self.security_events = self.security_events[-self.max_events:]
        
        # Cleanup request counts
        for identifier, timestamps in self.request_counts.items():
            cutoff = now - self.default_window
            self.request_counts[identifier] = [ts for ts in timestamps if ts > cutoff]
        
        self._last_cleanup = now
    
    # ── Input Sanitization ──────────────────────────────────────────────
    
    def sanitize_input(self, value: Any, max_length: int = 10000, allow_html: bool = False) -> str:
        """Sanitize input to prevent injection attacks."""
        if value is None:
            return ""
        if not isinstance(value, str):
            value = str(value)
        
        # Truncate
        value = value[:max_length]
        
        # Remove control characters
        value = re.sub(r'[\x00-\x08\x0b-\x0c\x0e-\x1f\x7f]', '', value)
        
        if not allow_html:
            # HTML escape
            value = html.escape(value, quote=True)
        
        return value
    
    def sanitize_html(self, value: str) -> str:
        """Sanitize HTML for safe display."""
        return html.escape(value, quote=True)
    
    def sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for filesystem safety."""
        filename = os.path.basename(filename)
        filename = re.sub(r'[^\w\s\-\.]', '', filename)
        filename = filename[:255]
        if not filename:
            filename = f"file_{secrets.token_hex(8)}"
        return filename
    
    def sanitize_search_query(self, query: str) -> str:
        """Sanitize search query for safe use in search engines."""
        query = self.sanitize_input(query, max_length=200)
        # Remove potentially dangerous operators for search engines
        query = re.sub(r'[<>"\'\&\(\)\[\]\{\}]', '', query)
        return query.strip()
    
    # ── Validation ───────────────────────────────────────────────────────
    
    def validate_onion_url(self, url: str) -> Tuple[bool, str]:
        """Validate .onion URL format."""
        if not url:
            return False, "Empty URL"
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            if parsed.scheme not in ("http", "https"):
                return False, f"Invalid scheme: {parsed.scheme}"
            hostname = parsed.hostname or ""
            if not re.match(r'^[a-z2-7]{16,56}\.onion$', hostname, re.IGNORECASE):
                return False, "Invalid .onion hostname"
            return True, ""
        except Exception as e:
            return False, f"URL parse error: {e}"
    
    def validate_file_path(self, path: str, base_dir: str) -> bool:
        """Prevent path traversal attacks."""
        try:
            real_path = os.path.realpath(path)
            real_base = os.path.realpath(base_dir)
            return real_path.startswith(real_base)
        except Exception:
            return False
    
    def validate_search_query(self, query: str, max_length: int = 200) -> Tuple[bool, str]:
        """Validate and sanitize search query."""
        if not query:
            return False, "Empty query"
        
        query = self.sanitize_search_query(query)
        
        if len(query) < 2:
            return False, "Query too short"
        if len(query) > max_length:
            return False, f"Query too long (max {max_length} chars)"
        
        # Check for suspicious patterns
        for pattern, threat_type in self.compiled_patterns:
            if pattern.search(query):
                self._log_security_event(
                    "injection_attempt", "high",
                    {"query": query[:100], "threat_type": threat_type}
                )
                return False, f"Potentially malicious query detected ({threat_type})"
        
        return True, query
    
    # ── Rate Limiting ────────────────────────────────────────────────────
    
    def check_rate_limit(
        self,
        identifier: str,
        max_requests: int | None = None,
        window_seconds: int | None = None,
    ) -> bool:
        """Token bucket rate limiting with thread safety."""
        max_requests = max_requests or self.default_rate_limit
        window_seconds = window_seconds or self.default_window
        refill_rate = max_requests / window_seconds
        
        with self._lock:
            self._cleanup_expired_entries()
            bucket = self.rate_limits[identifier]
            now = time.time()
            elapsed = now - bucket.last_refill
            
            # Refill tokens
            bucket.tokens = min(bucket.max_tokens, bucket.tokens + elapsed * refill_rate)
            bucket.last_refill = now
            bucket.max_tokens = max_requests
            bucket.refill_rate = refill_rate
            
            if bucket.tokens >= 1:
                bucket.tokens -= 1
                return True
            return False
    
    def get_rate_limit_status(self, identifier: str) -> Dict[str, Any]:
        """Get current rate limit status for an identifier."""
        with self._lock:
            bucket = self.rate_limits.get(identifier)
            if not bucket:
                return {"remaining": self.default_rate_limit, "reset_in": 0}
            return {
                "remaining": int(bucket.tokens),
                "max": bucket.max_tokens,
                "reset_in": max(0, (bucket.max_tokens - bucket.tokens) / bucket.refill_rate) if bucket.refill_rate > 0 else 0,
            }
    
    # ── Session Management ──────────────────────────────────────────────
    
    def create_session_token(
        self,
        user_id: str,
        permissions: List[str] | None = None,
        ttl_hours: int = 24,
    ) -> str:
        """Create a secure session token."""
        token = secrets.token_urlsafe(48)
        with self._lock:
            self._cleanup_expired_entries()
            self.session_tokens[token] = {
                "user_id": user_id,
                "created": datetime.now().isoformat(),
                "expires": (datetime.now() + timedelta(hours=ttl_hours)).isoformat(),
                "permissions": permissions or ["read"],
                "last_activity": datetime.now().isoformat(),
            }
            self.session_token_weakrefs[token] = weakref.ref(self.session_tokens[token])
        return token
    
    def validate_session_token(
        self,
        token: str,
        required_permission: str | None = None,
    ) -> Dict | None:
        """Validate session token and check permissions."""
        with self._lock:
            session = self.session_tokens.get(token)
            if not session:
                return None
            
            # Check expiration
            try:
                expires = datetime.fromisoformat(session["expires"])
                if datetime.now() > expires:
                    del self.session_tokens[token]
                    self.session_token_weakrefs.pop(token, None)
                    return None
            except Exception:
                pass
            
            # Check permission
            if required_permission and required_permission not in session.get("permissions", []):
                return None
            
            # Update last activity
            session["last_activity"] = datetime.now().isoformat()
            return session
    
    def revoke_session_token(self, token: str) -> bool:
        """Revoke a session token."""
        with self._lock:
            if token in self.session_tokens:
                del self.session_tokens[token]
                self.session_token_weakrefs.pop(token, None)
                return True
            return False
    
    def cleanup_expired_sessions(self) -> int:
        """Remove expired session tokens."""
        with self._lock:
            now = datetime.now()
            expired = [
                token for token, session in self.session_tokens.items()
                if datetime.fromisoformat(session["expires"]) < now
            ]
            for token in expired:
                del self.session_tokens[token]
                self.session_token_weakrefs.pop(token, None)
            return len(expired)
    
    # ── CSRF Protection ─────────────────────────────────────────────────
    
    def generate_csrf_token(self, session_id: str) -> str:
        """Generate CSRF token for session."""
        token = secrets.token_urlsafe(32)
        with self._lock:
            self._cleanup_expired_entries()
            self.csrf_tokens[session_id] = {
                "token": token,
                "created": time.time(),
            }
        return token
    
    def validate_csrf_token(self, session_id: str, token: str) -> bool:
        """Validate CSRF token."""
        with self._lock:
            token_data = self.csrf_tokens.get(session_id)
            if not token_data:
                return False
            # Handle both old format (string) and new format (dict)
            if isinstance(token_data, str):
                return token_data == token
            return token_data.get("token") == token
    
    # ── Security Event Logging ──────────────────────────────────────────
    
    def _log_security_event(
        self,
        event_type: str,
        severity: str,
        details: Dict,
        source_ip: str = "unknown",
        user_agent: str = "unknown",
        blocked: bool = False,
    ) -> None:
        event = SecurityEvent(
            timestamp=datetime.now().isoformat(),
            event_type=event_type,
            severity=severity,
            source_ip=source_ip,
            user_agent=user_agent,
            details=details,
            blocked=blocked,
            request_id=secrets.token_hex(8),
        )
        with self._lock:
            self._cleanup_expired_entries()
            self.security_events.append(event)
            if len(self.security_events) > self.max_events:
                self.security_events = self.security_events[-self.max_events:]
    
    def log_request(
        self,
        event_type: str,
        severity: str,
        details: Dict,
        source_ip: str = "unknown",
        user_agent: str = "unknown",
    ) -> None:
        """Public method to log security events."""
        self._log_security_event(event_type, severity, details, source_ip, user_agent)
    
    def get_security_dashboard(self) -> Dict:
        """Get security dashboard data."""
        with self._lock:
            now = datetime.now()
            recent = [
                e for e in self.security_events
                if datetime.fromisoformat(e.timestamp) > now - timedelta(hours=24)
            ]
            
            by_type = defaultdict(int)
            by_severity = defaultdict(int)
            for e in recent:
                by_type[e.event_type] += 1
                by_severity[e.severity] += 1
            
            return {
                "total_events_24h": len(recent),
                "by_type": dict(by_type),
                "by_severity": dict(by_severity),
                "blocked_ips": list(self.blocked_ips),
                "active_sessions": len(self.session_tokens),
                "rate_limited_identifiers": len(self.rate_limits),
                "recent_events": [
                    {
                        "timestamp": e.timestamp,
                        "type": e.event_type,
                        "severity": e.severity,
                        "details": e.details,
                        "blocked": e.blocked,
                        "request_id": e.request_id,
                    }
                    for e in recent[-50:]
                ],
            }
    
    # ── Integrity ────────────────────────────────────────────────────────
    
    def hash_content(self, content: bytes) -> str:
        """Generate SHA-256 hash of content."""
        return hashlib.sha256(content).hexdigest()
    
    def verify_checksum(self, content: bytes, expected: str) -> bool:
        """Verify content checksum."""
        return self.hash_content(content) == expected
    
    def generate_nonce(self, length: int = 16) -> str:
        """Generate cryptographically secure nonce."""
        return secrets.token_urlsafe(length)


# ── App Polish ──────────────────────────────────────────────────────────

class AppPolish:
    """UI/UX polish utilities for professional presentation."""
    
    def __init__(self):
        self.ui_state: Dict[str, Any] = {}
        self.performance_metrics: Dict[str, List[float]] = defaultdict(list)
        self.error_counts: Dict[str, int] = defaultdict(int)
        self.feature_flags: Dict[str, bool] = {
            "dark_mode": True,
            "animations": True,
            "tooltips": True,
            "keyboard_shortcuts": True,
            "auto_save": True,
            "real_time_updates": True,
            "compact_mode": False,
            "high_contrast": False,
        }
        self._max_metrics_per_name = 1000
        self._max_metric_names = 100
        self._max_error_types = 100
    
    def record_metric(self, name: str, value: float) -> None:
        self.performance_metrics[name].append(value)
        if len(self.performance_metrics[name]) > self._max_metrics_per_name:
            self.performance_metrics[name] = self.performance_metrics[name][-self._max_metrics_per_name:]
        # Limit total metric names
        if len(self.performance_metrics) > self._max_metric_names:
            oldest_keys = list(self.performance_metrics.keys())[:-self._max_metric_names]
            for k in oldest_keys:
                self.performance_metrics.pop(k, None)
    
    def record_error(self, error_type: str) -> None:
        self.error_counts[error_type] += 1
        # Limit error types
        if len(self.error_counts) > self._max_error_types:
            oldest_keys = list(self.error_counts.keys())[:-self._max_error_types]
            for k in oldest_keys:
                self.error_counts.pop(k, None)
    
    def get_performance_summary(self) -> Dict:
        summary = {}
        for name, values in self.performance_metrics.items():
            if values:
                sorted_vals = sorted(values)
                summary[name] = {
                    "count": len(values),
                    "avg": sum(values) / len(values),
                    "min": min(values),
                    "max": max(values),
                    "p50": sorted_vals[len(sorted_vals) // 2],
                    "p95": sorted_vals[int(len(sorted_vals) * 0.95)] if len(values) > 20 else max(values),
                    "p99": sorted_vals[int(len(sorted_vals) * 0.99)] if len(values) > 100 else max(values),
                }
        return summary
    
    def get_error_summary(self) -> Dict:
        return dict(self.error_counts)
    
    def clear_metrics(self) -> None:
        """Clear all performance metrics and error counts."""
        self.performance_metrics.clear()
        self.error_counts.clear()
    
    def toggle_feature(self, feature: str, enabled: bool | None = None) -> bool:
        if feature in self.feature_flags:
            if enabled is None:
                self.feature_flags[feature] = not self.feature_flags[feature]
            else:
                self.feature_flags[feature] = enabled
        return self.feature_flags.get(feature, False)
    
    def format_bytes(self, bytes_val: int) -> str:
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_val < 1024:
                return f"{bytes_val:.1f} {unit}"
            bytes_val /= 1024
        return f"{bytes_val:.1f} PB"
    
    def format_duration(self, seconds: float) -> str:
        if seconds < 1:
            return f"{seconds*1000:.0f}ms"
        if seconds < 60:
            return f"{seconds:.1f}s"
        if seconds < 3600:
            return f"{seconds/60:.1f}m"
        return f"{seconds/3600:.1f}h"
    
    def truncate_text(self, text: str, max_length: int = 100, suffix: str = "...") -> str:
        if len(text) <= max_length:
            return text
        return text[:max_length - len(suffix)] + suffix
    
    def generate_ui_id(self, prefix: str = "el") -> str:
        return f"{prefix}_{secrets.token_hex(6)}"
    
    def pluralize(self, count: int, singular: str, plural: str | None = None) -> str:
        if count == 1:
            return f"1 {singular}"
        return f"{count} {plural or singular + 's'}"
    
    def format_number(self, num: int) -> str:
        if num >= 1_000_000:
            return f"{num/1_000_000:.1f}M"
        if num >= 1_000:
            return f"{num/1_000:.1f}K"
        return str(num)


# ── Decorators ──────────────────────────────────────────────────────────

def security_middleware(func: Callable) -> Callable:
    """Decorator to add security middleware to functions."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        try:
            result = func(*args, **kwargs)
            polish.record_metric(f"{func.__name__}_duration", time.time() - start)
            return result
        except Exception as e:
            polish.record_error(type(e).__name__)
            logger.error(f"Error in {func.__name__}: {e}")
            raise
    return wrapper


def require_rate_limit(max_requests: int = 30, window: int = 60):
    """Decorator to enforce rate limiting."""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            identifier = kwargs.get("session_id") or kwargs.get("user_id") or "anonymous"
            if not security.check_rate_limit(identifier, max_requests, window):
                raise Exception(f"Rate limit exceeded: {max_requests} requests per {window}s")
            return func(*args, **kwargs)
        return wrapper
    return decorator


def validate_inputs(**validators):
    """Decorator to validate function inputs."""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            for param, validator in validators.items():
                if param in kwargs:
                    valid, result = validator(kwargs[param])
                    if not valid:
                        raise ValueError(f"Invalid {param}: {result}")
                    kwargs[param] = result
            return func(*args, **kwargs)
        return wrapper
    return decorator


# ── Global Instances ────────────────────────────────────────────────────

security = SecurityHardening()
polish = AppPolish()