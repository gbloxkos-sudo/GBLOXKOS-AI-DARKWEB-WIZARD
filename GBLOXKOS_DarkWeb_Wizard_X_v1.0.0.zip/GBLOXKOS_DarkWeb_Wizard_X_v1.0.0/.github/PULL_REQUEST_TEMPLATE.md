## Summary

<!-- What does this PR change, and why? Link the issue: Fixes #123 -->

## Type of change

- [ ] Bug fix (non-breaking)
- [ ] New feature (non-breaking)
- [ ] Breaking change
- [ ] Documentation
- [ ] Refactor / internal cleanup
- [ ] Build, CI or packaging

## Scope confirmation

Wizard X is a defensive OSINT tool. This change:

- [ ] Adds no capability for malware, credential theft, mass targeting, or evasion of lawful detection
- [ ] Handles untrusted input (dark web HTML, archives, LLM output) safely
- [ ] Logs no secrets, keys, cookies, or raw investigation payloads

## Quality gate

All three must pass locally before requesting review:

```bash
ruff check .     # All checks passed!
pytest -q        # all tests green
make check       # both of the above
```

- [ ] `ruff check .` is clean
- [ ] `pytest -q` passes
- [ ] Added or updated tests covering this change
- [ ] `README.md` updated if behaviour or configuration changed
- [ ] `CHANGELOG.md` updated

## Testing notes

<!-- How did you verify this? Which provider, which engines, what did you observe? -->

## Screenshots

<!-- For UI changes only. Redact any real investigation data. -->

## Checklist

- [ ] The diff is focused on one concern
- [ ] Public functions have docstrings covering args/returns/raises
- [ ] New imports are placed correctly (flat siblings, absolute names — no relative imports)
- [ ] No `print()` outside CLI entrypoints
- [ ] I read [`CONTRIBUTING.md`](../CONTRIBUTING.md)
