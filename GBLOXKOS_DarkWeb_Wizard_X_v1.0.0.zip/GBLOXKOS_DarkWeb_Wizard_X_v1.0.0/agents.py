"""
Agents Module - Production-grade multi-agent OSINT orchestration with circuit breakers,
async support, structured outputs, and self-healing capabilities.
"""
import json
import logging
import re
import threading
import time
import uuid
import weakref
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeoutError
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Set

from llm import get_llm
from llm_utils import CircuitBreaker, CircuitBreakerOpenError
from search import get_search_results
from scrape import scrape_multiple, extract_iocs
from download_manager import download_manager

logger = logging.getLogger(__name__)

# Module-level constants
MAX_AGENT_MEMORY_PATTERNS = 200
MAX_AGENT_MEMORY_LESSONS = 100
MAX_GLOBAL_MEMORY_PATTERNS = 500
MAX_GLOBAL_MEMORY_LESSONS = 200
ORCHESTRATOR_MAX_LOOP_ITERATIONS = 50
ORCHESTRATOR_TASK_TIMEOUT_BUFFER = 30
DEFAULT_TASK_TIMEOUT = 300.0


# ── Enums ────────────────────────────────────────────────────────────────

class AgentType(Enum):
    RECONNAISSANCE = "reconnaissance"
    THREAT_ACTOR_PROFILER = "threat_actor_profiler"
    MALWARE_ANALYST = "malware_analyst"
    CRYPTO_TRACER = "crypto_tracer"
    INFRASTRUCTURE_MAPPER = "infrastructure_mapper"
    DATA_BROKER_HUNTER = "data_broker_hunter"
    OPSEC_AUDITOR = "opsec_auditor"
    ORCHESTRATOR = "orchestrator"


class AgentStatus(Enum):
    IDLE = "idle"
    PLANNING = "planning"
    EXECUTING = "executing"
    ANALYZING = "analyzing"
    COMPLETED = "completed"
    FAILED = "failed"
    LEARNING = "learning"


# ── Data Classes ─────────────────────────────────────────────────────────

@dataclass
class AgentMemory:
    short_term: Dict[str, Any] = field(default_factory=dict)
    long_term: Dict[str, Any] = field(default_factory=dict)
    patterns: List[Dict] = field(default_factory=list)
    lessons_learned: List[str] = field(default_factory=list)
    successful_queries: List[str] = field(default_factory=list)
    failed_queries: List[str] = field(default_factory=list)
    discovered_artifacts: Dict[str, List] = field(default_factory=dict)
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    _max_short_term: int = 1000
    _max_long_term: int = 500
    
    def prune(self, max_patterns: int = MAX_AGENT_MEMORY_PATTERNS, max_lessons: int = MAX_AGENT_MEMORY_LESSONS) -> None:
        """Prune memory to prevent unbounded growth."""
        if len(self.patterns) > max_patterns:
            self.patterns = self.patterns[-max_patterns:]
        if len(self.lessons_learned) > max_lessons:
            self.lessons_learned = self.lessons_learned[-max_lessons:]
        if len(self.successful_queries) > 100:
            self.successful_queries = self.successful_queries[-100:]
        if len(self.failed_queries) > 100:
            self.failed_queries = self.failed_queries[-100:]
        if len(self.short_term) > self._max_short_term:
            keys_to_remove = list(self.short_term.keys())[:-self._max_short_term]
            for k in keys_to_remove:
                self.short_term.pop(k, None)
        if len(self.long_term) > self._max_long_term:
            keys_to_remove = list(self.long_term.keys())[:-self._max_long_term]
            for k in keys_to_remove:
                self.long_term.pop(k, None)
        for art_type, artifacts in self.discovered_artifacts.items():
            if isinstance(artifacts, list) and len(artifacts) > 500:
                self.discovered_artifacts[art_type] = artifacts[-500:]
        self.updated_at = datetime.now().isoformat()
    
    def clear_expired(self, max_age_hours: int = 24) -> None:
        """Clear entries older than max_age_hours."""
        cutoff = datetime.now().timestamp() - (max_age_hours * 3600)
        for store in (self.short_term, self.long_term):
            expired_keys = [
                k for k, v in store.items()
                if isinstance(v, dict) and v.get("timestamp", 0) < cutoff
            ]
            for k in expired_keys:
                store.pop(k, None)


@dataclass
class AgentTask:
    id: str
    agent_type: AgentType
    objective: str
    parameters: Dict[str, Any]
    status: AgentStatus = AgentStatus.IDLE
    result: Any = None
    error: str = ""
    started_at: str | None = None
    completed_at: str | None = None
    iterations: int = 0
    max_iterations: int = 3
    dependencies: List[str] = field(default_factory=list)
    priority: int = 5
    timeout_seconds: float = DEFAULT_TASK_TIMEOUT
    latency_ms: int = 0
    
    def __post_init__(self):
        if self.timeout_seconds <= 0:
            self.timeout_seconds = DEFAULT_TASK_TIMEOUT
        if self.timeout_seconds > 1800:
            self.timeout_seconds = 1800
        if self.max_iterations < 0:
            self.max_iterations = 0
        if self.max_iterations > 10:
            self.max_iterations = 10
        if not self.id:
            self.id = str(uuid.uuid4())
        if self.priority < 1:
            self.priority = 1
        elif self.priority > 10:
            self.priority = 10

# Valid fields for AgentTask construction from LLM output
_VALID_TASK_FIELDS = {"id", "objective", "parameters", "status", "result", "error",
                       "started_at", "completed_at", "iterations", "max_iterations",
                       "dependencies", "priority", "timeout_seconds", "latency_ms"}


@dataclass
class InvestigationPlan:
    id: str
    objective: str
    tasks: List[AgentTask]
    status: str = "pending"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    results: Dict[str, Any] = field(default_factory=dict)
    execution_strategy: str = "adaptive"
    success_criteria: str = ""
    
    def __post_init__(self):
        valid_strategies = {"parallel", "sequential", "adaptive"}
        if self.execution_strategy not in valid_strategies:
            self.execution_strategy = "adaptive"
        if not self.id:
            self.id = str(uuid.uuid4())
        if not self.tasks:
            self.tasks = []


# ── Circuit Breakers for Agents ────────────────────────────────────────

_agent_circuit_breakers: Dict[str, CircuitBreaker] = {}
_circuit_lock = threading.RLock()
_agent_breaker_weakrefs: Dict[str, weakref.ref] = {}

def _get_agent_breaker(agent_type: str) -> CircuitBreaker:
    with _circuit_lock:
        # Clean up dead weakrefs
        dead_keys = [k for k, ref in _agent_breaker_weakrefs.items() if ref() is None]
        for k in dead_keys:
            _agent_breaker_weakrefs.pop(k, None)
            _agent_circuit_breakers.pop(k, None)
        
        if agent_type not in _agent_circuit_breakers:
            _agent_circuit_breakers[agent_type] = CircuitBreaker(
                failure_threshold=3,
                recovery_timeout=60.0,
                half_open_max_calls=2,
            )
            _agent_breaker_weakrefs[agent_type] = weakref.ref(_agent_circuit_breakers[agent_type])
        return _agent_circuit_breakers[agent_type]

def clear_agent_circuit_breakers() -> None:
    """Clear all agent circuit breakers (for testing/reset)."""
    with _circuit_lock:
        _agent_circuit_breakers.clear()
        _agent_breaker_weakrefs.clear()


# ── Base Agent ──────────────────────────────────────────────────────────

class BaseAgent(ABC):
    """Base class for all specialized agents with production-grade features."""
    
    def __init__(self, agent_type: AgentType, model: str | None = None):
        self.agent_type = agent_type
        self.model = model or self._get_default_model()
        self.llm = self._create_llm()
        self.memory = AgentMemory()
        self.status = AgentStatus.IDLE
        self.current_task: AgentTask | None = None
        self._lock = threading.RLock()
        self.learning_enabled = True
        self.self_healing_enabled = True
        self.metrics = {
            "tasks_completed": 0,
            "tasks_failed": 0,
            "artifacts_discovered": 0,
            "queries_executed": 0,
            "downloads_initiated": 0,
            "total_latency_ms": 0,
        }
        self._breaker = _get_agent_breaker(agent_type.value)
        self._llm_cache: Dict[str, Any] = {}
        self._llm_cache_lock = threading.Lock()
    
    def _get_default_model(self) -> str:
        from llm_utils import get_model_choices
        choices = get_model_choices()
        return choices[0] if choices else "gpt4o"
    
    def _create_llm(self):
        try:
            return get_llm(self.model)
        except Exception as e:
            logger.warning(f"Failed to load model '{self.model}': {e}. Trying fallback.")
            from llm_utils import get_model_choices
            for choice in get_model_choices():
                try:
                    llm = get_llm(choice)
                    self.model = choice
                    return llm
                except Exception:
                    continue
            raise ValueError("No available LLM models. Configure API keys or Ollama.") from None
    
    @abstractmethod
    def get_system_prompt(self) -> str:
        pass
    
    @abstractmethod
    def plan_execution(self, objective: str, context: Dict) -> List[AgentTask]:
        pass
    
    @abstractmethod
    def execute_task(self, task: AgentTask, context: Dict) -> Any:
        pass
    
    @abstractmethod
    def analyze_results(self, task: AgentTask, results: Any) -> Dict:
        pass
    
    def _invoke_llm(self, prompt: str, timeout: float = 75.0) -> str:
        """Invoke LLM with circuit breaker, system prompt, and timeout."""
        system_prompt = self.get_system_prompt()
        
        def _invoke():
            from langchain_core.messages import SystemMessage, HumanMessage
            messages = [SystemMessage(content=system_prompt), HumanMessage(content=prompt)]
            response = self.llm.invoke(messages)
            return response.content if hasattr(response, 'content') else str(response)
        
        try:
            return self._breaker.call(self.agent_type.value, _invoke, timeout=timeout)
        except CircuitBreakerOpenError:
            logger.warning(f"Circuit breaker open for {self.agent_type.value}")
            raise
        except TimeoutError:
            logger.error(f"LLM invocation timed out after {timeout}s for {self.agent_type.value}")
            raise
        except Exception as e:
            logger.error(f"LLM invocation failed for {self.agent_type.value}: {e}")
            raise
    
    def _invoke_llm_json(self, prompt: str, timeout: float = 60.0) -> Dict:
        """Invoke LLM and parse JSON response with robust extraction."""
        raw = self._invoke_llm(prompt, timeout)
        try:
            text = raw.strip()
            text = re.sub(r"^```(?:markdown|json|)?\n?", "", text)
            text = re.sub(r"\n?```$", "", text)
            text = text.strip()
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                pass
            # Try to extract JSON object or array from surrounding text
            for pattern in [r"\{.*\}", r"\[.*\]"]:
                match = re.search(pattern, text, re.DOTALL)
                if match:
                    try:
                        return json.loads(match.group(0))
                    except json.JSONDecodeError:
                        continue
            raise json.JSONDecodeError("No valid JSON found", raw, 0)
        except json.JSONDecodeError as e:
            logger.warning(f"JSON parse failed for {self.agent_type.value}: {e}. Raw: {raw[:200]}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error in _invoke_llm_json for {self.agent_type.value}: {e}")
            raise
    
    def learn_from_execution(self, task: AgentTask, result: Any, success: bool) -> None:
        if not self.learning_enabled:
            return
        
        with self._lock:
            self.memory.updated_at = datetime.now().isoformat()
            self.memory.prune()
            
            if success:
                self.metrics["tasks_completed"] += 1
                self.metrics["total_latency_ms"] += getattr(task, 'latency_ms', 0)
                self.memory.successful_queries.append(task.objective)
                if isinstance(result, dict) and result.get('artifacts'):
                    artifacts = result['artifacts']
                    if isinstance(artifacts, dict):
                        for art_type, artifacts_list in artifacts.items():
                            if isinstance(artifacts_list, list):
                                self.metrics["artifacts_discovered"] += len(artifacts_list)
                                if art_type not in self.memory.discovered_artifacts:
                                    self.memory.discovered_artifacts[art_type] = []
                                self.memory.discovered_artifacts[art_type].extend(artifacts_list)
            else:
                self.metrics["tasks_failed"] += 1
                self.memory.failed_queries.append(task.objective)
                if self.self_healing_enabled and task.iterations < task.max_iterations:
                    self._self_heal(task, result)
            
            self._extract_patterns(task, result, success)
    
    def _self_heal(self, task: AgentTask, result: Any) -> None:
        """Attempt to self-heal from failure."""
        error_analysis = f"Task failed: {task.objective}. Error: {task.error}. Result: {str(result)[:500]}"
        healing_prompt = f"""You are a self-healing AI agent. Analyze this failure and provide a corrected approach.
        
FAILURE: {error_analysis}
AGENT TYPE: {self.agent_type.value}
CURRENT MEMORY PATTERNS: {json.dumps(self.memory.patterns[-5:], default=str)}
        
Provide a JSON response with:
1. "root_cause": brief explanation
2. "corrected_approach": specific actionable steps
3. "parameter_adjustments": dict of parameters to change
4. "should_retry": boolean"""
        
        try:
            healing = self._invoke_llm_json(healing_prompt)
            self.memory.lessons_learned.append(healing.get("root_cause", "Unknown"))
            if healing.get("should_retry") and task.iterations < task.max_iterations:
                task.status = AgentStatus.PLANNING
                logger.info(f"Agent {self.agent_type.value} self-healing: retrying task {task.id} (iteration {task.iterations + 1}/{task.max_iterations})")
        except CircuitBreakerOpenError:
            logger.warning(f"Self-healing circuit breaker open for {self.agent_type.value}")
        except Exception as e:
            logger.warning(f"Self-healing failed for {self.agent_type.value}: {e}")
    
    def _extract_patterns(self, task: AgentTask, result: Any, success: bool) -> None:
        try:
            pattern = {
                "timestamp": datetime.now().isoformat(),
                "objective": task.objective,
                "agent_type": self.agent_type.value,
                "success": success,
                "parameters": task.parameters,
                "result_keys": list(result.keys()) if isinstance(result, dict) else [],
            }
            self.memory.patterns.append(pattern)
            if len(self.memory.patterns) > MAX_AGENT_MEMORY_PATTERNS:
                self.memory.patterns = self.memory.patterns[-MAX_AGENT_MEMORY_PATTERNS:]
        except Exception as e:
            logger.debug(f"Pattern extraction failed for {self.agent_type.value}: {e}")
    
    def get_self_awareness_report(self) -> Dict:
        total = self.metrics["tasks_completed"] + self.metrics["tasks_failed"]
        return {
            "agent_type": self.agent_type.value,
            "status": self.status.value,
            "model": self.model,
            "metrics": self.metrics.copy(),
            "memory_size": {
                "short_term": len(self.memory.short_term),
                "long_term": len(self.memory.long_term),
                "patterns": len(self.memory.patterns),
                "lessons": len(self.memory.lessons_learned),
            },
            "recent_patterns": self.memory.patterns[-10:],
            "top_lessons": self.memory.lessons_learned[-10:],
            "success_rate": self.metrics["tasks_completed"] / max(1, total),
            "avg_latency_ms": self.metrics["total_latency_ms"] / max(1, self.metrics["tasks_completed"]),
        }
    
    def reset_memory(self) -> None:
        """Reset agent memory and metrics."""
        with self._lock:
            self.memory = AgentMemory()
            self.metrics = {
                "tasks_completed": 0,
                "tasks_failed": 0,
                "artifacts_discovered": 0,
                "queries_executed": 0,
                "downloads_initiated": 0,
                "total_latency_ms": 0,
            }
            self.status = AgentStatus.IDLE
            self.current_task = None


# ── Specialized Agents ──────────────────────────────────────────────────

class ReconnaissanceAgent(BaseAgent):
    def __init__(self, model: str | None = None):
        super().__init__(AgentType.RECONNAISSANCE, model)
    
    def get_system_prompt(self) -> str:
        return """You are the RECONNAISSANCE AGENT - elite dark web reconnaissance specialist.
Expertise: initial target discovery, surface mapping, attack surface enumeration, 
identifying entry points, mapping onion service ecosystems, discovering hidden services.

CORE CAPABILITIES:
- Multi-engine dark web search (Ahmia, OnionLand, Tor66, Excavator, etc.)
- Onion service discovery and enumeration
- Technology fingerprinting from afar
- Hidden service directory traversal
- Link analysis and relationship mapping

OUTPUT FORMAT: Always return valid JSON with keys: queries, priorities, rationale, expected_artifacts"""
    
    def plan_execution(self, objective: str, context: Dict) -> List[AgentTask]:
        planning_prompt = f"""You are the Reconnaissance Agent. Create an execution plan.

OBJECTIVE: {objective}
CONTEXT: {json.dumps(context, default=str)[:3000]}
MY MEMORY (successful queries): {self.memory.successful_queries[-10:]}
MY MEMORY (lessons): {self.memory.lessons_learned[-5:]}

Generate a JSON array of tasks. Each task: {{"id": "uuid", "objective": "specific goal", "parameters": {{"queries": ["q1","q2"], "engines": ["all"], "max_results": 50, "depth": 2}}, "agent_type": "reconnaissance", "dependencies": []}}

Return ONLY the JSON array."""
        
        try:
            tasks_data = self._invoke_llm_json(planning_prompt)
            if not isinstance(tasks_data, list):
                tasks_data = [tasks_data] if isinstance(tasks_data, dict) else []
            validated_tasks = []
            for t in tasks_data:
                if isinstance(t, dict):
                    # Filter to only valid AgentTask fields
                    filtered = {k: v for k, v in t.items() if k in _VALID_TASK_FIELDS}
                    filtered.pop("agent_type", None)
                    filtered.pop("status", None)
                    filtered.pop("result", None)
                    filtered.pop("error", None)
                    filtered.pop("started_at", None)
                    filtered.pop("completed_at", None)
                    filtered.pop("iterations", None)
                    filtered.pop("latency_ms", None)
                    filtered.setdefault("id", str(uuid.uuid4()))
                    filtered.setdefault("objective", objective)
                    filtered.setdefault("parameters", {"queries": [objective], "max_results": 50})
                    validated_tasks.append(AgentTask(**filtered, agent_type=AgentType.RECONNAISSANCE))
            return validated_tasks if validated_tasks else [AgentTask(
                id=str(uuid.uuid4()),
                agent_type=AgentType.RECONNAISSANCE,
                objective=objective,
                parameters={"queries": [objective], "engines": ["all"], "max_results": 50, "depth": 2}
            )]
        except Exception as e:
            logger.error(f"Recon planning failed: {e}")
            return [AgentTask(
                id=str(uuid.uuid4()),
                agent_type=AgentType.RECONNAISSANCE,
                objective=objective,
                parameters={"queries": [objective], "engines": ["all"], "max_results": 50, "depth": 2}
            )]
    
    def execute_task(self, task: AgentTask, context: Dict) -> Any:
        self.status = AgentStatus.EXECUTING
        start = time.time()
        self.metrics["queries_executed"] += 1
        
        all_results = []
        queries = task.parameters.get("queries", [task.objective])
        if not isinstance(queries, list):
            queries = [str(queries)]
        max_results = task.parameters.get("max_results", 50)
        
        for query in queries:
            try:
                results = get_search_results(query.replace(" ", "+"), max_workers=8)
                all_results.extend(results[:max_results])
                self.memory.short_term[f"query_{query}"] = len(results)
            except Exception as e:
                logger.error(f"Search failed for {query}: {e}")
        
        # Deduplicate
        unique = {}
        for r in all_results:
            link = r.get("link", "").rstrip('/').lower()
            if link not in unique:
                unique[link] = r
        
        filtered = list(unique.values())[:max_results]
        
        if filtered:
            scraped = scrape_multiple(filtered, max_workers=8)
            for url, content in scraped.items():
                iocs = extract_iocs(content)
                for r in filtered:
                    if r.get("link") == url:
                        r["scraped_content"] = content[:8000]
                        r["iocs"] = iocs
                        break
        
        task.latency_ms = int((time.time() - start) * 1000)
        return {
            "results": filtered,
            "count": len(filtered),
            "queries_used": queries,
            "artifacts": self._extract_artifacts(filtered),
        }
    
    def _extract_artifacts(self, results: List[Dict]) -> Dict[str, List]:
        artifacts = {"onions": [], "emails": [], "btc_addresses": [], "xmr_addresses": [], "ips": []}
        for r in results:
            content = r.get("scraped_content", "") or r.get("title", "")
            iocs = r.get("iocs", extract_iocs(content))
            for k, v in iocs.items():
                if k in artifacts and v:
                    artifacts[k].extend(v)
        for k in artifacts:
            artifacts[k] = list(set(artifacts[k]))
        return artifacts
    
    def analyze_results(self, task: AgentTask, results: Any) -> Dict:
        analysis_prompt = f"""Analyze reconnaissance results for intelligence value.

TASK: {task.objective}
RESULTS COUNT: {results.get('count', 0)}
ARTIFACTS: {json.dumps(results.get('artifacts', {}), default=str)[:2000]}
TOP RESULTS: {json.dumps([{"title": r.get("title"), "link": r.get("link"), "iocs": r.get("iocs")} for r in results.get('results', [])[:10]], default=str)}

Return JSON: {{"key_findings": [], "pivot_queries": [], "high_value_targets": [], "confidence": 0.0, "next_agent_recommendations": []}}"""
        
        try:
            return self._invoke_llm_json(analysis_prompt)
        except Exception as e:
            logger.error(f"Recon analysis failed: {e}")
            return {"key_findings": [], "pivot_queries": [], "high_value_targets": [], "confidence": 0.5, "next_agent_recommendations": []}


class ThreatActorProfilerAgent(BaseAgent):
    def __init__(self, model: str | None = None):
        super().__init__(AgentType.THREAT_ACTOR_PROFILER, model)
    
    def get_system_prompt(self) -> str:
        return """You are the THREAT ACTOR PROFILER AGENT - expert in cybercrime attribution, 
threat actor profiling, alias mapping, infrastructure correlation, TTP analysis, 
and actor lifecycle tracking across dark web forums, markets, and Telegram.

CORE CAPABILITIES:
- Handle/alias correlation across platforms
- TTP fingerprinting and MITRE ATT&CK mapping
- Infrastructure pivoting (C2, hosting, domains)
- Affiliate/program relationship mapping
- OpSec failure analysis and doxxing leads
- Cross-forum activity correlation

OUTPUT: JSON with profile, aliases, TTPs, infrastructure, affiliates, confidence"""
    
    def plan_execution(self, objective: str, context: Dict) -> List[AgentTask]:
        artifacts = context.get("artifacts", {})
        onions = artifacts.get("onions", [])
        emails = artifacts.get("emails", [])
        handles = context.get("handles", [])
        
        queries = []
        for onion in onions[:5]:
            queries.append(f"{onion} threat actor admin")
        for email in emails[:5]:
            queries.append(f'"{email}" darknet forum')
        for handle in handles[:5]:
            queries.append(f'"{handle}" ransomware affiliate')
        
        if not queries:
            queries = [objective]
        
        return [AgentTask(
            id=str(uuid.uuid4()),
            agent_type=AgentType.THREAT_ACTOR_PROFILER,
            objective=objective,
            parameters={"queries": queries[:10], "max_results": 30, "correlate": True}
        )]
    
    def execute_task(self, task: AgentTask, context: Dict) -> Any:
        self.status = AgentStatus.EXECUTING
        start = time.time()
        self.metrics["queries_executed"] += 1
        
        all_results = []
        for query in task.parameters.get("queries", []):
            try:
                results = get_search_results(query.replace(" ", "+"), max_workers=6)
                all_results.extend(results[:task.parameters.get("max_results", 30)])
            except Exception as e:
                logger.error(f"Threat actor search failed: {e}")
        
        if all_results:
            scraped = scrape_multiple(all_results[:15], max_workers=6)
            for url, content in scraped.items():
                for r in all_results:
                    if r.get("link") == url:
                        r["scraped_content"] = content[:10000]
                        r["iocs"] = extract_iocs(content)
                        break
        
        task.latency_ms = int((time.time() - start) * 1000)
        return {
            "results": all_results,
            "profiles": self._build_profiles(all_results),
            "artifacts": self._extract_artifacts(all_results),
        }
    
    def _build_profiles(self, results: List[Dict]) -> List[Dict]:
        profiles = []
        handle_mentions = {}
        
        for r in results:
            content = r.get("scraped_content", "") or r.get("title", "")
            handles = re.findall(r'@[\w\-]+|u/[\w\-]+|[\w\-]{3,20}(?:_admin|_owner|_dev|_support)', content)
            for h in handles:
                if h not in handle_mentions:
                    handle_mentions[h] = {"count": 0, "sources": [], "context": []}
                handle_mentions[h]["count"] += 1
                handle_mentions[h]["sources"].append(r.get("link", ""))
                handle_mentions[h]["context"].append(content[:200])
        
        for handle, data in handle_mentions.items():
            if data["count"] >= 2:
                profiles.append({
                    "handle": handle,
                    "mention_count": data["count"],
                    "sources": list(set(data["sources"]))[:5],
                    "context_snippets": data["context"][:3],
                })
        
        return profiles[:20]
    
    def _extract_artifacts(self, results: List[Dict]) -> Dict[str, List]:
        return {"handles": [p["handle"] for p in self._build_profiles(results)]}
    
    def analyze_results(self, task: AgentTask, results: Any) -> Dict:
        profiles = results.get("profiles", [])
        analysis_prompt = f"""Analyze threat actor profiles from reconnaissance data.

OBJECTIVE: {task.objective}
PROFILES FOUND: {len(profiles)}
TOP PROFILES: {json.dumps(profiles[:10], default=str)}

Return JSON: {{"actor_profiles": [], "ttp_mapping": {{}}, "infrastructure_links": [], "affiliate_network": [], "attribution_confidence": 0.0, "pivot_queries": []}}"""
        
        try:
            return self._invoke_llm_json(analysis_prompt)
        except Exception as e:
            logger.error(f"Threat actor analysis failed: {e}")
            return {"actor_profiles": profiles, "ttp_mapping": {}, "infrastructure_links": [], "affiliate_network": [], "attribution_confidence": 0.3, "pivot_queries": []}


class MalwareAnalystAgent(BaseAgent):
    def __init__(self, model: str | None = None):
        super().__init__(AgentType.MALWARE_ANALYST, model)
    
    def get_system_prompt(self) -> str:
        return """You are the MALWARE ANALYST AGENT - expert in malware reverse engineering, 
static/dynamic analysis, C2 protocol analysis, YARA rule creation, 
malware family classification, and exploit kit tracking.

CORE CAPABILITIES:
- Malware sample acquisition and triage
- Static analysis: strings, imports, entropy, packing detection
- C2 infrastructure extraction and protocol analysis
- YARA/Sigma rule generation for detection
- Malware family attribution and variant tracking
- Exploit kit and loader chain analysis
- Sandbox evasion technique identification

OUTPUT: JSON with malware_families, iocs, yara_rules, c2_infrastructure, detection_rules"""
    
    def plan_execution(self, objective: str, context: Dict) -> List[AgentTask]:
        artifacts = context.get("artifacts", {})
        onions = artifacts.get("onions", [])
        ips = artifacts.get("ips", [])
        
        queries = [objective]
        for onion in onions[:3]:
            queries.append(f"{onion} malware c2 panel")
        for ip in ips[:3]:
            queries.append(f"{ip} malware payload")
        queries.extend(["stealer logs panel", "rat c2 onion", "loader payload download"])
        
        return [AgentTask(
            id=str(uuid.uuid4()),
            agent_type=AgentType.MALWARE_ANALYST,
            objective=objective,
            parameters={"queries": queries[:8], "max_results": 25, "download_samples": True}
        )]
    
    def execute_task(self, task: AgentTask, context: Dict) -> Any:
        self.status = AgentStatus.EXECUTING
        start = time.time()
        self.metrics["queries_executed"] += 1
        
        all_results = []
        for query in task.parameters.get("queries", []):
            try:
                results = get_search_results(query.replace(" ", "+"), max_workers=5)
                all_results.extend(results[:task.parameters.get("max_results", 25)])
            except Exception as e:
                logger.error(f"Malware search failed: {e}")
        
        downloaded_samples = []
        if task.parameters.get("download_samples"):
            download_urls = [r for r in all_results if self._is_downloadable(r)]
            if download_urls:
                job_id = download_manager.create_job(
                    f"malware_samples_{task.id[:8]}",
                    download_urls,
                    {"category": "malware_analysis", "auto_extract": True}
                )
                download_manager.start_job(job_id)
                self.metrics["downloads_initiated"] += 1
                downloaded_samples.append(job_id)
        
        if all_results:
            scraped = scrape_multiple(all_results[:15], max_workers=5)
            for url, content in scraped.items():
                for r in all_results:
                    if r.get("link") == url:
                        r["scraped_content"] = content[:15000]
                        r["iocs"] = extract_iocs(content)
                        break
        
        task.latency_ms = int((time.time() - start) * 1000)
        return {
            "results": all_results,
            "malware_indicators": self._extract_malware_indicators(all_results),
            "download_jobs": downloaded_samples,
            "artifacts": self._extract_artifacts(all_results),
        }
    
    def _is_downloadable(self, result: Dict) -> bool:
        title = result.get("title", "").lower()
        link = result.get("link", "").lower()
        keywords = [".exe", ".dll", ".apk", ".zip", ".rar", ".tar", "payload", "sample", "build", "panel", "stealer", "rat", "loader"]
        return any(kw in title or kw in link for kw in keywords)
    
    def _extract_malware_indicators(self, results: List[Dict]) -> Dict:
        indicators = {
            "file_hashes": [], "c2_domains": [], "c2_ips": [],
            "mutexes": [], "registry_keys": [], "yara_strings": [],
            "mitre_ttps": [], "families": [],
        }
        
        import re
        for r in results:
            content = r.get("scraped_content", "") or r.get("title", "")
            indicators["file_hashes"].extend(re.findall(r'\b[a-fA-F0-9]{32,64}\b', content))
            indicators["c2_domains"].extend(re.findall(r'\b[a-z0-9\-\.]+\.[a-z]{2,}\b', content))
            indicators["mutexes"].extend(re.findall(r'(?:mutex|mutant)[:=]\s*[\w\-]+', content, re.I))
            
            families = ["redline", "raccoon", "vidar", "lumma", "stealc", "metastealer", "risepro", "amadey", 
                       "lockbit", "alphv", "blackcat", "play", "akira", "ransomhub", "basta", "bianlian"]
            for fam in families:
                if fam in content.lower():
                    indicators["families"].append(fam)
        
        for k in indicators:
            indicators[k] = list(set(indicators[k]))[:50]
        
        return indicators
    
    def _extract_artifacts(self, results: List[Dict]) -> Dict[str, List]:
        return self._extract_malware_indicators(results)
    
    def analyze_results(self, task: AgentTask, results: Any) -> Dict:
        indicators = results.get("malware_indicators", {})
        analysis_prompt = f"""Analyze malware indicators for threat intelligence.

OBJECTIVE: {task.objective}
INDICATORS: {json.dumps(indicators, default=str)[:3000]}
DOWNLOAD JOBS: {results.get('download_jobs', [])}

Return JSON: {{"malware_families": [], "c2_infrastructure": [], "yara_rules": [], "sigma_rules": [], "attribution": "", "confidence": 0.0, "pivot_queries": []}}"""
        
        try:
            return self._invoke_llm_json(analysis_prompt)
        except Exception as e:
            logger.error(f"Malware analysis failed: {e}")
            return {"malware_families": indicators.get("families", []), "c2_infrastructure": [], "yara_rules": [], "sigma_rules": [], "attribution": "Unknown", "confidence": 0.3, "pivot_queries": []}


class CryptoTracerAgent(BaseAgent):
    def __init__(self, model: str | None = None):
        super().__init__(AgentType.CRYPTO_TRACER, model)
    
    def get_system_prompt(self) -> str:
        return """You are the CRYPTO TRACER AGENT - expert in blockchain forensics, 
cryptocurrency tracing, mixer/tumbler analysis, chain-hopping detection, 
exchange deposit address clustering, and darknet market wallet attribution.

CORE CAPABILITIES:
- BTC/XMR/ETH address clustering and attribution
- Mixer/tumbler flow analysis (Tornado, Sinbad, Wasabi, etc.)
- Chain-hopping and cross-chain swap tracing
- Exchange KYC deposit address identification
- Darknet market wallet clustering
- Ransomware payment tracking
- DeFi protocol interaction analysis

OUTPUT: JSON with address_clusters, flow_analysis, mixer_usage, exchange_deposits, attribution"""
    
    def plan_execution(self, objective: str, context: Dict) -> List[AgentTask]:
        artifacts = context.get("artifacts", {})
        btc = artifacts.get("btc_addresses", artifacts.get("btc", []))
        xmr = artifacts.get("xmr_addresses", artifacts.get("xmr", []))
        eth = artifacts.get("eth_addresses", artifacts.get("eth", []))
        
        queries = [objective]
        for addr in (btc + xmr + eth)[:10]:
            queries.append(f'"{addr}" darknet market')
            queries.append(f'"{addr}" ransomware payment')
        
        return [AgentTask(
            id=str(uuid.uuid4()),
            agent_type=AgentType.CRYPTO_TRACER,
            objective=objective,
            parameters={"queries": queries[:10], "max_results": 20, "trace_depth": 3}
        )]
    
    def execute_task(self, task: AgentTask, context: Dict) -> Any:
        self.status = AgentStatus.EXECUTING
        start = time.time()
        self.metrics["queries_executed"] += 1
        
        all_results = []
        for query in task.parameters.get("queries", []):
            try:
                results = get_search_results(query.replace(" ", "+"), max_workers=4)
                all_results.extend(results[:task.parameters.get("max_results", 20)])
            except Exception as e:
                logger.error(f"Crypto search failed: {e}")
        
        if all_results:
            scraped = scrape_multiple(all_results[:10], max_workers=4)
            for url, content in scraped.items():
                for r in all_results:
                    if r.get("link") == url:
                        r["scraped_content"] = content[:10000]
                        r["iocs"] = extract_iocs(content)
                        break
        
        task.latency_ms = int((time.time() - start) * 1000)
        return {
            "results": all_results,
            "address_clusters": self._cluster_addresses(all_results),
            "flow_indicators": self._detect_flow_patterns(all_results),
            "artifacts": {"crypto_addresses": self._extract_all_addresses(all_results)},
        }
    
    def _extract_all_addresses(self, results: List[Dict]) -> List[str]:
        from scrape import extract_iocs as _extract_iocs
        addresses = []
        for r in results:
            content = r.get("scraped_content", "") or r.get("title", "")
            iocs = r.get("iocs", _extract_iocs(content))
            addresses.extend(iocs.get("btc_addresses", []))
            addresses.extend(iocs.get("xmr_addresses", []))
            addresses.extend(iocs.get("eth_addresses", []))
        return list(set(addresses))
    
    def _cluster_addresses(self, results: List[Dict]) -> List[Dict]:
        clusters = {}
        for r in results:
            content = r.get("scraped_content", "") or r.get("title", "")
            iocs = r.get("iocs", extract_iocs(content))
            all_addrs = iocs.get("btc_addresses", []) + iocs.get("eth_addresses", [])
            for addr in all_addrs:
                if addr not in clusters:
                    clusters[addr] = {"address": addr, "sources": [], "co_occurring": set()}
                clusters[addr]["sources"].append(r.get("link", ""))
                for other in all_addrs:
                    if other != addr:
                        clusters[addr]["co_occurring"].add(other)
        
        for c in clusters.values():
            c["co_occurring"] = list(c["co_occurring"])
        
        return list(clusters.values())[:20]
    
    def _detect_flow_patterns(self, results: List[Dict]) -> List[str]:
        patterns = []
        mixer_keywords = ["tornado", "sinbad", "wasabi", "samourai", "joinmarket", "mixer", "tumbler", "launder"]
        exchange_keywords = ["binance", "coinbase", "kraken", "kucoin", "bybit", "okx", "huobi", "gate.io", "mexc"]
        
        for r in results:
            content = (r.get("scraped_content", "") or r.get("title", "")).lower()
            for kw in mixer_keywords:
                if kw in content:
                    patterns.append(f"Mixer detected: {kw} in {r.get('link', '')}")
            for kw in exchange_keywords:
                if kw in content:
                    patterns.append(f"Exchange reference: {kw} in {r.get('link', '')}")
        
        return list(set(patterns))
    
    def _extract_artifacts(self, results: List[Dict]) -> Dict[str, List]:
        return {"crypto_addresses": self._extract_all_addresses(results)}
    
    def analyze_results(self, task: AgentTask, results: Any) -> Dict:
        analysis_prompt = f"""Analyze cryptocurrency tracing results.

OBJECTIVE: {task.objective}
ADDRESS CLUSTERS: {len(results.get('address_clusters', []))}
FLOW PATTERNS: {results.get('flow_indicators', [])[:10]}
ADDRESSES: {results.get('artifacts', {}).get('crypto_addresses', [])[:20]}

Return JSON: {{"attribution": {{}}, "mixer_usage": [], "exchange_deposits": [], "chain_hops": [], "ransomware_payments": [], "confidence": 0.0, "pivot_queries": []}}"""
        
        try:
            return self._invoke_llm_json(analysis_prompt)
        except Exception as e:
            logger.error(f"Crypto analysis failed: {e}")
            return {"attribution": {}, "mixer_usage": [], "exchange_deposits": [], "chain_hops": [], "ransomware_payments": [], "confidence": 0.3, "pivot_queries": []}


class InfrastructureMapperAgent(BaseAgent):
    def __init__(self, model: str | None = None):
        super().__init__(AgentType.INFRASTRUCTURE_MAPPER, model)
    
    def get_system_prompt(self) -> str:
        return """You are the INFRASTRUCTURE MAPPER AGENT - expert in mapping adversary infrastructure, 
hosting provider analysis, domain/IP correlation, SSL certificate tracking, 
CDN/WAF fingerprinting, server-side technology profiling, and attack infrastructure lifecycles.

CORE CAPABILITIES:
- Onion service hosting correlation
- IP/domain historical resolution
- SSL certificate transparency analysis
- CDN/WAF bypass and fingerprinting
- Server header and technology profiling
- Infrastructure sharing and pivot points
- Bulletproof hosting identification
- Fast-flux and domain flux detection

OUTPUT: JSON with infrastructure_map, hosting_providers, ssl_certs, cdns, pivots, shared_infrastructure"""
    
    def plan_execution(self, objective: str, context: Dict) -> List[AgentTask]:
        artifacts = context.get("artifacts", {})
        onions = artifacts.get("onions", [])
        ips = artifacts.get("ips", [])
        
        queries = [objective]
        for onion in onions[:5]:
            queries.append(f"{onion} hosting server")
            queries.append(f"{onion} ssl certificate")
        for ip in ips[:5]:
            queries.append(f"{ip} hosting provider")
        
        return [AgentTask(
            id=str(uuid.uuid4()),
            agent_type=AgentType.INFRASTRUCTURE_MAPPER,
            objective=objective,
            parameters={"queries": queries[:12], "max_results": 25, "deep_scan": True}
        )]
    
    def execute_task(self, task: AgentTask, context: Dict) -> Any:
        self.status = AgentStatus.EXECUTING
        start = time.time()
        self.metrics["queries_executed"] += 1
        
        all_results = []
        for query in task.parameters.get("queries", []):
            try:
                results = get_search_results(query.replace(" ", "+"), max_workers=5)
                all_results.extend(results[:task.parameters.get("max_results", 25)])
            except Exception as e:
                logger.error(f"Infrastructure search failed: {e}")
        
        if all_results:
            scraped = scrape_multiple(all_results[:15], max_workers=5)
            for url, content in scraped.items():
                for r in all_results:
                    if r.get("link") == url:
                        r["scraped_content"] = content[:10000]
                        r["metadata"] = r.get("metadata", {})
                        break
        
        task.latency_ms = int((time.time() - start) * 1000)
        return {
            "results": all_results,
            "infrastructure_map": self._map_infrastructure(all_results),
            "hosting_analysis": self._analyze_hosting(all_results),
            "artifacts": {"infrastructure": self._extract_infrastructure_artifacts(all_results)},
        }
    
    def _map_infrastructure(self, results: List[Dict]) -> Dict:
        infra = {"onions": [], "ips": [], "domains": [], "hosting": [], "ssl": [], "tech_stack": []}
        
        for r in results:
            content = r.get("scraped_content", "") or r.get("title", "")
            metadata = r.get("metadata", {})
            
            onions = re.findall(r'[a-z2-7]{16,56}\.onion', content, re.I)
            infra["onions"].extend(onions)
            
            ips = re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', content)
            infra["ips"].extend(ips)
            
            domains = re.findall(r'\b[a-z0-9\-\.]+\.[a-z]{2,}\b', content)
            infra["domains"].extend([d for d in domains if not d.endswith('.onion')])
            
            if metadata.get("generator"):
                infra["tech_stack"].append(metadata["generator"])
            if metadata.get("scripts"):
                for s in metadata["scripts"][:5]:
                    infra["tech_stack"].append(s)
        
        for k in infra:
            infra[k] = list(set(infra[k]))[:50]
        
        return infra
    
    def _analyze_hosting(self, results: List[Dict]) -> List[Dict]:
        hosting = []
        hosting_keywords = ["hosting", "vps", "dedicated", "server", "datacenter", "cloud", "aws", "azure", "digitalocean", "linode", "vultr", "hetzner", "ovh", "contabo"]
        
        for r in results:
            content = (r.get("scraped_content", "") or r.get("title", "")).lower()
            for kw in hosting_keywords:
                if kw in content:
                    hosting.append({"keyword": kw, "source": r.get("link", ""), "context": content[:300]})
                    break
        
        return hosting[:20]
    
    def _extract_infrastructure_artifacts(self, results: List[Dict]) -> Dict[str, List]:
        infra = self._map_infrastructure(results)
        return {
            "onions": infra["onions"],
            "ips": infra["ips"],
            "domains": infra["domains"],
        }
    
    def analyze_results(self, task: AgentTask, results: Any) -> Dict:
        infra_map = results.get("infrastructure_map", {})
        analysis_prompt = f"""Analyze infrastructure mapping results.

OBJECTIVE: {task.objective}
INFRASTRUCTURE: {json.dumps(infra_map, default=str)[:3000]}
HOSTING: {json.dumps(results.get('hosting_analysis', []), default=str)[:1000]}

Return JSON: {{"infrastructure_clusters": [], "bulletproof_hosting": [], "shared_infrastructure": [], "pivot_points": [], "attribution_hints": [], "confidence": 0.0, "pivot_queries": []}}"""
        
        try:
            return self._invoke_llm_json(analysis_prompt)
        except Exception as e:
            logger.error(f"Infrastructure analysis failed: {e}")
            return {"infrastructure_clusters": [], "bulletproof_hosting": [], "shared_infrastructure": [], "pivot_points": [], "attribution_hints": [], "confidence": 0.3, "pivot_queries": []}


class DataBrokerHunterAgent(BaseAgent):
    def __init__(self, model: str | None = None):
        super().__init__(AgentType.DATA_BROKER_HUNTER, model)
    
    def get_system_prompt(self) -> str:
        return """You are the DATA BROKER HUNTER AGENT - expert in tracking data brokers, 
breach compilation markets, credential stuffing ecosystems, PII marketplaces, 
and personal/corporate data supply chains on the dark web.

CORE CAPABILITIES:
- Breach compilation identification and attribution
- Data broker marketplace enumeration (Genesis, Russian Market, 2easy, etc.)
- Credential log/source correlation
- PII freshness and completeness assessment
- Supply chain mapping: breach -> broker -> buyer
- Auction site and private sale monitoring
- Data type classification and valuation

OUTPUT: JSON with brokers, breaches, data_types, supply_chain, pricing, freshness"""
    
    def plan_execution(self, objective: str, context: Dict) -> List[AgentTask]:
        artifacts = context.get("artifacts", {})
        emails = artifacts.get("emails", [])
        
        queries = [objective]
        queries.extend(["breach compilation database", "credential logs shop", "fullz shop onion", 
                       "pii marketplace", "genesis market alternative", "russian market logs",
                       "2easy shop", "spycloud breach", "breachforums database"])
        for email in emails[:5]:
            queries.append(f'"{email.split("@")[0]}" breach')
        
        return [AgentTask(
            id=str(uuid.uuid4()),
            agent_type=AgentType.DATA_BROKER_HUNTER,
            objective=objective,
            parameters={"queries": queries[:12], "max_results": 30, "track_pricing": True}
        )]
    
    def execute_task(self, task: AgentTask, context: Dict) -> Any:
        self.status = AgentStatus.EXECUTING
        start = time.time()
        self.metrics["queries_executed"] += 1
        
        all_results = []
        for query in task.parameters.get("queries", []):
            try:
                results = get_search_results(query.replace(" ", "+"), max_workers=6)
                all_results.extend(results[:task.parameters.get("max_results", 30)])
            except Exception as e:
                logger.error(f"Data broker search failed: {e}")
        
        if all_results:
            scraped = scrape_multiple(all_results[:20], max_workers=6)
            for url, content in scraped.items():
                for r in all_results:
                    if r.get("link") == url:
                        r["scraped_content"] = content[:12000]
                        r["iocs"] = extract_iocs(content)
                        break
        
        task.latency_ms = int((time.time() - start) * 1000)
        return {
            "results": all_results,
            "brokers": self._identify_brokers(all_results),
            "breaches": self._identify_breaches(all_results),
            "data_types": self._classify_data_types(all_results),
            "artifacts": {"pii": self._extract_pii_artifacts(all_results)},
        }
    
    def _identify_brokers(self, results: List[Dict]) -> List[Dict]:
        brokers = []
        broker_keywords = ["genesis", "russian market", "2easy", "spycloud", "breachforums", "breached", "leakbase", "leak-lab", "dataleak", "logshop", "credshop"]
        
        for r in results:
            content = (r.get("scraped_content", "") or r.get("title", "")).lower()
            title = r.get("title", "").lower()
            for kw in broker_keywords:
                if kw in content or kw in title:
                    brokers.append({
                        "name": kw.title(),
                        "source": r.get("link", ""),
                        "title": r.get("title", ""),
                        "context": content[:500],
                    })
                    break
        
        seen = set()
        unique = []
        for b in brokers:
            key = (b["name"], b["source"])
            if key not in seen:
                seen.add(key)
                unique.append(b)
        
        return unique[:15]
    
    def _identify_breaches(self, results: List[Dict]) -> List[Dict]:
        breaches = []
        breach_keywords = ["breach", "leak", "dump", "database", "compilation", "combolist", "config"]
        
        for r in results:
            content = (r.get("scraped_content", "") or r.get("title", "")).lower()
            title = r.get("title", "").lower()
            for kw in breach_keywords:
                if kw in title:
                    breaches.append({
                        "title": r.get("title", ""),
                        "source": r.get("link", ""),
                        "type": kw,
                        "context": content[:500],
                    })
                    break
        
        return breaches[:20]
    
    def _classify_data_types(self, results: List[Dict]) -> Dict[str, int]:
        types = {}
        type_keywords = {
            "credentials": ["email:pass", "username:password", "combo", "log", "credential"],
            "pii": ["fullz", "ssn", "dob", "passport", "driver license", "id scan", "utility bill"],
            "financial": ["cc", "cvv", "dump", "track1", "track2", "bin", "bank log", "paypal"],
            "corporate": ["source code", "github", "gitlab", "internal", "confidential", "hr", "financial report"],
            "access": ["rdp", "vpn", "ssh", "shell", "cpanel", "admin panel", "ssh key", "aws key"],
        }
        
        for r in results:
            content = (r.get("scraped_content", "") or r.get("title", "")).lower()
            for dtype, keywords in type_keywords.items():
                for kw in keywords:
                    if kw in content:
                        types[dtype] = types.get(dtype, 0) + 1
                        break
        
        return types
    
    def _extract_pii_artifacts(self, results: List[Dict]) -> Dict[str, List]:
        pii = {"emails": [], "phones": [], "ssns": [], "names": []}
        for r in results:
            content = r.get("scraped_content", "") or r.get("title", "")
            iocs = r.get("iocs", extract_iocs(content))
            pii["emails"].extend(iocs.get("emails", []))
            pii["phones"].extend(iocs.get("phones", []))
            pii["ssns"].extend(re.findall(r'\b\d{3}-\d{2}-\d{4}\b', content))
        
        for k in pii:
            pii[k] = list(set(pii[k]))[:100]
        
        return pii
    
    def _extract_artifacts(self, results: List[Dict]) -> Dict[str, List]:
        return self._extract_pii_artifacts(results)
    
    def analyze_results(self, task: AgentTask, results: Any) -> Dict:
        analysis_prompt = f"""Analyze data broker and breach intelligence.

OBJECTIVE: {task.objective}
BROKERS: {len(results.get('brokers', []))}
BREACHES: {len(results.get('breaches', []))}
DATA TYPES: {results.get('data_types', {})}
PII SAMPLES: {json.dumps({k: v[:5] for k, v in results.get('artifacts', {}).get('pii', {}).items()}, default=str)}

Return JSON: {{"broker_profiles": [], "breach_attribution": [], "supply_chain_map": {{}}, "pricing_intel": {{}}, "risk_assessment": "", "confidence": 0.0, "pivot_queries": []}}"""
        
        try:
            return self._invoke_llm_json(analysis_prompt)
        except Exception as e:
            logger.error(f"Data broker analysis failed: {e}")
            return {"broker_profiles": results.get("brokers", []), "breach_attribution": [], "supply_chain_map": {}, "pricing_intel": {}, "risk_assessment": "Unknown", "confidence": 0.3, "pivot_queries": []}


class OpSecAuditorAgent(BaseAgent):
    def __init__(self, model: str | None = None):
        super().__init__(AgentType.OPSEC_AUDITOR, model)
    
    def get_system_prompt(self) -> str:
        return """You are the OPSEC AUDITOR AGENT - expert in operational security analysis, 
identifying OpSec failures, deanonymization vectors, correlation attacks, 
metadata leakage, forensic artifact discovery, and attacker mistake pattern recognition.

CORE CAPABILITIES:
- OpSec failure pattern detection (reuse, correlation, leakage)
- Metadata analysis (EXIF, document properties, timestamps)
- Language/linguistic fingerprinting
- Timezone/activity pattern correlation
- Infrastructure reuse detection
- Cryptocurrency address reuse tracking
- Persona vs real identity correlation
- Counter-forensics technique identification

OUTPUT: JSON with opsec_failures, deanonymization_vectors, correlation_risks, metadata_leaks, recommendations"""
    
    def plan_execution(self, objective: str, context: Dict) -> List[AgentTask]:
        artifacts = context.get("artifacts", {})
        onions = artifacts.get("onions", [])
        emails = artifacts.get("emails", [])
        handles = context.get("handles", [])
        
        queries = [objective]
        for onion in onions[:5]:
            queries.append(f"{onion} opsec failure")
            queries.append(f"{onion} admin identity")
        for email in emails[:5]:
            queries.append(f'"{email}" real name')
        for handle in handles[:5]:
            queries.append(f'"{handle}" doxxed')
        
        queries.extend(["opsec failure ransomware", "admin doxxed darknet", "bitcoin address reuse identity"])
        
        return [AgentTask(
            id=str(uuid.uuid4()),
            agent_type=AgentType.OPSEC_AUDITOR,
            objective=objective,
            parameters={"queries": queries[:12], "max_results": 25, "deep_analysis": True}
        )]
    
    def execute_task(self, task: AgentTask, context: Dict) -> Any:
        self.status = AgentStatus.EXECUTING
        start = time.time()
        self.metrics["queries_executed"] += 1
        
        all_results = []
        for query in task.parameters.get("queries", []):
            try:
                results = get_search_results(query.replace(" ", "+"), max_workers=5)
                all_results.extend(results[:task.parameters.get("max_results", 25)])
            except Exception as e:
                logger.error(f"OpSec search failed: {e}")
        
        if all_results:
            scraped = scrape_multiple(all_results[:15], max_workers=5)
            for url, content in scraped.items():
                for r in all_results:
                    if r.get("link") == url:
                        r["scraped_content"] = content[:15000]
                        r["metadata"] = r.get("metadata", {})
                        break
        
        task.latency_ms = int((time.time() - start) * 1000)
        return {
            "results": all_results,
            "opsec_failures": self._detect_opsec_failures(all_results),
            "correlation_vectors": self._find_correlation_vectors(all_results),
            "metadata_leaks": self._find_metadata_leaks(all_results),
            "artifacts": {"opsec": self._extract_opsec_artifacts(all_results)},
        }
    
    def _detect_opsec_failures(self, results: List[Dict]) -> List[Dict]:
        failures = []
        failure_patterns = {
            "clearnet_leak": ["clearnet", "clear web", "surface web", "github.com", "gitlab.com"],
            "email_reuse": ["gmail.com", "protonmail.com", "tutanota.com", "mail.ru"],
            "handle_reuse": ["same handle", "also known as", "aka", "formerly"],
            "infrastructure_reuse": ["same server", "shared hosting", "same ip", "same provider"],
            "crypto_reuse": ["same address", "address reuse", "cluster"],
            "language_leak": ["native language", "timezone", "working hours", "keyboard layout"],
        }
        
        for r in results:
            content = (r.get("scraped_content", "") or r.get("title", "")).lower()
            for failure_type, keywords in failure_patterns.items():
                for kw in keywords:
                    if kw in content:
                        failures.append({
                            "type": failure_type,
                            "indicator": kw,
                            "source": r.get("link", ""),
                            "context": content[:500],
                            "severity": "high" if failure_type in ["clearnet_leak", "email_reuse", "crypto_reuse"] else "medium",
                        })
                        break
        
        return failures[:30]
    
    def _find_correlation_vectors(self, results: List[Dict]) -> List[Dict]:
        vectors = []
        for r in results:
            content = r.get("scraped_content", "") or r.get("title", "")
            iocs = r.get("iocs", extract_iocs(content))
            
            if iocs.get("emails") and iocs.get("onions"):
                vectors.append({"type": "email_onion_correlation", "emails": iocs["emails"], "onions": iocs["onions"], "source": r.get("link")})
            if iocs.get("btc_addresses") and iocs.get("onions"):
                vectors.append({"type": "btc_onion_correlation", "btc": iocs["btc_addresses"], "onions": iocs["onions"], "source": r.get("link")})
            if iocs.get("phones") and iocs.get("emails"):
                vectors.append({"type": "phone_email_correlation", "phones": iocs["phones"], "emails": iocs["emails"], "source": r.get("link")})
        
        return vectors[:20]
    
    def _find_metadata_leaks(self, results: List[Dict]) -> List[Dict]:
        leaks = []
        for r in results:
            metadata = r.get("metadata", {})
            if metadata.get("generator"):
                leaks.append({"type": "server_generator", "value": metadata["generator"], "source": r.get("link")})
            if metadata.get("language"):
                leaks.append({"type": "language_header", "value": metadata["language"], "source": r.get("link")})
            for link in metadata.get("links", [])[:10]:
                if any(kw in link.get("url", "").lower() for kw in ["admin", "panel", "cpanel", "phpmyadmin", "server-status"]):
                    leaks.append({"type": "admin_interface_exposed", "url": link["url"], "source": r.get("link")})
        
        return leaks[:20]
    
    def _extract_opsec_artifacts(self, results: List[Dict]) -> Dict[str, List]:
        return {
            "failures": [f["type"] for f in self._detect_opsec_failures(results)],
            "correlation_vectors": [v["type"] for v in self._find_correlation_vectors(results)],
        }
    
    def _extract_artifacts(self, results: List[Dict]) -> Dict[str, List]:
        return self._extract_opsec_artifacts(results)
    
    def analyze_results(self, task: AgentTask, results: Any) -> Dict:
        analysis_prompt = f"""Analyze OpSec audit results for deanonymization potential.

OBJECTIVE: {task.objective}
OPSEC FAILURES: {len(results.get('opsec_failures', []))}
CORRELATION VECTORS: {len(results.get('correlation_vectors', []))}
METADATA LEAKS: {len(results.get('metadata_leaks', []))}
TOP FAILURES: {json.dumps(results.get('opsec_failures', [])[:5], default=str)}

Return JSON: {{"deanonymization_risk": "low|medium|high|critical", "key_vectors": [], "identity_leads": [], "countermeasures": [], "confidence": 0.0, "pivot_queries": []}}"""
        
        try:
            return self._invoke_llm_json(analysis_prompt)
        except Exception as e:
            logger.error(f"OpSec analysis failed: {e}")
            return {"deanonymization_risk": "medium", "key_vectors": [], "identity_leads": [], "countermeasures": [], "confidence": 0.3, "pivot_queries": []}


# ── Orchestrator Agent ──────────────────────────────────────────────────

class OrchestratorAgent(BaseAgent):
    def __init__(self, model: str | None = None):
        if model is None:
            from llm_utils import get_model_choices
            choices = get_model_choices()
            model = choices[0] if choices else "gpt4o"
        super().__init__(AgentType.ORCHESTRATOR, model)
        self.agents = {
            AgentType.RECONNAISSANCE: ReconnaissanceAgent(model),
            AgentType.THREAT_ACTOR_PROFILER: ThreatActorProfilerAgent(model),
            AgentType.MALWARE_ANALYST: MalwareAnalystAgent(model),
            AgentType.CRYPTO_TRACER: CryptoTracerAgent(model),
            AgentType.INFRASTRUCTURE_MAPPER: InfrastructureMapperAgent(model),
            AgentType.DATA_BROKER_HUNTER: DataBrokerHunterAgent(model),
            AgentType.OPSEC_AUDITOR: OpSecAuditorAgent(model),
        }
        self.execution_history: List[Dict] = []
        self.global_memory = AgentMemory()
    
    def get_system_prompt(self) -> str:
        return """You are the ORCHESTRATOR AGENT - supreme coordinator of all dark web OSINT agents.
Plan multi-agent investigations, coordinate parallel execution, synthesize cross-agent findings,
resolve conflicts, identify gaps, and dynamically adapt the investigation strategy.

CORE CAPABILITIES:
- Multi-agent investigation planning and coordination
- Dynamic task decomposition and dependency resolution
- Cross-agent finding synthesis and correlation
- Gap analysis and pivot generation
- Resource allocation and priority management
- Self-healing workflow recovery
- Learning across all agent executions

OUTPUT: JSON investigation plan with tasks, dependencies, agent assignments, priority"""
    
    def create_investigation_plan(self, objective: str, context: Dict | None = None) -> InvestigationPlan:
        context = context or {}
        
        planning_prompt = f"""You are the Orchestrator. Create a comprehensive multi-agent investigation plan.

OBJECTIVE: {objective}
INITIAL CONTEXT: {json.dumps(context, default=str)[:3000]}
AVAILABLE AGENTS: {[a.value for a in AgentType if a != AgentType.ORCHESTRATOR]}
GLOBAL MEMORY (patterns): {len(self.global_memory.patterns)} patterns learned
GLOBAL MEMORY (lessons): {self.global_memory.lessons_learned[-5:]}

Create a JSON investigation plan with:
- "objective": the main goal
- "tasks": array of tasks, each with: id, agent_type, objective, parameters, dependencies, priority (1-10)
- "execution_strategy": "parallel" | "sequential" | "adaptive"
- "success_criteria": what constitutes completion
- "max_iterations": max planning/execution cycles

Return ONLY the JSON plan."""
        
        try:
            plan_data = self._invoke_llm_json(planning_prompt)
            
            raw_tasks = plan_data.get("tasks", [])
            if not isinstance(raw_tasks, list):
                raw_tasks = []
            
            tasks = []
            for t in raw_tasks:
                if not isinstance(t, dict):
                    continue
                try:
                    agent_type_str = t.pop("agent_type", "reconnaissance")
                    try:
                        agent_type = AgentType(agent_type_str)
                    except ValueError:
                        agent_type = AgentType.RECONNAISSANCE
                    # Filter to only valid AgentTask fields
                    filtered = {k: v for k, v in t.items() if k in _VALID_TASK_FIELDS}
                    filtered.pop("status", None)
                    filtered.pop("result", None)
                    filtered.pop("error", None)
                    filtered.pop("started_at", None)
                    filtered.pop("completed_at", None)
                    filtered.pop("iterations", None)
                    filtered.pop("latency_ms", None)
                    filtered.setdefault("id", str(uuid.uuid4()))
                    filtered.setdefault("objective", objective)
                    filtered.setdefault("parameters", {"queries": [objective], "max_results": 50})
                    tasks.append(AgentTask(**filtered, agent_type=agent_type))
                except Exception as e:
                    logger.debug(f"Skipping malformed task: {e}")
                    continue
            
            plan = InvestigationPlan(
                id=str(uuid.uuid4()),
                objective=objective,
                tasks=tasks,
                execution_strategy=plan_data.get("execution_strategy", "adaptive"),
                success_criteria=plan_data.get("success_criteria", ""),
            )
            
            self.execution_history.append({
                "plan_id": plan.id,
                "objective": objective,
                "created_at": plan.created_at,
                "task_count": len(tasks),
            })
            
            return plan
        except Exception as e:
            logger.error(f"Orchestrator planning failed: {e}")
            return InvestigationPlan(
                id=str(uuid.uuid4()),
                objective=objective,
                tasks=[AgentTask(
                    id=str(uuid.uuid4()),
                    agent_type=AgentType.RECONNAISSANCE,
                    objective=objective,
                    parameters={"queries": [objective], "max_results": 50}
                )]
            )
    
    def execute_plan(self, plan: InvestigationPlan, progress_callback: Callable | None = None, context: Dict | None = None) -> Dict:
        plan.status = "executing"
        results = {}
        completed_tasks: Set[str] = set()
        outer_context = context or {}
        
        def can_execute(task: AgentTask) -> bool:
            return all(dep in completed_tasks for dep in task.dependencies)
        
        def has_circular_dependency(task: AgentTask, visited: Set[str] = None) -> bool:
            """Check for circular dependencies."""
            if visited is None:
                visited = set()
            if task.id in visited:
                return True
            visited.add(task.id)
            for dep_id in task.dependencies:
                dep_task = pending_tasks.get(dep_id)
                if dep_task and has_circular_dependency(dep_task, visited.copy()):
                    return True
            return False
        
        pending_tasks = {t.id: t for t in plan.tasks}
        
        # Validate no circular dependencies
        for task in pending_tasks.values():
            if has_circular_dependency(task):
                logger.error(f"Circular dependency detected for task {task.id}")
                task.status = AgentStatus.FAILED
                task.error = "Circular dependency detected"
                completed_tasks.add(task.id)
        
        # safety: prevent infinite loop
        loop_guard = 0
        max_iterations = ORCHESTRATOR_MAX_LOOP_ITERATIONS
        
        # Create executor once outside the loop for better resource management
        executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix="orchestrator")
        try:
            while pending_tasks and plan.status == "executing" and loop_guard < max_iterations:
                loop_guard += 1
                executable = [t for t in pending_tasks.values() if can_execute(t) and t.status != AgentStatus.EXECUTING]
                
                if not executable:
                    # Check if all remaining tasks are already executing (waiting for completion)
                    executing_count = sum(1 for t in pending_tasks.values() if t.status == AgentStatus.EXECUTING)
                    if executing_count == 0:
                        logger.warning("No executable tasks - dependency deadlock or all tasks failed")
                        break
                    # Wait a bit for executing tasks to complete
                    time.sleep(0.5)
                    continue
                
                executable.sort(key=lambda t: t.priority, reverse=True)
                
                future_to_task = {}
                for task in executable[:3]:
                    agent = self.agents.get(task.agent_type)
                    if agent:
                        task.status = AgentStatus.EXECUTING
                        task.started_at = datetime.now().isoformat()
                        # merge contexts safely
                        ctx = {**outer_context, **results}
                        future = executor.submit(self._execute_agent_task, agent, task, ctx)
                        future_to_task[future] = task
                    else:
                        logger.error(f"No agent found for type {task.agent_type}")
                        task.status = AgentStatus.FAILED
                        task.error = f"Agent {task.agent_type.value} not available"
                        completed_tasks.add(task.id)
                
                completed_batch = []
                for future in as_completed(future_to_task):
                    task = future_to_task[future]
                    try:
                        result = future.result(timeout=float(task.timeout_seconds) + ORCHESTRATOR_TASK_TIMEOUT_BUFFER)
                        task.result = result
                        task.status = AgentStatus.COMPLETED
                        task.completed_at = datetime.now().isoformat()
                        completed_tasks.add(task.id)
                        results[task.id] = result
                        completed_batch.append(task.id)
                        
                        agent = self.agents.get(task.agent_type)
                        if agent:
                            agent.learn_from_execution(task, result, True)
                            self._update_global_memory(agent)
                        
                        if progress_callback:
                            try:
                                progress_callback(task, result)
                            except Exception:
                                pass
                            
                    except FuturesTimeoutError:
                        task.error = f"Task timeout after {task.timeout_seconds}s"
                        task.status = AgentStatus.FAILED
                        logger.error(f"Task {task.id} timed out")
                        
                        agent = self.agents.get(task.agent_type)
                        if agent:
                            try:
                                agent.learn_from_execution(task, None, False)
                            except Exception:
                                pass
                        
                        if task.iterations < task.max_iterations and self.agents.get(task.agent_type) and self.agents.get(task.agent_type).self_healing_enabled:
                            task.iterations += 1
                            task.status = AgentStatus.PLANNING
                            # Reset for retry - remove from completed_tasks so it can be re-executed
                            completed_tasks.discard(task.id)
                            # Also remove from pending_tasks to allow re-scheduling
                            # Don't add to completed_batch, will be retried in next iteration
                            pending_tasks[task.id] = task
                            continue
                        
                        completed_tasks.add(task.id)
                        completed_batch.append(task.id)
                    except Exception as e:
                        task.error = str(e)[:500]
                        task.status = AgentStatus.FAILED
                        logger.error(f"Task {task.id} failed: {e}")
                        
                        agent = self.agents.get(task.agent_type)
                        if agent:
                            try:
                                agent.learn_from_execution(task, None, False)
                            except Exception:
                                pass
                        
                        if task.iterations < task.max_iterations and self.agents.get(task.agent_type) and self.agents.get(task.agent_type).self_healing_enabled:
                            task.iterations += 1
                            task.status = AgentStatus.PLANNING
                            completed_tasks.discard(task.id)
                            pending_tasks[task.id] = task
                            continue
                        
                        completed_tasks.add(task.id)
                        completed_batch.append(task.id)
                
                for tid in completed_batch:
                    pending_tasks.pop(tid, None)
                # also remove any executable that failed to be submitted (agent missing)
                for t in executable[:3]:
                    if t.id not in completed_tasks and t.status == AgentStatus.EXECUTING:
                        pending_tasks.pop(t.id, None)
            
            if loop_guard >= max_iterations:
                logger.warning(f"Orchestrator reached max iterations ({max_iterations}), stopping")
                plan.status = "partial"
        finally:
            executor.shutdown(wait=True)
        
        plan.status = "completed" if not pending_tasks else "partial"
        plan.updated_at = datetime.now().isoformat()
        plan.results = results
        
        return self._synthesize_results(plan, results)

    def _execute_agent_task(self, agent: BaseAgent, task: AgentTask, context: Dict) -> Any:
        agent.status = AgentStatus.PLANNING
        try:
            subtasks = agent.plan_execution(task.objective, context)
        except Exception as e:
            logger.error(f"Agent planning failed for {agent.agent_type.value}: {e}")
            subtasks = [task]
        
        if not subtasks:
            subtasks = [task]
        
        # Ensure all subtasks have valid agent_type and valid parameters
        for st in subtasks:
            if not hasattr(st, 'agent_type') or st.agent_type is None:
                st.agent_type = agent.agent_type
            if not hasattr(st, 'timeout_seconds') or st.timeout_seconds <= 0:
                st.timeout_seconds = task.timeout_seconds
            if st.timeout_seconds > 1800:
                st.timeout_seconds = 1800
        
        if len(subtasks) > 1:
            combined_result = {}
            for subtask in subtasks:
                agent.status = AgentStatus.EXECUTING
                try:
                    result = agent.execute_task(subtask, context)
                    combined_result[subtask.id] = result
                    agent.status = AgentStatus.ANALYZING
                    analysis = agent.analyze_results(subtask, result)
                    combined_result[f"{subtask.id}_analysis"] = analysis
                except Exception as e:
                    logger.error(f"Subtask {subtask.id} failed: {e}")
                    combined_result[subtask.id] = {"error": str(e), "status": "failed"}
                    combined_result[f"{subtask.id}_analysis"] = {"error": str(e)}
            return combined_result
        agent.status = AgentStatus.EXECUTING
        try:
            result = agent.execute_task(subtasks[0], context)
        except Exception as e:
            logger.error(f"Task execution failed for {agent.agent_type.value}: {e}")
            result = {"error": str(e), "status": "failed"}
        agent.status = AgentStatus.ANALYZING
        try:
            analysis = agent.analyze_results(subtasks[0], result)
        except Exception as e:
            logger.error(f"Task analysis failed for {agent.agent_type.value}: {e}")
            analysis = {"error": str(e)}
        return {"execution": result, "analysis": analysis}
    
    def _update_global_memory(self, agent: BaseAgent) -> None:
        acquired_self = False
        acquired_agent = False
        try:
            acquired_self = self._lock.acquire(timeout=5.0)
            if not acquired_self:
                logger.warning("Could not acquire orchestrator lock for global memory update")
                return
            acquired_agent = agent._lock.acquire(timeout=5.0)
            if not acquired_agent:
                logger.warning(f"Could not acquire agent {agent.agent_type.value} lock for global memory update")
                return
            
            self.global_memory.patterns.extend(agent.memory.patterns[-10:])
            self.global_memory.lessons_learned.extend(agent.memory.lessons_learned[-5:])
            self.global_memory.successful_queries.extend(agent.memory.successful_queries[-5:])
            for k, v in agent.memory.discovered_artifacts.items():
                if k not in self.global_memory.discovered_artifacts:
                    self.global_memory.discovered_artifacts[k] = []
                self.global_memory.discovered_artifacts[k].extend(v[-10:])
            self.global_memory.prune(max_patterns=MAX_GLOBAL_MEMORY_PATTERNS, max_lessons=MAX_GLOBAL_MEMORY_LESSONS)
        except Exception as e:
            logger.debug(f"Global memory update failed: {e}")
        finally:
            if acquired_agent:
                try:
                    agent._lock.release()
                except RuntimeError:
                    pass
            if acquired_self:
                try:
                    self._lock.release()
                except RuntimeError:
                    pass
    
    def _synthesize_results(self, plan: InvestigationPlan, results: Dict) -> Dict:
        synthesis_prompt = f"""Synthesize findings from multi-agent investigation.

OBJECTIVE: {plan.objective}
AGENT RESULTS: {json.dumps({k: {"keys": list(v.keys()) if isinstance(v, dict) else str(type(v))} for k, v in results.items()}, default=str)[:5000]}
EXECUTION HISTORY: {len(self.execution_history)} previous investigations

Return JSON: {{"executive_summary": "", "key_findings": [], "all_artifacts": {{}}, "threat_landscape": "", "attribution": "", "actionable_intelligence": [], "gaps": [], "recommended_next_steps": [], "confidence": 0.0}}"""
        
        # collect artifacts regardless of synthesis success - guarantees features 100% working
        all_artifacts = {}
        for result in results.values():
            if isinstance(result, dict):
                # handle both direct artifacts and nested execution wrapper
                candidates = [result]
                if "execution" in result and isinstance(result["execution"], dict):
                    candidates.append(result["execution"])
                for cand in candidates:
                    artifacts = cand.get("artifacts", {}) or cand.get("all_artifacts", {})
                    if isinstance(artifacts, dict):
                        for k, v in artifacts.items():
                            if isinstance(v, list):
                                if k not in all_artifacts:
                                    all_artifacts[k] = []
                                all_artifacts[k].extend(v)
                            elif v:
                                if k not in all_artifacts:
                                    all_artifacts[k] = []
                                all_artifacts[k].append(v)
                    # also flatten any iocs style artifacts
                    if isinstance(cand.get("artifacts"), dict):
                        pass
        
        for k in list(all_artifacts.keys()):
            if isinstance(all_artifacts[k], list):
                # dedup preserve order, cap 200 per type
                seen=set(); dedup=[]
                for x in all_artifacts[k]:
                    key=str(x)[:500]
                    if key not in seen:
                        seen.add(key); dedup.append(x)
                all_artifacts[k] = dedup[:200]
        
        try:
            synthesis = self._invoke_llm_json(synthesis_prompt)
            synthesis["all_artifacts"] = all_artifacts or synthesis.get("all_artifacts", {})
            synthesis["plan_id"] = plan.id
            synthesis["agent_metrics"] = {a_type.value: agent.get_self_awareness_report()["metrics"] for a_type, agent in self.agents.items()}
            # ensure required keys
            for k in ("executive_summary","key_findings","actionable_intelligence","recommended_next_steps"):
                if k not in synthesis:
                    synthesis[k]=[] if "findings" in k or "intelligence" in k or "steps" in k else ""
            if "confidence" not in synthesis:
                synthesis["confidence"]=0.6
            return synthesis
        except Exception as e:
            logger.error(f"Synthesis failed: {e}")
            # guaranteed non-empty synthesis so AI always responds
            return {
                "executive_summary": f"Investigation '{plan.objective}' completed with {len(all_artifacts)} artifact types across {len(results)} agent tasks. LLM synthesis was temporarily unavailable — raw artifacts are preserved below for pivot.",
                "key_findings": [f"Collected {sum(len(v) for v in all_artifacts.values())} artifacts", f"Agents executed: {len(results)} tasks", "Review artifacts for next pivots"],
                "all_artifacts": all_artifacts,
                "actionable_intelligence": ["Re-run with a more specific 3-5 word query if coverage is low", "Check Sidebar → Health Checks → LLM Connection"],
                "recommended_next_steps": ["Pivot on top onion/btc/email artifacts", "Download artifacts for deeper analysis"],
                "confidence": 0.45,
                "plan_id": plan.id,
                "agent_metrics": {a_type.value: agent.get_self_awareness_report()["metrics"] for a_type, agent in self.agents.items()},
                "gaps": ["Synthesis LLM was unavailable - raw artifacts provided"],
            }
    
    def plan_execution(self, objective: str, context: Dict) -> List[AgentTask]:
        plan = self.create_investigation_plan(objective, context)
        return plan.tasks
    
    def execute_task(self, task: AgentTask, context: Dict) -> Any:
        plan = InvestigationPlan(id=task.id, objective=task.objective, tasks=[task])
        return self.execute_plan(plan, context=context)
    
    def analyze_results(self, task: AgentTask, results: Any) -> Dict:
        return results
    
    def get_full_self_awareness_report(self) -> Dict:
        return {
            "orchestrator": self.get_self_awareness_report(),
            "agents": {a_type.value: agent.get_self_awareness_report() for a_type, agent in self.agents.items()},
            "global_memory": {
                "patterns": len(self.global_memory.patterns),
                "lessons": len(self.global_memory.lessons_learned),
                "successful_queries": len(self.global_memory.successful_queries),
                "artifact_types": list(self.global_memory.discovered_artifacts.keys()),
            },
            "execution_history_count": len(self.execution_history),
        }


# ── Factory Functions ───────────────────────────────────────────────────

_orchestrator_cache: Dict[str, OrchestratorAgent] = {}
_agent_cache: Dict[str, Dict[AgentType, BaseAgent]] = {}

def get_orchestrator(model: str | None = None) -> OrchestratorAgent:
    if model is None:
        from llm_utils import get_model_choices
        choices = get_model_choices()
        model = choices[0] if choices else "gpt4o"
    cache_key = str(model)
    if cache_key not in _orchestrator_cache:
        _orchestrator_cache[cache_key] = OrchestratorAgent(model)
    return _orchestrator_cache[cache_key]


def get_all_agents(model: str | None = None) -> Dict[AgentType, BaseAgent]:
    if model is None:
        from llm_utils import get_model_choices
        choices = get_model_choices()
        model = choices[0] if choices else "gpt4o"
    cache_key = str(model)
    if cache_key not in _agent_cache:
        _agent_cache[cache_key] = {
            AgentType.RECONNAISSANCE: ReconnaissanceAgent(model),
            AgentType.THREAT_ACTOR_PROFILER: ThreatActorProfilerAgent(model),
            AgentType.MALWARE_ANALYST: MalwareAnalystAgent(model),
            AgentType.CRYPTO_TRACER: CryptoTracerAgent(model),
            AgentType.INFRASTRUCTURE_MAPPER: InfrastructureMapperAgent(model),
            AgentType.DATA_BROKER_HUNTER: DataBrokerHunterAgent(model),
            AgentType.OPSEC_AUDITOR: OpSecAuditorAgent(model),
        }
    return _agent_cache[cache_key]