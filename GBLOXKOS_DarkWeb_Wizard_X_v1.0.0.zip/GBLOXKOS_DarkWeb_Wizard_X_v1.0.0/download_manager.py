"""
Download Manager - Production-grade download manager with async support, resume, and validation.
"""
import asyncio
import hashlib
import inspect
import json
import logging
import mimetypes
import os
import random
import requests
import shutil
import threading
import time
import weakref
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Tuple
from urllib.parse import urlparse

import aiofiles
import aiohttp

from session import get_tor_session, get_direct_session, USER_AGENTS, MAX_DOWNLOAD_BYTES

if TYPE_CHECKING:  # pragma: no cover - typing only
    import tarfile

logger = logging.getLogger(__name__)

# Module-level constants
MAX_JOBS = 1000
MAX_JOB_METADATA_SIZE = 10 * 1024 * 1024  # 10MB
MAX_EXTRACTED_FILES = 1000
#: Total uncompressed bytes allowed from a single archive (decompression-bomb guard).
MAX_EXTRACT_BYTES = 500 * 1024 * 1024  # 500MB


def _tar_extract_kwargs() -> Dict[str, Any]:
    """Build ``TarFile.extract`` kwargs, using the stdlib data filter when available.

    ``filter='data'`` (CPython >= 3.10.12 / 3.11.4 / 3.12) applies the
    library's own traversal and permission hardening and becomes the default in
    Python 3.14. Older interpreters fall back to ``set_attrs=False``, which our
    own ``_safe_tar_members`` pass already makes safe.
    """
    import tarfile

    kwargs: Dict[str, Any] = {"set_attrs": False}
    try:
        probe = tarfile.TarFile.extract  # type: ignore[attr-defined]
        if "filter" in inspect.signature(probe).parameters:
            kwargs["filter"] = "data"
    except (TypeError, ValueError):
        pass
    return kwargs


_TAR_EXTRACT_KWARGS = _tar_extract_kwargs()
DOWNLOAD_CHUNK_SIZE = 8192
DEFAULT_CONNECT_TIMEOUT = 15
DEFAULT_READ_TIMEOUT = 120
MAX_DOWNLOAD_LIMIT = MAX_DOWNLOAD_BYTES


# ── Enums ────────────────────────────────────────────────────────────────

class DownloadStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"


class ContentType(Enum):
    FILE = "file"
    FOLDER = "folder"
    TOOL = "tool"
    APP = "app"
    ARCHIVE = "archive"
    SCRIPT = "script"
    DATABASE = "database"
    CONFIG = "config"
    DOCUMENT = "document"
    IMAGE = "image"
    VIDEO = "video"
    AUDIO = "audio"
    UNKNOWN = "unknown"


# ── Data Classes ────────────────────────────────────────────────────────

@dataclass
class DownloadItem:
    url: str
    title: str = ""
    content_type: ContentType = ContentType.UNKNOWN
    size_bytes: int = 0
    status: DownloadStatus = DownloadStatus.PENDING
    progress: float = 0.0
    downloaded_bytes: int = 0
    local_path: str = ""
    error: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    iocs: Dict[str, List[str]] = field(default_factory=dict)
    checksum: str = ""
    started_at: str | None = None
    completed_at: str | None = None
    resume_from: int = 0
    etag: str = ""
    last_modified: str = ""


@dataclass
class DownloadJob:
    id: str
    name: str
    items: List[DownloadItem] = field(default_factory=list)
    status: DownloadStatus = DownloadStatus.PENDING
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    completed_at: str | None = None
    total_size: int = 0
    downloaded_size: int = 0
    output_dir: str = ""
    options: Dict[str, Any] = field(default_factory=dict)
    _callbacks: List[Callable] = field(default_factory=list, repr=False)
    
    def add_callback(self, callback: Callable) -> None:
        self._callbacks.append(callback)
    
    def _notify(self, item: DownloadItem | None = None) -> None:
        for cb in self._callbacks:
            try:
                cb(self.id, item)
            except Exception as e:
                logger.error(f"Callback error: {e}")


# ── Download Manager ────────────────────────────────────────────────────

class DownloadManager:
    """Thread-safe download manager with pause/resume/cancel support."""
    
    def __init__(self, base_download_dir: str = "downloads", max_workers: int = 8):
        self.base_download_dir = Path(base_download_dir)
        self.base_download_dir.mkdir(parents=True, exist_ok=True)
        self.jobs: Dict[str, DownloadJob] = {}
        self._job_weakrefs: Dict[str, weakref.ref] = {}
        self._lock = threading.RLock()
        self.executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="downloader")
        self._running = True
        self._shutdown_event = threading.Event()
        self._job_counter = 0
        self._cleanup_interval = 3600  # 1 hour
        self._last_cleanup = time.time()
        
    def create_job(
        self,
        name: str,
        urls: List[Dict[str, str]],
        options: Dict | None = None,
    ) -> str:
        """Create a new download job."""
        if not urls:
            raise ValueError("No URLs provided")
        
        # Clean up old jobs if we're at the limit
        with self._lock:
            if len(self.jobs) >= MAX_JOBS:
                self._cleanup_old_jobs_locked()
            if len(self.jobs) >= MAX_JOBS:
                raise RuntimeError(f"Maximum number of jobs ({MAX_JOBS}) reached")
        
        job_id = hashlib.blake2b(
            f"{name}{datetime.now().isoformat()}{self._job_counter}".encode(),
            digest_size=6,
        ).hexdigest()
        self._job_counter += 1
        output_dir = self.base_download_dir / job_id
        output_dir.mkdir(parents=True, exist_ok=True)
        
        items = []
        for url_data in urls:
            url, title = self._normalize_url_data(url_data)
            if not url:
                continue
            content_type = self._detect_content_type(url, title)
            item = DownloadItem(
                url=url,
                title=title,
                content_type=content_type,
                metadata={"source": url_data},
            )
            items.append(item)
        
        if not items:
            raise ValueError("No valid URLs after normalization")
        
        job = DownloadJob(
            id=job_id,
            name=name,
            items=items,
            output_dir=str(output_dir),
            options=options or {},
        )
        
        with self._lock:
            self.jobs[job_id] = job
            self._job_weakrefs[job_id] = weakref.ref(job)
        
        logger.info(f"Created download job {job_id} ({name}) with {len(items)} items")
        return job_id
    
    def _cleanup_old_jobs_locked(self) -> int:
        """Remove completed/failed/cancelled jobs older than 24 hours. Must be called with lock held."""
        now = datetime.now()
        cutoff = now.timestamp() - (24 * 3600)
        removed = 0
        
        jobs_to_remove = []
        for job_id, job in self.jobs.items():
            if job.status in (DownloadStatus.COMPLETED, DownloadStatus.FAILED, DownloadStatus.CANCELLED):
                try:
                    completed_at = datetime.fromisoformat(job.completed_at) if job.completed_at else None
                    if completed_at and completed_at.timestamp() < cutoff:
                        jobs_to_remove.append(job_id)
                except Exception:
                    pass
        
        for job_id in jobs_to_remove:
            job = self.jobs.pop(job_id, None)
            if job:
                self._job_weakrefs.pop(job_id, None)
                removed += 1
        
        return removed
    
    def cleanup_old_jobs(self, max_age_hours: int = 24) -> int:
        """Public method to clean up old jobs."""
        with self._lock:
            return self._cleanup_old_jobs_locked()
    
    def _normalize_url_data(self, url_data: Any) -> Tuple[str, str]:
        if not isinstance(url_data, dict):
            return "", "Untitled"
        url = str(url_data.get("link") or "").strip()
        title = str(url_data.get("title") or "Untitled").strip() or "Untitled"
        return url, title
    
    def _detect_content_type(self, url: str, title: str) -> ContentType:
        title_lower = title.lower()
        parsed = urlparse(url)
        path = parsed.path.lower()
        
        # By extension
        if any(ext in path for ext in ['.zip', '.tar', '.gz', '.rar', '.7z', '.bz2', '.xz', '.tgz']):
            return ContentType.ARCHIVE
        if any(ext in path for ext in ['.exe', '.bin', '.sh', '.py', '.js', '.php', '.pl', '.rb', '.go', '.rs']):
            return ContentType.TOOL
        if any(ext in path for ext in ['.apk', '.ipa', '.app', '.dmg', '.msi', '.deb', '.rpm']):
            return ContentType.APP
        if any(ext in path for ext in ['.sql', '.db', '.sqlite', '.dump', '.bak']):
            return ContentType.DATABASE
        if any(ext in path for ext in ['.conf', '.config', '.ini', '.yaml', '.yml', '.toml', '.env']):
            return ContentType.CONFIG
        if any(ext in path for ext in ['.pdf', '.doc', '.docx', '.txt', '.md', '.rtf', '.odt']):
            return ContentType.DOCUMENT
        if any(ext in path for ext in ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.svg', '.ico']):
            return ContentType.IMAGE
        if any(ext in path for ext in ['.mp4', '.avi', '.mkv', '.mov', '.webm', '.flv']):
            return ContentType.VIDEO
        if any(ext in path for ext in ['.mp3', '.wav', '.flac', '.ogg', '.m4a']):
            return ContentType.AUDIO
        
        # By title keywords
        if any(kw in title_lower for kw in ['tool', 'script', 'exploit', 'payload', 'loader', 'stealer', 'rat', 'botnet']):
            return ContentType.TOOL
        if any(kw in title_lower for kw in ['app', 'application', 'panel', 'dashboard', 'admin', 'c2', 'cnc']):
            return ContentType.APP
        if any(kw in title_lower for kw in ['folder', 'directory', 'archive', 'collection', 'pack', 'bundle']):
            return ContentType.FOLDER
        
        return ContentType.FILE
    
    def start_job(self, job_id: str) -> bool:
        """Start or resume a download job."""
        with self._lock:
            job = self.jobs.get(job_id)
            if not job:
                return False
            if job.status in (DownloadStatus.IN_PROGRESS, DownloadStatus.COMPLETED):
                return True
            job.status = DownloadStatus.IN_PROGRESS
        
        self.executor.submit(self._run_job, job_id)
        return True
    
    def pause_job(self, job_id: str) -> bool:
        """Pause a running download job."""
        with self._lock:
            job = self.jobs.get(job_id)
            if not job or job.status != DownloadStatus.IN_PROGRESS:
                return False
            job.status = DownloadStatus.PAUSED
            for item in job.items:
                if item.status == DownloadStatus.IN_PROGRESS:
                    item.status = DownloadStatus.PAUSED
        return True
    
    def resume_job(self, job_id: str) -> bool:
        """Resume a paused download job."""
        with self._lock:
            job = self.jobs.get(job_id)
            if not job or job.status != DownloadStatus.PAUSED:
                return False
            job.status = DownloadStatus.IN_PROGRESS
            for item in job.items:
                if item.status == DownloadStatus.PAUSED:
                    item.status = DownloadStatus.PENDING
        
        self.executor.submit(self._run_job, job_id)
        return True
    
    def cancel_job(self, job_id: str) -> bool:
        """Cancel a download job."""
        with self._lock:
            job = self.jobs.get(job_id)
            if not job:
                return False
            job.status = DownloadStatus.CANCELLED
            for item in job.items:
                if item.status in (DownloadStatus.IN_PROGRESS, DownloadStatus.PENDING, DownloadStatus.PAUSED):
                    item.status = DownloadStatus.CANCELLED
        return True
    
    def delete_job(self, job_id: str, delete_files: bool = False) -> bool:
        """Delete a job and optionally its files."""
        with self._lock:
            job = self.jobs.pop(job_id, None)
        if job and delete_files:
            try:
                shutil.rmtree(job.output_dir, ignore_errors=True)
            except Exception as e:
                logger.error(f"Failed to delete job files: {e}")
        return job is not None
    
    def get_job(self, job_id: str) -> DownloadJob | None:
        with self._lock:
            return self.jobs.get(job_id)
    
    def list_jobs(self) -> List[DownloadJob]:
        with self._lock:
            return list(self.jobs.values())
    
    def _run_job(self, job_id: str) -> None:
        """Run download job in background thread."""
        job = None
        with self._lock:
            job = self.jobs.get(job_id)
            if not job:
                return
        
        try:
            for item in job.items:
                if not self._running or self._shutdown_event.is_set():
                    break
                if job.status != DownloadStatus.IN_PROGRESS:
                    break
                if item.status in (DownloadStatus.COMPLETED, DownloadStatus.FAILED, DownloadStatus.CANCELLED):
                    continue
                
                self._download_item(job, item)
                self._update_job_progress(job)
            
            # Finalize job status
            with self._lock:
                job_ref = self.jobs.get(job_id)
                if job_ref:
                    all_completed = all(
                        i.status == DownloadStatus.COMPLETED for i in job_ref.items
                    )
                    any_failed = any(
                        i.status == DownloadStatus.FAILED for i in job_ref.items
                    )
                    if all_completed:
                        job_ref.status = DownloadStatus.COMPLETED
                    elif any_failed and not any(
                        i.status == DownloadStatus.IN_PROGRESS for i in job_ref.items
                    ):
                        job_ref.status = DownloadStatus.FAILED
                    job_ref.completed_at = datetime.now().isoformat()
                    self._save_job_metadata(job_ref)
                    try:
                        job_ref._notify()
                    except Exception as e:
                        logger.debug(f"Job completion callback error: {e}")
        
        except Exception as e:
            logger.error(f"Job {job_id} failed with exception: {e}")
            with self._lock:
                job_ref = self.jobs.get(job_id)
                if job_ref:
                    job_ref.status = DownloadStatus.FAILED
        finally:
            # Periodic cleanup
            now = time.time()
            if now - self._last_cleanup > self._cleanup_interval:
                with self._lock:
                    if now - self._last_cleanup > self._cleanup_interval:
                        self._cleanup_old_jobs_locked()
                        self._last_cleanup = now
    
    def _download_item(self, job: DownloadJob, item: DownloadItem) -> None:
        """Download a single item with resume support."""
        item.status = DownloadStatus.IN_PROGRESS
        item.started_at = datetime.now().isoformat()
        job._notify(item)
        
        try:
            parsed = urlparse(item.url)
            is_onion = parsed.hostname and parsed.hostname.endswith('.onion')
            session = get_tor_session() if is_onion else get_direct_session()
            
            headers = {
                "User-Agent": random.choice(USER_AGENTS),
                "Accept": "*/*",
                "Connection": "keep-alive",
            }
            
            # Resume support
            if item.resume_from > 0:
                headers["Range"] = f"bytes={item.resume_from}-"
            
            # Conditional headers
            if item.etag:
                headers["If-None-Match"] = item.etag
            if item.last_modified:
                headers["If-Modified-Since"] = item.last_modified
            
            response = session.get(
                item.url,
                headers=headers,
                timeout=(15, 120),
                stream=True,
            )
            
            if response.status_code == 416:  # Range not satisfiable
                # File already complete
                if item.local_path and os.path.exists(item.local_path):
                    item.status = DownloadStatus.COMPLETED
                    item.progress = 1.0
                    item.downloaded_bytes = item.size_bytes
                    job._notify(item)
                    return
            
            if response.status_code not in (200, 206):
                item.status = DownloadStatus.FAILED
                item.error = f"HTTP {response.status_code}"
                job._notify(item)
                return
            
            # Update metadata from response
            content_length = response.headers.get('Content-Length')
            if content_length:
                item.size_bytes = int(content_length) + item.resume_from
            
            item.etag = response.headers.get('ETag', '')
            item.last_modified = response.headers.get('Last-Modified', '')
            
            filename = self._get_filename(item, response)
            local_path = Path(job.output_dir) / filename
            local_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Open file for append if resuming
            mode = 'ab' if item.resume_from > 0 else 'wb'
            hasher = hashlib.sha256()
            if item.resume_from > 0 and item.checksum:
                # Re-hash existing content (simplified - in production, hash incrementally)
                pass
            
            downloaded = item.downloaded_bytes
            
            with open(local_path, mode) as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if not self._running or self._shutdown_event.is_set():
                        item.status = DownloadStatus.CANCELLED
                        break
                    if job.status != DownloadStatus.IN_PROGRESS:
                        if job.status == DownloadStatus.PAUSED:
                            item.status = DownloadStatus.PAUSED
                        elif job.status == DownloadStatus.CANCELLED:
                            item.status = DownloadStatus.CANCELLED
                        break
                    if item.status == DownloadStatus.CANCELLED:
                        break
                    if not chunk:
                        continue
                    f.write(chunk)
                    hasher.update(chunk)
                    downloaded += len(chunk)
                    item.downloaded_bytes = downloaded
                    if item.size_bytes > 0:
                        item.progress = downloaded / item.size_bytes
                    job._notify(item)
                    
                    if downloaded > MAX_DOWNLOAD_BYTES:
                        logger.warning(f"Download limit reached for {item.url}")
                        break
            
            if item.status == DownloadStatus.IN_PROGRESS:
                item.checksum = hasher.hexdigest()
                item.local_path = str(local_path)
                item.size_bytes = downloaded
                item.progress = 1.0
                item.status = DownloadStatus.COMPLETED
                item.completed_at = datetime.now().isoformat()
                item.resume_from = 0  # Reset for future runs
                
                # Analyze downloaded file in background to avoid blocking
                try:
                    analysis_thread = threading.Thread(
                        target=self._analyze_downloaded_file,
                        args=(item, local_path),
                        daemon=True,
                    )
                    analysis_thread.start()
                except Exception as e:
                    logger.debug(f"Failed to start analysis thread: {e}")
            
            job._notify(item)
        
        except Exception as e:
            logger.error(f"Download failed for {item.url}: {e}")
            item.status = DownloadStatus.FAILED
            item.error = str(e)
            job._notify(item)
    
    def _get_filename(self, item: DownloadItem, response: requests.Response) -> str:
        """Extract filename from response or generate one."""
        import re as _re
        content_disposition = response.headers.get('Content-Disposition', '')
        if 'filename=' in content_disposition:
            match = _re.search(r'filename[^;=\n]*=(([\'"]).*?\2|[^;\n]*)', content_disposition)
            if match:
                filename = match.group(1).strip('"\'')
                return self._sanitize_filename(filename)
        
        parsed = urlparse(item.url)
        path = parsed.path
        filename = os.path.basename(path) or "download"
        
        if not os.path.splitext(filename)[1] and item.content_type != ContentType.UNKNOWN:
            ext_map = {
                ContentType.ARCHIVE: '.zip',
                ContentType.TOOL: '.py',
                ContentType.APP: '.exe',
                ContentType.DATABASE: '.sql',
                ContentType.CONFIG: '.conf',
                ContentType.DOCUMENT: '.txt',
                ContentType.IMAGE: '.png',
                ContentType.VIDEO: '.mp4',
                ContentType.AUDIO: '.mp3',
                ContentType.SCRIPT: '.py',
            }
            filename += ext_map.get(item.content_type, '.bin')
        
        return self._sanitize_filename(filename)
    
    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for filesystem safety."""
        # Remove path traversal attempts
        filename = os.path.basename(filename)
        # Keep only safe characters
        safe_name = "".join(c for c in filename if c.isalnum() or c in '.-_ ')
        safe_name = safe_name.strip()
        if not safe_name:
            safe_name = f"download_{hashlib.blake2b(filename.encode(), digest_size=4).hexdigest()}"
        # Limit length
        if len(safe_name) > 255:
            name, ext = os.path.splitext(safe_name)
            safe_name = name[:255 - len(ext)] + ext
        return safe_name
    
    def _analyze_downloaded_file(self, item: DownloadItem, path: Path) -> None:
        """Analyze downloaded file for type, IOCs, and threats."""
        try:
            mime_type, _ = mimetypes.guess_type(str(path))
            item.metadata['mime_type'] = mime_type
            
            suffix = path.suffix.lower()
            
            if suffix in ['.zip', '.tar', '.gz', '.tgz', '.bz2', '.xz']:
                item.content_type = ContentType.ARCHIVE
                self._extract_archive(item, path)
            elif suffix in ['.py', '.js', '.sh', '.php', '.pl', '.rb', '.ps1']:
                item.content_type = ContentType.SCRIPT
                self._analyze_script(item, path)
            elif suffix in ['.sql', '.db', '.sqlite', '.dump']:
                item.content_type = ContentType.DATABASE
            elif suffix in ['.conf', '.config', '.ini', '.yaml', '.yml', '.toml', '.env']:
                item.content_type = ContentType.CONFIG
            elif suffix in ['.exe', '.dll', '.so', '.bin', '.apk', '.ipa']:
                item.content_type = ContentType.APP
                self._analyze_binary(item, path)
        
        except Exception as e:
            logger.debug(f"File analysis failed: {e}")
    
    @staticmethod
    def _is_within(base: Path, target: Path) -> bool:
        """Return True when *target* really lives inside *base*.

        Uses ``Path.is_relative_to`` rather than a ``str.startswith`` prefix
        test, because a sibling directory such as ``<base>_evil`` shares the
        ``<base>`` string prefix while sitting outside of it.
        """
        try:
            return target.is_relative_to(base)
        except (ValueError, OSError):
            return False

    def _safe_tar_members(self, tf: "tarfile.TarFile", extract_dir: Path) -> List[Any]:
        """Filter tar members down to regular files/dirs that stay in *extract_dir*.

        Rejects absolute paths, ``..`` traversal, symlinks and hardlinks
        (a link can point outside the destination and let a later member be
        written through it), device nodes, FIFOs and oversized entries.
        """
        base = extract_dir.resolve()
        safe: List[Any] = []
        for member in tf.getmembers():
            name = member.name
            if not name or name in (".", "./"):
                continue
            if member.issym() or member.islnk():
                logger.warning(f"Skipping link member in archive: {name}")
                continue
            if member.isdev() or member.isfifo():
                logger.warning(f"Skipping special file in archive: {name}")
                continue
            if not (member.isfile() or member.isdir()):
                continue
            if os.path.isabs(name) or name.startswith(("/", "\\")):
                logger.warning(f"Skipping absolute path in archive: {name}")
                continue
            if ".." in Path(name).parts:
                logger.warning(f"Skipping traversal path in archive: {name}")
                continue
            if member.size > MAX_EXTRACT_BYTES:
                logger.warning(f"Skipping oversized member in archive: {name}")
                continue
            if not self._is_within(base, (extract_dir / name).resolve()):
                logger.warning(f"Skipping out-of-bounds path in archive: {name}")
                continue
            safe.append(member)
        return safe

    def _extract_archive(self, item: DownloadItem, path: Path) -> None:
        """Extract archive and catalog contents.

        Archives come from untrusted dark-web sources, so every member is
        validated against the destination directory before extraction. This
        defeats Zip-Slip path traversal, symlink/hardlink escapes, absolute
        paths, device nodes and decompression bombs.
        """
        try:
            extract_dir = path.parent / f"{path.stem}_extracted"
            extract_dir.mkdir(parents=True, exist_ok=True)

            extracted_files: List[str] = []
            rejected = 0

            if path.suffix.lower() == '.zip':
                import zipfile
                with zipfile.ZipFile(path, 'r') as zf:
                    base = extract_dir.resolve()
                    safe_members: List[str] = []
                    total = 0
                    for member in zf.namelist():
                        name = member
                        if not name or name.endswith('/'):
                            # Directories are created implicitly by file members.
                            dir_target = (extract_dir / name.rstrip('/')).resolve()
                            if name.rstrip('/') and self._is_within(base, dir_target):
                                dir_target.mkdir(parents=True, exist_ok=True)
                            continue
                        if os.path.isabs(name) or name.startswith(("/", "\\")):
                            logger.warning(f"Skipping absolute path in zip: {name}")
                            rejected += 1
                            continue
                        if ".." in Path(name).parts:
                            logger.warning(f"Skipping traversal path in zip: {name}")
                            rejected += 1
                            continue
                        try:
                            info = zf.getinfo(member)
                        except KeyError:
                            rejected += 1
                            continue
                        if info.file_size > MAX_EXTRACT_BYTES:
                            logger.warning(f"Skipping oversized member in zip: {name}")
                            rejected += 1
                            continue
                        total += info.file_size
                        if total > MAX_EXTRACT_BYTES:
                            logger.warning("Zip extraction budget exceeded - truncating")
                            break
                        if not self._is_within(base, (extract_dir / name).resolve()):
                            logger.warning(f"Skipping out-of-bounds path in zip: {name}")
                            rejected += 1
                            continue
                        safe_members.append(member)
                    for member in safe_members:
                        try:
                            zf.extract(member, extract_dir)
                        except Exception as exc:
                            logger.warning(f"Failed to extract zip member {member}: {exc}")
                    extracted_files = safe_members
            elif path.suffix.lower() in ['.tar', '.gz', '.tgz', '.bz2', '.xz']:
                import tarfile
                with tarfile.open(path, 'r:*') as tf:
                    all_members = tf.getmembers()
                    safe_members = self._safe_tar_members(tf, extract_dir)
                    rejected = len(all_members) - len(safe_members)
                    for member in safe_members:
                        try:
                            tf.extract(member, extract_dir, **_TAR_EXTRACT_KWARGS)
                        except Exception as exc:
                            logger.warning(f"Failed to extract tar member {member.name}: {exc}")
                    extracted_files = [m.name for m in safe_members]

            item.metadata['extracted_files'] = extracted_files[:1000]  # Limit
            item.metadata['extracted_path'] = str(extract_dir)
            item.metadata['extracted_count'] = len(extracted_files)
            item.metadata['rejected_members'] = rejected

        except Exception as e:
            logger.debug(f"Archive extraction failed: {e}")
    
    def _analyze_script(self, item: DownloadItem, path: Path) -> None:
        """Analyze script file for IOCs and suspicious patterns."""
        try:
            max_read = 100_000
            content = path.read_text(errors='ignore')[:max_read]
            item.metadata['script_preview'] = content[:5000]
            
            from scrape import extract_iocs
            item.iocs = extract_iocs(content)
            
            # Suspicious keywords
            keywords = [
                'c2', 'cnc', 'command', 'control', 'exploit', 'payload', 'shell',
                'backdoor', 'rat', 'keylogger', 'stealer', 'miner', 'botnet',
                'ddos', 'flood', 'scan', 'brute', 'crack', 'bypass', 'evasion',
                'obfuscate', 'encode', 'encrypt', 'decrypt', 'inject', 'hook',
                'rootkit', 'bootkit', 'firmware', 'bios', 'uefi', 'kernel',
            ]
            content_lower = content.lower()
            found = [kw for kw in keywords if kw in content_lower]
            item.metadata['suspicious_keywords'] = found
            
            # Entropy check - streaming for large files to avoid memory issues
            if len(content) > 100:
                import math
                from collections import Counter
                # Sample for entropy if very large
                sample = content if len(content) <= 10_000 else content[:10_000]
                counts = Counter(sample)
                length = len(sample)
                entropy = -sum((c/length) * math.log2(c/length) for c in counts.values() if c > 0)
                item.metadata['entropy'] = round(entropy, 2)
                if entropy > 7.5:
                    item.metadata['high_entropy'] = True
        
        except Exception as e:
            logger.debug(f"Script analysis failed: {e}")
    
    def _analyze_binary(self, item: DownloadItem, path: Path) -> None:
        """Basic binary analysis."""
        try:
            # Read header for magic bytes
            with open(path, 'rb') as f:
                header = f.read(16)
            
            if not header:
                item.metadata['file_type'] = 'Empty file'
                return
            
            item.metadata['magic_bytes'] = header.hex()
            
            # Identify file type
            magic_map = {
                b'MZ': 'PE (Windows Executable)',
                b'\x7fELF': 'ELF (Linux Executable)',
                b'\xca\xfe\xba\xbe': 'Mach-O (macOS)',
                b'PK\x03\x04': 'ZIP Archive',
                b'PK\x05\x06': 'ZIP Archive (empty)',
                b'PK\x07\x08': 'ZIP Archive (spanned)',
                b'\x1f\x8b': 'GZIP',
                b'BZh': 'BZIP2',
                b'\xfd7zXZ\x00': '7Z',
                b'Rar!\x1a\x07': 'RAR',
            }
            
            for magic, desc in magic_map.items():
                if header.startswith(magic):
                    item.metadata['file_type'] = desc
                    break
        
        except Exception as e:
            logger.debug(f"Binary analysis failed: {e}")
    
    def _update_job_progress(self, job: DownloadJob) -> None:
        job.downloaded_size = sum(i.downloaded_bytes for i in job.items)
        job.total_size = sum(i.size_bytes for i in job.items if i.size_bytes > 0)
    
    def _save_job_metadata(self, job: DownloadJob) -> None:
        try:
            meta_file = Path(job.output_dir) / "job_metadata.json"
            # Limit metadata size per item to prevent huge files
            limited_items = []
            for i in job.items:
                limited_metadata = {}
                for k, v in i.metadata.items():
                    if isinstance(v, (str, list, dict)):
                        # Truncate large strings and lists
                        if isinstance(v, str) and len(v) > 10000:
                            v = v[:10000] + "...(truncated)"
                        elif isinstance(v, list) and len(v) > 100:
                            v = v[:100]
                        limited_metadata[k] = v
                    else:
                        limited_metadata[k] = v
                
                limited_items.append({
                    "url": i.url,
                    "title": i.title,
                    "content_type": i.content_type.value,
                    "size_bytes": i.size_bytes,
                    "status": i.status.value,
                    "progress": i.progress,
                    "downloaded_bytes": i.downloaded_bytes,
                    "local_path": i.local_path,
                    "error": i.error,
                    "checksum": i.checksum,
                    "iocs": i.iocs,
                    "metadata": limited_metadata,
                    "resume_from": i.resume_from,
                    "etag": i.etag,
                    "last_modified": i.last_modified,
                })
            
            data = {
                "id": job.id,
                "name": job.name,
                "status": job.status.value,
                "created_at": job.created_at,
                "completed_at": job.completed_at,
                "total_size": job.total_size,
                "downloaded_size": job.downloaded_size,
                "options": job.options,
                "items": limited_items,
            }
            
            json_str = json.dumps(data, indent=2)
            # Check size limit
            if len(json_str.encode()) > MAX_JOB_METADATA_SIZE:
                logger.warning(f"Job metadata for {job.id} exceeds size limit, truncating")
                # Remove some items if too large
                data["items"] = limited_items[:len(limited_items)//2]
                json_str = json.dumps(data, indent=2)
            
            meta_file.write_text(json_str)
        except Exception as e:
            logger.error(f"Failed to save job metadata: {e}")
    
    def shutdown(self, wait: bool = True) -> None:
        """Shutdown the download manager."""
        self._running = False
        self._shutdown_event.set()
        # Wait for active downloads to finish or timeout
        try:
            self.executor.shutdown(wait=wait)
        except Exception:
            pass
        # Close all sessions
        try:
            from session import close_all_sessions as _close
            _close()
        except Exception:
            pass
        # Clear jobs to free memory
        with self._lock:
            self.jobs.clear()
            self._job_weakrefs.clear()


# ── Async Download Support ──────────────────────────────────────────────

async def async_download(
    url: str,
    output_path: Path,
    session: aiohttp.ClientSession | None = None,
    proxy: str | None = None,
    timeout: int = 120,
    chunk_size: int = 8192,
    progress_callback: Callable[[int, int], None] | None = None,
) -> Dict[str, Any]:
    """Async download with progress tracking.

    Args:
        url: Absolute URL to fetch.
        output_path: Destination file path. Parent dirs are created.
        session: Optional pre-built aiohttp session. When omitted one is
            created and closed automatically.
        proxy: Optional proxy URL passed through to aiohttp.
        timeout: Total timeout in seconds.
        chunk_size: Read granularity in bytes.
        progress_callback: Optional callable invoked as
            ``callback(downloaded_bytes, total_bytes)`` after every chunk.
            ``total_bytes`` is ``0`` when the server omits ``Content-Length``.

    Returns:
        Dict with ``success`` plus either ``path``/``size``/``checksum`` or an
        ``error`` message. Never raises for network or filesystem failures.
    """
    close_session = False
    if session is None:
        connector = aiohttp.TCPConnector(limit=10)
        session = aiohttp.ClientSession(connector=connector)
        close_session = True

    try:
        async with session.get(url, proxy=proxy, timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
            if resp.status != 200:
                return {"success": False, "error": f"HTTP {resp.status}"}

            content_length = resp.headers.get('Content-Length')
            try:
                total = int(content_length) if content_length else 0
            except (TypeError, ValueError):
                # Malformed Content-Length header - fall back to unknown size.
                total = 0

            output_path.parent.mkdir(parents=True, exist_ok=True)

            hasher = hashlib.sha256()
            downloaded = 0

            async with aiofiles.open(output_path, 'wb') as f:
                async for chunk in resp.content.iter_chunked(chunk_size):
                    await f.write(chunk)
                    hasher.update(chunk)
                    downloaded += len(chunk)
                    if progress_callback is not None:
                        try:
                            progress_callback(downloaded, total)
                        except Exception as exc:  # never let a listener kill the transfer
                            logger.debug(f"progress_callback raised, ignoring: {exc}")

            return {
                "success": True,
                "path": str(output_path),
                "size": downloaded,
                "total": total,
                "checksum": hasher.hexdigest(),
            }
    except asyncio.TimeoutError:
        return {"success": False, "error": f"Timeout after {timeout}s"}
    except aiohttp.ClientError as e:
        return {"success": False, "error": f"Client error: {e}"}
    except Exception as e:
        logger.error(f"Async download failed for {url}: {e}")
        return {"success": False, "error": str(e)}
    finally:
        if close_session:
            try:
                await session.close()
            except Exception:
                pass


# ── Global Instance ────────────────────────────────────────────────────

download_manager = DownloadManager()
import atexit as _atexit

def _shutdown_download_manager() -> None:
    """Shutdown handler for download manager — suppress Event loop is closed during interpreter shutdown."""
    try:
        # suppress noisy RuntimeError: Event loop is closed on fast Ctrl+C
        import warnings as _w
        with _w.catch_warnings():
            _w.simplefilter("ignore")
            download_manager.shutdown(wait=False)
    except (RuntimeError, SystemExit, KeyboardInterrupt):
        pass
    except Exception:
        pass

_atexit.register(_shutdown_download_manager)