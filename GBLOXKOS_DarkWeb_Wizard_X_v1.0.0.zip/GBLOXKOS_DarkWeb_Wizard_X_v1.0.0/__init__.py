"""
GBLOXKOS AI DARKWEB WIZARD X - Elite Dark Web OSINT Platform
Copyright (c) 2026 GBLOXKOS LLC. All rights reserved.

This distribution is a *flat* top-level module set: every module imports its
siblings with plain absolute names (e.g. ``from llm_utils import ...``) rather
than relative ones. Consequently this file deliberately avoids importing the
siblings eagerly -- doing so would both fail at runtime and pull Streamlit into
the import path of any library-only consumer.

Use :func:`load` (or simply import the modules you need directly) to obtain the
module namespace lazily.
"""
from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any, Dict, Tuple

__version__ = "1.0.0"
__author__ = "GBLOXKOS"
__developer__ = "GBLOXKOS LLC"
__company__ = "GBLOXKOS LLC"
__license__ = "MIT"
__description__ = "Production-grade Dark Web OSINT with 7 specialized AI agents"

#: Canonical module order used by :func:`load`.
MODULES: Tuple[str, ...] = (
    "config",
    "session",
    "llm_utils",
    "llm",
    "hardening",
    "health",
    "scrape",
    "search",
    "download_manager",
    "agents",
    "ui",
)

if TYPE_CHECKING:  # pragma: no cover - import-time typing only
    from . import (  # noqa: F401
        agents,
        config,
        download_manager,
        hardening,
        health,
        llm,
        llm_utils,
        scrape,
        search,
        session,
        ui,
    )


def load(*names: str) -> Dict[str, Any]:
    """Import the requested submodules and return them keyed by name.

    Args:
        *names: Module names to import. Defaults to every module in
            :data:`MODULES`. Unknown names raise ``KeyError``.

    Returns:
        Mapping of module name to the imported module object.

    Raises:
        KeyError: If a requested name is not a known submodules.
        ImportError: If a requested module cannot be imported.
    """
    selected = names or MODULES
    unknown = [n for n in selected if n not in MODULES]
    if unknown:
        raise KeyError(f"Unknown submodule(s): {', '.join(sorted(unknown))}")
    return {name: importlib.import_module(name) for name in selected}


__all__ = [
    "MODULES",
    "load",
    "__version__",
    "__author__",
    "__developer__",
    "__company__",
    "__license__",
    "__description__",
]
