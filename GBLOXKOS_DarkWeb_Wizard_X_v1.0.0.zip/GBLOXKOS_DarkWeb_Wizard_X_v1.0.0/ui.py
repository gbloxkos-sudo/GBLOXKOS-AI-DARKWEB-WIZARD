import base64
import json
import streamlit as st
from datetime import datetime
from pathlib import Path
from typing import Dict, Any

from scrape import scrape_multiple
from search import get_search_results
from config import (
    CUSTOM_API_BASE_URL, CUSTOM_API_KEY, CUSTOM_API_MODEL,
    OPENAI_API_KEY, ANTHROPIC_API_KEY, GOOGLE_API_KEY,
    OPENROUTER_API_KEY, OLLAMA_BASE_URL, LLAMA_CPP_BASE_URL,
)
from llm_utils import BufferedStreamingHandler, get_model_choices, get_model_display_names, clear_model_cache
from llm import (
    get_llm, refine_query, filter_results, generate_summary, PRESET_PROMPTS,
    answer_followup, suggest_pivots, build_followup_context,
)
from langchain_core.messages import HumanMessage, AIMessage
from health import check_llm_health, check_search_engines, check_tor_proxy
from download_manager import download_manager, DownloadStatus
from agents import (
    get_orchestrator, get_all_agents, AgentType, AgentStatus,
    InvestigationPlan, AgentTask,
)
from hardening import security, polish
import html as html_module

# Module-level constants
MAX_CHAT_HISTORY = 100
MAX_ASSISTANT_CONTEXT_SIZE = 50
MAX_SESSION_STATE_KEYS = 200


st.set_page_config(
    page_title="GBLOXKOS AI DARKWEB WIZARD X",
    page_icon="🧙‍♂️",
    initial_sidebar_state="expanded",
    layout="wide",
)


def _init_session_state() -> None:
    """Initialize session state with defaults and cleanup old keys."""
    defaults = {
        "assistant_chat": [],
        "assistant_context": {"artifacts": {}, "investigations": [], "downloads": []},
        "assistant_mode": "autonomous",
        "chat_history": [],
        "pivot_suggestions": [],
        "active_investigation": None,
        "loaded_agent_investigation": None,
        "orchestrator_instance": None,
    }
    
    for key, default_value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = default_value
    
    # Cleanup old session state keys if too many
    if len(st.session_state) > MAX_SESSION_STATE_KEYS:
        keys_to_remove = list(st.session_state.keys())[:-MAX_SESSION_STATE_KEYS]
        for k in keys_to_remove:
            if k not in defaults:
                st.session_state.pop(k, None)
    
    # Limit chat history
    if len(st.session_state.get("chat_history", [])) > MAX_CHAT_HISTORY:
        st.session_state["chat_history"] = st.session_state["chat_history"][-MAX_CHAT_HISTORY:]
    
    # Limit assistant context
    ctx = st.session_state.get("assistant_context", {})
    if isinstance(ctx, dict):
        for k in ("artifacts", "investigations", "downloads"):
            if k in ctx and isinstance(ctx[k], list) and len(ctx[k]) > MAX_ASSISTANT_CONTEXT_SIZE:
                ctx[k] = ctx[k][-MAX_ASSISTANT_CONTEXT_SIZE:]


_init_session_state()


def _render_pipeline_error(stage: str, err: Exception) -> None:
    # Log to console/file for professional observability
    import logging as _logging
    _logging.getLogger(__name__).error(f"Pipeline error at stage '{stage}': {err}", exc_info=err)
    message = str(err).strip() or err.__class__.__name__
    lower_msg = message.lower()
    hints = [
        "- Confirm the relevant API key is set in your `.env` or shell before launching Streamlit.",
        "- Keys copied from dashboards often include hidden spaces; re-copy if authentication keeps failing.",
        "- Restart the app after updating environment variables so the new values are picked up.",
    ]

    if any(token in lower_msg for token in ("anthropic", "x-api-key", "invalid api key", "authentication")):
        hints.insert(0, "- Claude/Anthropic models require a valid `ANTHROPIC_API_KEY`.")
    elif "openrouter" in lower_msg or "user not found" in lower_msg or "code: 401" in lower_msg:
        hints.insert(0, "- OpenRouter 401/User not found usually means the API key is invalid/expired or has leading/trailing characters.")
        hints.insert(1, "- Set `OPENROUTER_API_KEY` without extra spaces and verify the key is active in your OpenRouter account.")
        hints.insert(2, "- Keep `OPENROUTER_BASE_URL` as `https://openrouter.ai/api/v1` unless you intentionally use a custom gateway.")
    elif "openai" in lower_msg or "gpt" in lower_msg:
        hints.insert(0, "- OpenAI models require `OPENAI_API_KEY` with access to the chosen model.")
    elif "google" in lower_msg or "gemini" in lower_msg:
        hints.insert(0, "- Google Gemini models need `GOOGLE_API_KEY` or Application Default Credentials.")

    st.error(
        "Failed to {}.\n\nError: {}\n\n{}".format(
            stage,
            message,
            "\n".join(hints),
        )
    )
    st.stop()


INVESTIGATIONS_DIR = Path("investigations")
AGENT_INVESTIGATIONS_DIR = Path("agent_investigations")


def save_investigation(query: str, refined_query: str, model: str, preset_label: str, sources: list, summary: str) -> str:
    INVESTIGATIONS_DIR.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = f"investigation_{timestamp}.json"
    data = {
        "timestamp": datetime.now().isoformat(),
        "query": query,
        "refined_query": refined_query,
        "model": model,
        "preset": preset_label,
        "sources": sources,
        "summary": summary,
    }
    (INVESTIGATIONS_DIR / fname).write_text(json.dumps(data, indent=2))
    return fname


def save_agent_investigation(plan: InvestigationPlan, results: Dict, synthesis: Dict) -> str:
    AGENT_INVESTIGATIONS_DIR.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = f"agent_investigation_{timestamp}.json"
    data = {
        "timestamp": datetime.now().isoformat(),
        "plan_id": plan.id,
        "objective": plan.objective,
        "tasks": [
            {
                "id": t.id,
                "agent_type": t.agent_type.value,
                "objective": t.objective,
                "parameters": t.parameters,
                "status": t.status.value,
                "result": str(t.result)[:5000] if t.result else None,
                "error": t.error,
            }
            for t in plan.tasks
        ],
        "results": {k: str(v)[:10000] for k, v in results.items()},
        "synthesis": synthesis,
    }
    (AGENT_INVESTIGATIONS_DIR / fname).write_text(json.dumps(data, indent=2, default=str))
    return fname


def load_investigations() -> list:
    if not INVESTIGATIONS_DIR.exists():
        return []
    files = sorted(INVESTIGATIONS_DIR.glob("investigation_*.json"), reverse=True)
    investigations = []
    for f in files:
        try:
            data = json.loads(f.read_text())
            data["_filename"] = f.name
            investigations.append(data)
        except Exception:
            continue
    return investigations


def load_agent_investigations() -> list:
    if not AGENT_INVESTIGATIONS_DIR.exists():
        return []
    files = sorted(AGENT_INVESTIGATIONS_DIR.glob("agent_investigation_*.json"), reverse=True)
    investigations = []
    for f in files:
        try:
            data = json.loads(f.read_text())
            data["_filename"] = f.name
            investigations.append(data)
        except Exception:
            continue
    return investigations


@st.cache_data(ttl=45, show_spinner=False)
def cached_search_results(refined_query: str, threads: int):
    # stable cache key, avoid hashing unhashable dicts/lists in args; short TTL avoids caching 0-result freezes
    res = get_search_results(refined_query.replace(" ", "+"), max_workers=max(1, min(int(threads), 16)))
    # do not cache empty results long - bypass by clearing if empty
    if not res:
        # will be cached for only 45s due to ttl, but also log
        import logging as _lg
        _lg.getLogger(__name__).warning(f"Search returned 0 results for '{refined_query}' - fallback will be used in UI")
    return res

@st.cache_data(ttl=200, show_spinner=False, hash_funcs={list: lambda x: hash(tuple(sorted(str(d) for d in x)))})
def cached_scrape_multiple(filtered: list, threads: int):
    # copy to avoid mutating cached input + make hashable for Streamlit cache
    safe = [dict(item) for item in filtered] if isinstance(filtered, list) else filtered
    return scrape_multiple(safe, max_workers=max(1, min(int(threads), 16)))


st.markdown(
    """
    <style>
    .aStyle { font-size: 18px; font-weight: bold; padding: 5px; padding-left: 0px; text-align: left; }
    .colHeight { max-height: 40vh; overflow-y: auto; text-align: center; }
    .pTitle { font-weight: bold; color: #FF4B4B; margin-bottom: 0.5em; }
    .agent-card { border: 1px solid #444; border-radius: 8px; padding: 1rem; margin: 0.5rem 0; background: #1e1e1e; }
    .agent-active { border-color: #FF4B4B; box-shadow: 0 0 10px rgba(255,75,75,0.3); }
    .metric-card { background: #262730; border-radius: 8px; padding: 1rem; text-align: center; }
    .metric-value { font-size: 2rem; font-weight: bold; color: #FF4B4B; }
    .metric-label { font-size: 0.875rem; color: #888; }
    .status-running { color: #FF4B4B; font-weight: bold; }
    .status-complete { color: #00D4AA; font-weight: bold; }
    .status-failed { color: #FF6B6B; font-weight: bold; }
    .download-btn { background: #FF4B4B; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; }
    .download-btn:hover { background: #ff6b6b; }
    .tab-content { padding: 1rem 0; }
    .stTabs [data-baseweb="tab-list"] { gap: 8px; }
    .stTabs [data-baseweb="tab"] { height: 50px; padding: 0 24px; background: #262730; border-radius: 8px 8px 0 0; }
    .stTabs [aria-selected="true"] { background: #FF4B4B !important; color: white !important; }
    </style>""",
    unsafe_allow_html=True,
)


st.sidebar.title("GBLOXKOS AI DARKWEB WIZARD X")
st.sidebar.caption("🧙‍♂️ AI DARKWEB WIZARD X — by GBLOXKOS")
st.sidebar.markdown("""*Elite Dark Web OSINT • 7 Never-Seen-Before AI Agents • Self-Healing • Self-Learning*\n\nMade by [Apurv Singh Gautam](https://www.linkedin.com/in/apurvsinghgautam/) — Rebranded for **GBLOXKOS**""")
st.sidebar.subheader("Settings")

def _env_is_set(value) -> bool:
    return bool(value and str(value).strip() and "your_" not in str(value))

if "custom_api_url" not in st.session_state:
    st.session_state["custom_api_url"] = CUSTOM_API_BASE_URL or ""
if "custom_api_key" not in st.session_state:
    st.session_state["custom_api_key"] = CUSTOM_API_KEY or ""
if "custom_api_model" not in st.session_state:
    st.session_state["custom_api_model"] = CUSTOM_API_MODEL or ""

# Update config module values from session state — only clear cache when values actually changed (prevents freeze)
import config as _config_module
_new_custom_url = st.session_state["custom_api_url"].strip() or None
_new_custom_key = st.session_state["custom_api_key"].strip() or None
_new_custom_model = st.session_state["custom_api_model"].strip() or None
if (_new_custom_url != _config_module.CUSTOM_API_BASE_URL or
    _new_custom_key != _config_module.CUSTOM_API_KEY or
    _new_custom_model != _config_module.CUSTOM_API_MODEL):
    _config_module.CUSTOM_API_BASE_URL = _new_custom_url
    _config_module.CUSTOM_API_KEY = _new_custom_key
    _config_module.CUSTOM_API_MODEL = _new_custom_model
    clear_model_cache()
else:
    # still sync without clearing
    _config_module.CUSTOM_API_BASE_URL = _new_custom_url
    _config_module.CUSTOM_API_KEY = _new_custom_key
    _config_module.CUSTOM_API_MODEL = _new_custom_model

@st.cache_data(ttl=30, show_spinner=False)
def _cached_model_choices():
    return get_model_choices()

@st.cache_data(ttl=30, show_spinner=False)
def _cached_model_display(names_tuple):
    return get_model_display_names(list(names_tuple))

try:
    model_options = _cached_model_choices()
except Exception:
    model_options = get_model_choices()
try:
    model_display_names = _cached_model_display(tuple(model_options))
except Exception:
    model_display_names = get_model_display_names(model_options)
default_model_index = (
    next((idx for idx, name in enumerate(model_options) if "ollama" in model_display_names.get(name, "").lower()), 0)
    if model_options else 0
)
# fallback to gpt-4o if ollama not found (cloud)
if default_model_index == 0 and model_options:
    _gpt_idx = next((idx for idx, name in enumerate(model_options) if name.lower() in ("gpt4o", "gpt-4o")), None)
    if _gpt_idx is not None and not any("ollama" in model_display_names.get(n, "").lower() for n in model_options):
        default_model_index = _gpt_idx

if not model_options:
    st.sidebar.error(
        "⛔ **No LLM models available.**\n\n"
        "No API keys or local providers are configured. "
        "Set at least one in your `.env` file and restart GBLOXKOS AI DARKWEB WIZARD X.\n\n"
        "See **Provider Configuration** below for details."
    )
    st.stop()

model = st.sidebar.selectbox(
    "Select LLM Model",
    model_options,
    format_func=lambda m: model_display_names.get(m, m),
    index=default_model_index,
    key="model_select",
)
_known_cloud = {"gpt4o", "gpt-4o", "gpt-4.1", "gpt-4o-mini", "gpt-3.5-turbo", "claude-3-5-sonnet-latest", "claude-3-5-haiku-latest", "claude-3-opus-latest", "gemini-2.5-flash", "gemini-2.5-pro", "gemini-1.5-flash", "gemini-1.5-pro", "qwen3-80b-openrouter", "llama-3.3-70b-openrouter", "gpt-oss-120b-openrouter", "nemotron-nano-9b-openrouter", "deepseek-chat-openrouter", "llama3.1"}
if any(name.lower() not in _known_cloud for name in model_options):
    st.sidebar.caption("🔵 Locally detected Ollama/llama.cpp models are automatically added to this list.")
# Pro guard: warn if embedding model somehow slipped through
if model and "embed" in model.lower():
    st.sidebar.warning(f"⚠️ `{model}` looks like an embedding model — it cannot chat. Pick a chat model (e.g. qwen2.5 or llama-3.2).")
    st.sidebar.info("Filtered embedding models automatically. If you see this, restart the app.")

with st.sidebar.expander("🔌 Custom API Provider"):
    st.text_input("Base URL", key="custom_api_url", placeholder="https://api.groq.com/openai/v1", help="Base URL for any OpenAI-compatible API (Groq, Mistral, LM Studio, etc.)")
    st.text_input("API Key", key="custom_api_key", type="password", help="API key for the custom provider (leave blank if not required)")
    st.text_input("Model Name", key="custom_api_model", placeholder="llama-3.3-70b-versatile", help="Model to use. Required if the provider doesn't expose /v1/models for auto-discovery.")

threads = st.sidebar.slider("Scraping Threads", 1, 16, 4, key="thread_slider")
max_results = st.sidebar.slider("Max Results to Filter", 10, 100, 50, key="max_results_slider", help="Cap the number of raw search results passed to the LLM filter step.")
max_scrape = st.sidebar.slider("Max Pages to Scrape", 3, 20, 10, key="max_scrape_slider", help="Cap the number of filtered results that get scraped for content.")

st.sidebar.divider()
st.sidebar.subheader("Provider Configuration")
_providers = [
    ("OpenAI", OPENAI_API_KEY, True),
    ("Anthropic", ANTHROPIC_API_KEY, True),
    ("Google", GOOGLE_API_KEY, True),
    ("OpenRouter", OPENROUTER_API_KEY, True),
    ("Ollama", OLLAMA_BASE_URL, False),
    ("llama.cpp", LLAMA_CPP_BASE_URL, False),
]
for name, value, is_cloud in _providers:
    if _env_is_set(value):
        st.sidebar.markdown(f"&ensp;✅ **{name}** — configured")
    elif is_cloud:
        st.sidebar.markdown(f"&ensp;⚠️ **{name}** — API key not set")
    else:
        st.sidebar.markdown(f"&ensp;🔵 **{name}** — not configured *(optional)*")

with st.sidebar.expander("⚙️ Prompt Settings"):
    preset_options = {
        "🔍 Dark Web Threat Intel": "threat_intel",
        "🦠 Ransomware / Malware Focus": "ransomware_malware",
        "👤 Personal / Identity Investigation": "personal_identity",
        "🏢 Corporate Espionage / Data Leaks": "corporate_espionage",
    }
    preset_placeholders = {
        "threat_intel": "e.g. Pay extra attention to cryptocurrency wallet addresses and exchange names.",
        "ransomware_malware": "e.g. Highlight any references to double-extortion tactics or known ransomware-as-a-service affiliates.",
        "personal_identity": "e.g. Flag any passport or government ID numbers and note which country they appear to be from.",
        "corporate_espionage": "e.g. Prioritize any mentions of source code repositories, API keys, or internal Slack/email dumps.",
    }
    selected_preset_label = st.selectbox("Research Domain", list(preset_options.keys()), key="preset_select")
    selected_preset = preset_options[selected_preset_label]
    st.text_area("System Prompt", value=PRESET_PROMPTS[selected_preset].strip(), height=200, disabled=True, key="system_prompt_display")
    custom_instructions = st.text_area("Custom Instructions (optional)", placeholder=preset_placeholders[selected_preset], height=100, key="custom_instructions")

st.sidebar.divider()
st.sidebar.subheader("Health Checks")

if st.sidebar.button("🔌 Check LLM Connection", use_container_width=True):
    with st.sidebar:
        with st.spinner(f"Testing {model}..."):
            result = check_llm_health(model)
        if result["status"] == "up":
            st.sidebar.success(f"✅ **{result['provider']}** — Connected ({result['latency_ms']}ms)")
        else:
            st.sidebar.error(f"❌ **{result['provider']}** — Failed\n\n{result['error']}")

if st.sidebar.button("🔍 Check Search Engines", use_container_width=True):
    with st.sidebar:
        with st.spinner("Checking Tor proxy..."):
            tor_result = check_tor_proxy()
        if tor_result["status"] == "down":
            st.sidebar.error(f"❌ **Tor Proxy** — Not reachable\n\n{tor_result['error']}\n\nEnsure Tor is running: `sudo systemctl start tor`")
        else:
            st.sidebar.success(f"✅ **Tor Proxy** — Connected ({tor_result['latency_ms']}ms)")
            with st.spinner("Pinging 16 search engines via Tor..."):
                engine_results = check_search_engines()
            up_count = sum(1 for r in engine_results if r["status"] == "up")
            total = len(engine_results)
            if up_count == total:
                st.sidebar.success(f"✅ **All {total} engines reachable**")
            elif up_count > 0:
                st.sidebar.warning(f"⚠️ **{up_count}/{total} engines reachable**")
            else:
                st.sidebar.error(f"❌ **0/{total} engines reachable**")
            for r in engine_results:
                if r["status"] == "up":
                    st.sidebar.markdown(f"&ensp;🟢 **{r['name']}** — {r['latency_ms']}ms")
                else:
                    st.sidebar.markdown(f"&ensp;🔴 **{r['name']}** — {r['error']}")

st.sidebar.divider()
st.sidebar.subheader("📂 Past Investigations")
saved_investigations = load_investigations()
if saved_investigations:
    inv_labels = [f"{inv['_filename'].replace('investigation_','').replace('.json','')} — {inv['query'][:40]}" for inv in saved_investigations]
    selected_inv_label = st.sidebar.selectbox("Load investigation", ["(none)"] + inv_labels, key="inv_select")
    if selected_inv_label != "(none)":
        selected_inv_idx = inv_labels.index(selected_inv_label)
        if st.sidebar.button("Load", use_container_width=True, key="load_inv_btn"):
            _saved = saved_investigations[selected_inv_idx]
            _saved_preset = _saved.get("preset", "threat_intel")
            _preset_key = "threat_intel"
            _preset_options_map = {
                "threat_intel": "threat_intel",
                "ransomware_malware": "ransomware_malware",
                "personal_identity": "personal_identity",
                "corporate_espionage": "corporate_espionage",
            }
            if _saved_preset in _preset_options_map:
                _preset_key = _saved_preset
            else:
                _label_to_key = {
                    "\U0001f50d Dark Web Threat Intel": "threat_intel",
                    "\U0001f9a0 Ransomware / Malware Focus": "ransomware_malware",
                    "\U0001f464 Personal / Identity Investigation": "personal_identity",
                    "\U0001f3e2 Corporate Espionage / Data Leaks": "corporate_espionage",
                }
                _preset_key = _label_to_key.get(_saved_preset, "threat_intel")
            st.session_state["active_investigation"] = {
                "query": _saved.get("query", ""),
                "refined": _saved.get("refined_query", ""),
                "model": _saved.get("model", ""),
                "preset": _preset_key,
                "preset_label": _saved.get("preset", ""),
                "sources": _saved.get("sources", []),
                "scraped": None,
                "summary": _saved.get("summary", ""),
                "results_count": len(_saved.get("sources", [])),
                "timestamp": _saved.get("timestamp", ""),
            }
            st.session_state["chat_history"] = []
            st.session_state["pivot_suggestions"] = []
            st.rerun()
else:
    st.sidebar.caption("No saved investigations yet.")

st.sidebar.divider()
st.sidebar.subheader("🤖 Agent Investigations")
agent_investigations = load_agent_investigations()
if agent_investigations:
    agent_inv_labels = [f"{inv['_filename'].replace('agent_investigation_','').replace('.json','')} — {inv['objective'][:40]}" for inv in agent_investigations]
    selected_agent_inv = st.sidebar.selectbox("Load agent investigation", ["(none)"] + agent_inv_labels, key="agent_inv_select")
    if selected_agent_inv != "(none)":
        if st.sidebar.button("📂 Load Agent Investigation", use_container_width=True, key="load_agent_inv_btn"):
            _saved = agent_investigations[agent_inv_labels.index(selected_agent_inv)]
            st.session_state["loaded_agent_investigation"] = _saved
            st.rerun()
else:
    st.sidebar.caption("No agent investigations yet.")


_, logo_col, _ = st.columns([1, 3, 1])
with logo_col:
    st.markdown("""
    <div style="text-align: center; padding: 1.5rem 0;">
        <div style="font-size: 2.5rem; font-weight: 800; color: #FF4B4B; letter-spacing: -0.02em; line-height: 1.2;">
            GBLOXKOS AI DARKWEB WIZARD X
        </div>
        <div style="font-size: 1.1rem; color: #888; margin-top: 0.5rem; font-weight: 400;">
            Elite Dark Web OSINT Wizard
        </div>
        <div style="margin-top: 1rem; padding: 0.5rem; background: linear-gradient(90deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); border-radius: 8px; border: 1px solid #FF4B4B;">
            <span style="color: #FF4B4B; font-weight: 600;">◆</span>
            <span style="color: #aaa; margin: 0 0.5rem;">7 Specialized AI Agents</span>
            <span style="color: #FF4B4B; font-weight: 600;">◆</span>
            <span style="color: #aaa; margin: 0 0.5rem;">Self-Healing</span>
            <span style="color: #FF4B4B; font-weight: 600;">◆</span>
            <span style="color: #aaa; margin: 0 0.5rem;">Self-Learning</span>
            <span style="color: #FF4B4B; font-weight: 600;">◆</span>
        </div>
    </div>
    """, unsafe_allow_html=True)
    # Optional: Show logo if exists
    try:
        st.image(".github/assets/gbloxkos_logo.png", width=280)
    except Exception:
        pass

st.markdown("<hr style='margin: 1rem 0; border: none; border-top: 1px solid #333;'>", unsafe_allow_html=True)


tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "🔍 Classic Investigation",
    "🤖 AI Agent Orchestrator",
    "🧠 AI Assistant Pro",
    "📥 Download Manager",
    "🛡️ Security & Analytics"
])


with tab1:
    with st.form("search_form", clear_on_submit=True):
        col_input, col_button = st.columns([10, 1])
        query = col_input.text_input("Enter Dark Web Search Query", placeholder="Enter Dark Web Search Query", label_visibility="collapsed", key="query_input")
        run_button = col_button.form_submit_button("Run")

    status_slot = st.empty()
    _stat_cols = st.columns(3)
    p1, p2, p3 = [col.empty() for col in _stat_cols]
    notes_placeholder = st.empty()
    sources_placeholder = st.empty()
    findings_placeholder = st.empty()

    def _render_investigation_body(inv):
        with st.expander("📋 Notes", expanded=False):
            st.markdown(f"**Refined Query:** `{inv.get('refined', '')}`")
            st.markdown(f"**Model:** `{inv.get('model', '')}` &nbsp;&nbsp; **Domain:** {inv.get('preset_label') or inv.get('preset', '')}")
            _counts = f"**Sources:** {len(inv.get('sources', []))}"
            if inv.get("scraped"):
                _counts += f" &nbsp;&nbsp; **Scraped:** {len(inv['scraped'])}"
            st.markdown(_counts)
        sources = inv.get("sources", [])
        with st.expander(f"🔗 Sources ({len(sources)} results)", expanded=False):
            for i, item in enumerate(sources, 1):
                st.markdown(f"{i}. [{item.get('title', 'Untitled')}]({item.get('link', '')})")
        st.subheader(":red[🔎 Findings]", anchor=None, divider="gray")
        summary = inv.get("summary", "") or ""
        st.markdown(summary)
        if summary:
            now = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            b64 = base64.b64encode(summary.encode()).decode()
            href = f'<div class="aStyle">📥 <a href="data:file/markdown;base64,{b64}" download="summary_{now}.md">Download</a></div>'
            st.markdown(href, unsafe_allow_html=True)

    def _followup_history_messages(chat_history, max_turns=5):
        recent = chat_history[-(max_turns * 2):] if chat_history else []
        msgs = []
        for turn in recent:
            if turn.get("role") == "user":
                msgs.append(HumanMessage(content=turn.get("content", "")))
            else:
                msgs.append(AIMessage(content=turn.get("content", "")))
        return msgs

    def _render_chat_panel(inv):
        st.divider()
        st.subheader(":red[💬 Follow-up Chat]", anchor=None, divider="gray")
        pivots = st.session_state.get("pivot_suggestions", [])
        if pivots:
            st.caption("Suggested pivots — click to run as a new investigation:")
            pivot_cols = st.columns(len(pivots))
            for i, (col, pq) in enumerate(zip(pivot_cols, pivots, strict=True)):
                if col.button(f"🔎 {pq}", key=f"pivot_{i}", use_container_width=True):
                    st.session_state["pivot_query"] = pq
                    st.rerun()
        for turn in st.session_state.get("chat_history", []):
            with st.chat_message(turn.get("role", "assistant")):
                st.markdown(turn.get("content", ""))
        if st.session_state.get("chat_history"):
            if st.button("🧹 Clear chat", key="clear_chat"):
                st.session_state["chat_history"] = []
                st.rerun()
        followup = st.chat_input("Ask a follow-up about this investigation")
        if followup:
            with st.chat_message("user"):
                st.markdown(followup)
            context = build_followup_context(inv.get("query", ""), inv.get("refined", ""), inv.get("sources", []), inv.get("scraped"), inv.get("summary", ""))
            history = _followup_history_messages(st.session_state.get("chat_history", []))
            with st.chat_message("assistant"):
                answer_slot = st.empty()
                acc = {"text": ""}
                def _emit(chunk: str):
                    acc["text"] += chunk
                    answer_slot.markdown(acc["text"])
                try:
                    # robust model fallback for follow-up so AI ALWAYS answers
                    _fm = inv.get("model") or model
                    try:
                        f_llm = get_llm(_fm, callbacks=[BufferedStreamingHandler(ui_callback=_emit)])
                    except Exception:
                        from llm_utils import get_model_choices as _gmc2
                        _fb = (_gmc2()[0] if _gmc2() else _fm)
                        f_llm = get_llm(_fb, callbacks=[BufferedStreamingHandler(ui_callback=_emit)])
                    answer = answer_followup(f_llm, followup, context, history=history, preset=inv.get("preset", "threat_intel"), custom_instructions=inv.get("custom_instructions", ""))
                    if not acc["text"].strip() and answer:
                        acc["text"] = answer
                        answer_slot.markdown(answer)
                    if not acc["text"].strip():
                        acc["text"] = "I’m here — I didn’t get a streaming chunk but the fallback answer is ready. Please rephrase or check Health Checks if this persists."
                        answer_slot.markdown(acc["text"])
                except Exception as e:
                    # guaranteed fallback - never leave user hanging
                    acc["text"] = (
                        f"⚠️ Follow-up LLM was temporarily unavailable: `{e}`\n\n"
                        f"**Your question:** {followup}\n\n"
                        f"**From saved context (first 800 chars):**\n{context[:800]}\n\n"
                        f"Try again in a moment, or verify **Sidebar → Health Checks → Check LLM Connection** and that Ollama is running (`ollama serve`)."
                    )
                    answer_slot.markdown(acc["text"])
            st.session_state.setdefault("chat_history", [])
            st.session_state["chat_history"].append({"role": "user", "content": followup})
            st.session_state["chat_history"].append({"role": "assistant", "content": acc["text"]})

    _pivot_query = st.session_state.pop("pivot_query", None)
    _active_query = _pivot_query or query
    _do_run = bool(_active_query) and (run_button or _pivot_query is not None)

    if _do_run:
        query = _active_query
        st.session_state.pop("active_investigation", None)
        for k in ["refined", "results", "filtered", "scraped", "streamed_summary", "chat_history", "pivot_suggestions"]:
            st.session_state.pop(k, None)

        with status_slot.container(), st.spinner("🔄 Loading LLM..."):
            try:
                llm = get_llm(model)
            except Exception as e:
                _render_pipeline_error("load the selected LLM", e)

        with status_slot.container(), st.spinner("🔄 Refining query..."):
            try:
                st.session_state.refined = refine_query(llm, query)
            except Exception as e:
                _render_pipeline_error("refine the query", e)
        p1.container(border=True).markdown(f"<div class='colHeight'><p class='pTitle'>Refined Query</p><p>{html_module.escape(st.session_state.refined)}</p></div>", unsafe_allow_html=True)

        with status_slot.container(), st.spinner("🔍 Searching dark web..."):
            try:
                st.session_state.results = cached_search_results(st.session_state.refined, threads)
            except Exception as e:
                logger = __import__('logging').getLogger(__name__)
                logger.warning(f"Search failed: {e}")
                st.warning(f"Search encountered an issue: {e} — continuing with empty results, try a shorter query.")
                st.session_state.results = []
        if len(st.session_state.results) > max_results:
            st.session_state.results = st.session_state.results[:max_results]
        p2.container(border=True).markdown(f"<div class='colHeight'><p class='pTitle'>Search Results</p><p>{len(st.session_state.results)}</p></div>", unsafe_allow_html=True)

        with status_slot.container(), st.spinner("🗂️ Filtering results..."):
            try:
                st.session_state.filtered = filter_results(llm, st.session_state.refined, st.session_state.results)
            except Exception as e:
                logger = __import__('logging').getLogger(__name__)
                logger.warning(f"Filter failed, using heuristic fallback: {e}")
                # heuristic fallback guarantees pipeline never crashes
                st.session_state.filtered = st.session_state.results[:min(len(st.session_state.results), max_scrape)]
        if len(st.session_state.filtered) > max_scrape:
            st.session_state.filtered = st.session_state.filtered[:max_scrape]
        p3.container(border=True).markdown(f"<div class='colHeight'><p class='pTitle'>Filtered Results</p><p>{len(st.session_state.filtered)}</p></div>", unsafe_allow_html=True)

        with status_slot.container():
            with st.spinner("📜 Scraping content..."):
                try:
                    st.session_state.scraped = cached_scrape_multiple(st.session_state.filtered, threads)
                except Exception as e:
                    logger = __import__('logging').getLogger(__name__)
                    logger.warning(f"Scrape failed: {e}")
                    st.warning(f"Scrape encountered an issue: {e} — proceeding to summary with available data.")
                    st.session_state.scraped = {item.get('link',''): item.get('title','') for item in st.session_state.filtered}

        st.session_state.streamed_summary = ""
        with findings_placeholder.container():
            st.subheader(":red[🔎 Findings]", anchor=None, divider="gray")
            summary_slot = st.empty()

        # FIX: no streaming callback touching Streamlit from background thread (caused missing ScriptRunContext warnings + Event loop closed)
        # Use non-streaming LLM for reliable, thread-safe generation + fallback if LLM slow
        # Gracefully handle Ctrl+C / Event loop closed during shutdown (your logs: interrupt exiting cleanly)
        with status_slot.container():
            with st.spinner("✍️ Generating summary (local 3B ~15s, fallback at 45s)..."):
                summary_text = ""
                try:
                    # use non-streaming for stability; timeout handled inside generate_summary fallback
                    summary_llm = get_llm(model, streaming=False)
                    summary_text = generate_summary(summary_llm, query, st.session_state.scraped, preset=selected_preset, custom_instructions=custom_instructions)
                except (KeyboardInterrupt, SystemExit):
                    summary_text = f"**Investigation interrupted by user (Ctrl+C).**\n\nPartial results preserved: {len(st.session_state.scraped)} pages scraped. Re-run query `{query}` to resume."
                except RuntimeError as e:
                    # catches Event loop is closed / cannot schedule new futures after interpreter shutdown
                    if "event loop" in str(e).lower() or "interpreter shutdown" in str(e).lower() or "cannot schedule" in str(e).lower():
                        summary_text = f"**Summary interrupted by shutdown.**\n\nScraped {len(st.session_state.scraped)} pages — showing raw content:\n\n" + "\n\n".join(f"**{u}**\n{c[:1500]}" for u,c in list(st.session_state.scraped.items())[:3])
                    else:
                        raise
                except Exception as e:
                    import logging as _lg
                    _lg.getLogger(__name__).warning(f"Summary generation exception: {e}")
                    summary_text = f"**Summary generation encountered an issue:** `{e}`\n\nShowing raw scraped content instead."
                    for url, content in (st.session_state.scraped or {}).items():
                        if content:
                            summary_text += f"\n\n---\n**{url}**\n{content[:2000]}"
                    if not (st.session_state.scraped):
                        summary_text += "\n\n*No scraped content available — search returned 0 results. Try a shorter 2-3 word query like `lockbit ransom` or `fullz shop`.*"
                if not summary_text:
                    summary_text = "\n\n".join(f"**{u}**\n{c[:1500]}" for u,c in list(st.session_state.scraped.items())[:3]) or "*No content.*"

        # thread-safe single update on main thread
        st.session_state.streamed_summary = summary_text or st.session_state.streamed_summary
        summary_slot.markdown(st.session_state.streamed_summary)

        _fname = save_investigation(query=query, refined_query=st.session_state.refined, model=model, preset_label=selected_preset_label, sources=st.session_state.filtered, summary=st.session_state.streamed_summary)

        with notes_placeholder.container():
            with st.expander("📋 Notes", expanded=False):
                st.markdown(f"**Refined Query:** `{st.session_state.refined}`")
                st.markdown(f"**Model:** `{model}` &nbsp;&nbsp; **Domain:** {selected_preset_label}")
                st.markdown(f"**Results found:** {len(st.session_state.results)} &nbsp;&nbsp; **Filtered to:** {len(st.session_state.filtered)} &nbsp;&nbsp; **Scraped:** {len(st.session_state.scraped)}")

        with sources_placeholder.container():
            with st.expander(f"🔗 Sources ({len(st.session_state.filtered)} results)", expanded=False):
                for i, item in enumerate(st.session_state.filtered, 1):
                    title = item.get("title", "Untitled")
                    link = item.get("link", "")
                    st.markdown(f"{i}. [{title}]({link})")
                # Download Anything: one-click queue all filtered sources
                if st.button("📥 Download All Filtered Sources", key="dl_filtered", use_container_width=True):
                    try:
                        jid = download_manager.create_job(f"filtered_{datetime.now().strftime('%H%M%S')}", st.session_state.filtered, {"category": "investigation", "auto_extract": True})
                        download_manager.start_job(jid)
                        st.success(f"📥 Download job started: `{jid}` — check Download Manager tab")
                    except Exception as e:
                        st.error(f"Download failed: {e}")
                # Per-source quick download
                cols = st.columns(3)
                for idx, item in enumerate(st.session_state.filtered[:12]):
                    with cols[idx % 3]:
                        if st.button(f"⬇️ {item.get('title','Untitled')[:24]}", key=f"dl_one_{idx}", help=item.get('link','')):
                            try:
                                jid = download_manager.create_job(f"single_{idx}_{datetime.now().strftime('%H%M%S')}", [item], {"category": "single", "auto_extract": True})
                                download_manager.start_job(jid)
                                st.toast(f"Downloading {item.get('link','')} as {jid}")
                            except Exception as e:
                                st.error(str(e))

        with findings_placeholder.container():
            st.subheader(":red[🔎 Findings]", anchor=None, divider="gray")
            st.markdown(st.session_state.streamed_summary)
            now = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            fname = f"summary_{now}.md"
            b64 = base64.b64encode(st.session_state.streamed_summary.encode()).decode()
            href = f'<div class="aStyle">📥 <a href="data:file/markdown;base64,{b64}" download="{fname}">Download</a></div>'
            st.markdown(href, unsafe_allow_html=True)

        status_slot.success(f"✔️ Pipeline completed successfully! Investigation saved as `{_fname}`")

        st.session_state["active_investigation"] = {
            "query": query, "refined": st.session_state.refined, "model": model,
            "preset": selected_preset, "preset_label": selected_preset_label,
            "sources": st.session_state.filtered, "scraped": st.session_state.scraped,
            "summary": st.session_state.streamed_summary, "results_count": len(st.session_state.results),
            "custom_instructions": custom_instructions,
        }
        st.session_state["chat_history"] = []

        with st.spinner("💡 Suggesting pivots..."):
            try:
                # resilient: try selected model, fallback to first available chat model
                try:
                    _pivot_llm = get_llm(model, streaming=False)
                except Exception:
                    from llm_utils import get_model_choices as _gmc_p
                    _fb_p = (_gmc_p()[0] if _gmc_p() else model)
                    _pivot_llm = get_llm(_fb_p, streaming=False)
                st.session_state["pivot_suggestions"] = suggest_pivots(_pivot_llm, query, st.session_state.get("scraped"), preset=selected_preset)
            except Exception:
                st.session_state["pivot_suggestions"] = []

        _render_chat_panel(st.session_state["active_investigation"])

    elif st.session_state.get("active_investigation"):
        _inv = st.session_state["active_investigation"]
        _ts = _inv.get("timestamp")
        st.info(f"📂 **{_inv.get('query', '')}**" + (f" — {_ts[:16]}" if _ts else ""))
        _render_investigation_body(_inv)
        _render_chat_panel(_inv)


with tab2:
    st.header("🤖 AI Agent Orchestrator")
    st.markdown("**Autonomous multi-agent dark web OSINT investigations** — 7 specialized agents coordinate to deliver comprehensive intelligence.")

    agent_descriptions = {
        AgentType.RECONNAISSANCE: ("🔍 Reconnaissance", "Initial target discovery, surface mapping, onion service enumeration, hidden service discovery"),
        AgentType.THREAT_ACTOR_PROFILER: ("👤 Threat Actor Profiler", "Cybercrime attribution, alias mapping, TTP fingerprinting, affiliate network analysis"),
        AgentType.MALWARE_ANALYST: ("🦠 Malware Analyst", "Static analysis, C2 extraction, YARA/Sigma rule generation, malware family attribution"),
        AgentType.CRYPTO_TRACER: ("₿ Crypto Tracer", "Blockchain forensics, mixer analysis, chain-hopping detection, ransomware payment tracking"),
        AgentType.INFRASTRUCTURE_MAPPER: ("🌐 Infrastructure Mapper", "Hosting correlation, SSL cert analysis, CDN/WAF fingerprinting, bulletproof hosting ID"),
        AgentType.DATA_BROKER_HUNTER: ("💾 Data Broker Hunter", "Breach compilation tracking, credential market enumeration, PII supply chain mapping"),
        AgentType.OPSEC_AUDITOR: ("🔒 OpSec Auditor", "OpSec failure detection, deanonymization vectors, metadata leaks, correlation attacks"),
    }

    cols = st.columns(4)
    for i, (_agent_type, (label, desc)) in enumerate(agent_descriptions.items()):
        with cols[i % 4]:
            st.markdown(f'<div class="agent-card"><strong>{label}</strong><br><small>{desc}</small></div>', unsafe_allow_html=True)

    st.divider()

    col_obj, col_btn = st.columns([4, 1])
    with col_obj:
        agent_objective = st.text_area(
            "Investigation Objective",
            placeholder="Describe your investigation goal in natural language. Example: 'Map the infrastructure and threat actors behind the LockBit ransomware affiliate program, trace their crypto payments, and identify OpSec failures.'",
            height=100,
            key="agent_objective",
        )
    with col_btn:
        st.write("")
        st.write("")
        run_agent_investigation = st.button("🚀 Launch Multi-Agent Investigation", type="primary", use_container_width=True)

    agent_options = st.multiselect(
        "Select Agents (default: all)",
        options=[at.value for at in AgentType if at != AgentType.ORCHESTRATOR],
        default=[at.value for at in AgentType if at != AgentType.ORCHESTRATOR],
        format_func=lambda x: f"{agent_descriptions[AgentType(x)][0]} — {agent_descriptions[AgentType(x)][1]}",
        key="selected_agents",
    )
    selected_agent_types = [AgentType(at) for at in agent_options] if agent_options else [at for at in AgentType if at != AgentType.ORCHESTRATOR]

    col_adv1, col_adv2, col_adv3 = st.columns(3)
    with col_adv1:
        max_iterations = st.slider("Max Iterations per Task", 1, 10, 3, key="max_iterations")
    with col_adv2:
        enable_self_healing = st.checkbox("Enable Self-Healing", value=True, key="enable_self_healing")
    with col_adv3:
        enable_learning = st.checkbox("Enable Cross-Agent Learning", value=True, key="enable_learning")

    if run_agent_investigation and agent_objective:
        _plan_ref = {"plan": None}
        _orch_ref = {"orchestrator": None}
        orchestrator = get_orchestrator(model)
        _orch_ref["orchestrator"] = orchestrator
        for at in AgentType:
            if at != AgentType.ORCHESTRATOR:
                agent = orchestrator.agents.get(at)
                if agent:
                    agent.self_healing_enabled = enable_self_healing
                    agent.learning_enabled = enable_learning
                    agent.current_task = None

        progress_container = st.container()
        status_container = st.container()
        results_container = st.container()

        with progress_container:
            st.subheader("Investigation Progress")
            progress_bar = st.progress(0)
            status_text = st.empty()
            agent_status_cols = st.columns(len(selected_agent_types))
            agent_status_indicators = {at: agent_status_cols[i].empty() for i, at in enumerate(selected_agent_types)}

        def update_progress(task: AgentTask, _result: Any):
            current_plan = _plan_ref["plan"]
            orch = _orch_ref["orchestrator"]
            if current_plan is None or orch is None:
                return
            completed = sum(1 for t in current_plan.tasks if t.status == AgentStatus.COMPLETED)
            total = len(current_plan.tasks)
            progress_bar.progress(completed / total if total > 0 else 0)
            status_text.info(f"Executing: **{task.agent_type.value}** — {task.objective[:80]}...")
            for at in selected_agent_types:
                agent = orch.agents.get(at)
                if agent and agent.current_task:
                    agent_status_indicators[at].markdown(f'<span class="status-running">{agent_descriptions[at][0]}</span>', unsafe_allow_html=True)
                elif agent and any(t.agent_type == at and t.status == AgentStatus.COMPLETED for t in current_plan.tasks):
                    agent_status_indicators[at].markdown(f'<span class="status-complete">{agent_descriptions[at][0]}</span>', unsafe_allow_html=True)
                elif agent and any(t.agent_type == at and t.status == AgentStatus.FAILED for t in current_plan.tasks):
                    agent_status_indicators[at].markdown(f'<span class="status-failed">{agent_descriptions[at][0]}</span>', unsafe_allow_html=True)
                else:
                    agent_status_indicators[at].markdown(f'{agent_descriptions[at][0]}')

        with status_container:
            with st.spinner("Orchestrator planning investigation..."):
                plan = orchestrator.create_investigation_plan(agent_objective, {"selected_agents": selected_agent_types})

            plan.tasks = [t for t in plan.tasks if t.agent_type.value in selected_agent_types]
            for t in plan.tasks:
                t.max_iterations = max_iterations

            _plan_ref["plan"] = plan
            st.info(f"Plan created: **{len(plan.tasks)} tasks** across **{len(selected_agent_types)} agents**")

            with st.spinner("Executing multi-agent investigation..."):
                synthesis = orchestrator.execute_plan(plan, progress_callback=update_progress, context={"selected_agents": selected_agent_types})

        progress_bar.progress(1.0)
        status_text.success("✅ Investigation completed!")

        for at in selected_agent_types:
            agent = orchestrator.agents.get(at)
            if agent and any(t.agent_type == at and t.status == AgentStatus.COMPLETED for t in plan.tasks):
                agent_status_indicators[at].markdown(f'<span class="status-complete">{agent_descriptions[at][0]}</span>', unsafe_allow_html=True)

        agent_results = {t.agent_type.value: str(t.result)[:5000] if t.result else "" for t in plan.tasks}
        fname = save_agent_investigation(plan, agent_results, synthesis)
        st.success(f"💾 Investigation saved as `{fname}`")

        with results_container:
            st.subheader("📋 Executive Summary")
            st.markdown(synthesis.get("executive_summary", "No summary generated."))

            col_sum1, col_sum2 = st.columns(2)
            with col_sum1:
                st.metric("Key Findings", len(synthesis.get("key_findings", [])))
                st.metric("Artifacts Collected", sum(len(v) for v in synthesis.get("all_artifacts", {}).values()))
            with col_sum2:
                st.metric("Confidence", f"{synthesis.get('confidence', 0)*100:.0f}%")
                st.metric("Actionable Items", len(synthesis.get("actionable_intelligence", [])))

            st.divider()
            st.subheader("🔑 Key Findings")
            for finding in synthesis.get("key_findings", []):
                st.markdown(f"- {finding}")

            st.divider()
            st.subheader("🎯 Actionable Intelligence")
            for item in synthesis.get("actionable_intelligence", []):
                st.markdown(f"- {item}")

            st.divider()
            st.subheader("📦 All Artifacts")
            artifacts = synthesis.get("all_artifacts", {})
            for art_type, items in artifacts.items():
                if items:
                    with st.expander(f"{art_type.title()} ({len(items)})", expanded=False):
                        for item in items[:50]:
                            st.code(item, language=None)

            st.divider()
            st.subheader("🤖 Agent Performance")
            agent_metrics = synthesis.get("agent_metrics", {})
            for at in selected_agent_types:
                metrics = agent_metrics.get(at.value, {})
                with st.expander(f"{agent_descriptions[at][0]} Metrics", expanded=False):
                    mcols = st.columns(4)
                    mcols[0].metric("Tasks Completed", metrics.get("tasks_completed", 0))
                    mcols[1].metric("Tasks Failed", metrics.get("tasks_failed", 0))
                    mcols[2].metric("Artifacts Found", metrics.get("artifacts_discovered", 0))
                    mcols[3].metric("Queries Run", metrics.get("queries_executed", 0))

            st.divider()
            st.subheader("🔮 Recommended Next Steps")
            for step in synthesis.get("recommended_next_steps", []):
                st.markdown(f"- {step}")

            if synthesis.get("gaps"):
                st.divider()
                st.subheader("⚠️ Identified Gaps")
                for gap in synthesis.get("gaps", []):
                    st.warning(gap)

    elif st.session_state.get("loaded_agent_investigation"):
        inv = st.session_state["loaded_agent_investigation"]
        st.info(f"📂 **Loaded: {inv.get('objective', '')}**")
        synthesis = inv.get("synthesis", {})
        
        st.subheader("📋 Executive Summary")
        st.markdown(synthesis.get("executive_summary", "No summary."))
        
        st.divider()
        st.subheader("🔑 Key Findings")
        for finding in synthesis.get("key_findings", []):
            st.markdown(f"- {finding}")

        st.divider()
        st.subheader("📦 All Artifacts")
        artifacts = synthesis.get("all_artifacts", {})
        for art_type, items in artifacts.items():
            if items:
                with st.expander(f"{art_type.title()} ({len(items)})", expanded=False):
                    for item in items[:50]:
                        st.code(item, language=None)

        st.divider()
        st.subheader("🤖 Agent Performance")
        agent_metrics = synthesis.get("agent_metrics", {})
        for at_str, metrics in agent_metrics.items():
            at = AgentType(at_str) if at_str in [a.value for a in AgentType] else None
            label = agent_descriptions[at][0] if at else at_str
            with st.expander(f"{label} Metrics", expanded=False):
                mcols = st.columns(4)
                mcols[0].metric("Completed", metrics.get("tasks_completed", 0))
                mcols[1].metric("Failed", metrics.get("tasks_failed", 0))
                mcols[2].metric("Artifacts", metrics.get("artifacts_discovered", 0))
                mcols[3].metric("Queries", metrics.get("queries_executed", 0))


with tab3:
    st.header("🧠 AI Assistant Pro")
    st.markdown("**Super-advanced AI assistant** — Autonomous search, scrape, download, analyze, and execute any investigation task you describe.")

    if "assistant_chat" not in st.session_state:
        st.session_state.assistant_chat = []
    if "assistant_context" not in st.session_state:
        st.session_state.assistant_context = {"artifacts": {}, "investigations": [], "downloads": []}
    if "assistant_mode" not in st.session_state:
        st.session_state.assistant_mode = "autonomous"

    col_mode1, col_mode2, col_mode3 = st.columns(3)
    with col_mode1:
        if st.button("🤖 Autonomous Mode", use_container_width=True, type="primary" if st.session_state.assistant_mode == "autonomous" else "secondary"):
            st.session_state.assistant_mode = "autonomous"
            st.rerun()
    with col_mode2:
        if st.button("🔍 Search & Scrape", use_container_width=True, type="primary" if st.session_state.assistant_mode == "search" else "secondary"):
            st.session_state.assistant_mode = "search"
            st.rerun()
    with col_mode3:
        if st.button("📥 Download Focus", use_container_width=True, type="primary" if st.session_state.assistant_mode == "download" else "secondary"):
            st.session_state.assistant_mode = "download"
            st.rerun()

    st.caption(f"Current mode: **{st.session_state.assistant_mode.title()}**")

    st.divider()

    for msg in st.session_state.assistant_chat:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg.get("artifacts"):
                with st.expander("🔍 Artifacts Found", expanded=False):
                    for k, v in msg["artifacts"].items():
                        if v:
                            st.markdown(f"**{k}:** {', '.join(v[:20])}")
            if msg.get("downloads"):
                with st.expander("📥 Downloads Initiated", expanded=False):
                    for d in msg["downloads"]:
                        st.markdown(f"- {d}")

    st.markdown("> **Safety:** This assistant is maximally helpful for *lawful* OSINT (threat intel, research, journalism, defense). It will not facilitate creation/distribution of malware, illegal hacking, or non-consensual data abuse. For sensitive requests it provides harm-reduction, legal alternatives, and will still deliver OSINT value within policy.")
    user_input = st.chat_input("Ask me to investigate, search, scrape, download, analyze anything... (e.g. 'download the pdf from http://...onion/file.pdf' or 'find and download ransomware leak tools')")

    # helper: parse any URLs the user typed for direct download intent
    def _extract_urls_from_text(text: str):
        import re
        # onion + clearweb http/https + bare onions
        url_re = re.compile(r'(https?://[^\s<>\"]+|[a-z2-7]{16,56}\.onion(?:/[^\s<>\"]*)?)', re.I)
        found = url_re.findall(text)
        normalized = []
        for u in found:
            if not u.startswith("http"):
                u = "http://" + u
            normalized.append(u)
        # dedup preserve order
        seen=set(); out=[]
        for u in normalized:
            low=u.lower().rstrip("/")
            if low not in seen:
                seen.add(low); out.append(u)
        return out
    def _is_download_intent(text: str) -> bool:
        t=text.lower()
        return any(k in t for k in ["download","fetch","grab","pull","archive","mirror","save","wget","curl","get me the file","get file"])

    if user_input:
        st.session_state.assistant_chat.append({"role": "user", "content": user_input})
        
        with st.chat_message("user"):
            st.markdown(user_input)

        with st.chat_message("assistant"):
            response_placeholder = st.empty()
            artifacts_placeholder = st.empty()
            downloads_placeholder = st.empty()
            
            response_buffer = {"text": ""}
            discovered_artifacts = {}
            initiated_downloads = []

            def emit_chunk(chunk: str):
                response_buffer["text"] += chunk
                response_placeholder.markdown(response_buffer["text"] + "▌")

            try:
                # Guarantee AI always answers - validate model with fallback
                try:
                    orchestrator = get_orchestrator(model)
                    all_agents = get_all_agents(model)
                except Exception as e:
                    # fallback to first available chat model
                    from llm_utils import get_model_choices as _gmc
                    fallback = (_gmc()[0] if _gmc() else "gpt4o")
                    orchestrator = get_orchestrator(fallback)
                    all_agents = get_all_agents(fallback)
                    emit_chunk(f"⚠️ Model `{model}` unavailable ({e}), switched to `{fallback}`.\n")

                for agent in all_agents.values():
                    agent.self_healing_enabled = True
                    agent.learning_enabled = True

                # --- Universal download intent: user explicitly pasted URLs ---
                direct_urls = _extract_urls_from_text(user_input)
                want_download = _is_download_intent(user_input)
                if want_download and direct_urls:
                    emit_chunk(f"📥 Detected **{len(direct_urls)}** URL(s) for download intent.\n")
                    urls_for_job = [{"link": u, "title": f"Assistant requested: {u[:60]}"} for u in direct_urls[:20]]
                    try:
                        job_id = download_manager.create_job(f"assistant_direct_{datetime.now().strftime('%H%M%S')}", urls_for_job, {"category": "assistant_direct", "auto_extract": True, "scan_malware": True})
                        download_manager.start_job(job_id)
                        initiated_downloads.append(job_id)
                        discovered_artifacts = {"direct_urls": direct_urls}
                        st.session_state.assistant_context["downloads"].append({"urls": direct_urls, "job": job_id, "time": datetime.now().isoformat()})
                        emit_chunk(f"✅ **Download job started:** `{job_id}` with {len(urls_for_job)} URL(s). Track in **📥 Download Manager** tab. Files are scanned and saved under `downloads/{job_id}/`.\n")
                        emit_chunk("> ⚠️ Only download content you have legal right to access. Malware/scripts are flagged but not executed.\n")
                    except Exception as e:
                        emit_chunk(f"❌ Failed to start download: {e}\n")
                # --- If download intent but no URLs yet: discover then download via agents ---
                elif want_download and not direct_urls and st.session_state.assistant_mode == "download":
                    # try artifacts -> sources -> search fallback
                    urls_to_download = []
                    if st.session_state.assistant_context.get("artifacts"):
                        for art_type, items in st.session_state.assistant_context["artifacts"].items():
                            for item in items or []:
                                if isinstance(item, str) and (".onion" in item or item.startswith("http")):
                                    link = item if item.startswith("http") else "http://"+item
                                    urls_to_download.append({"link": link, "title": f"{art_type}: {link[:50]}"})
                                    if len(urls_to_download) >= 20: break
                            if len(urls_to_download) >= 20: break
                    if st.session_state.get("active_investigation") and st.session_state["active_investigation"].get("sources") and not urls_to_download:
                        for s in st.session_state["active_investigation"]["sources"][:20]:
                            urls_to_download.append({"link": s.get("link",""), "title": s.get("title","Source")})
                    if not urls_to_download:
                        # last resort: run reconnaissance to discover URLs then auto-download top 10
                        emit_chunk("🔍 No cached URLs — running discovery to find downloadable targets...\n")
                        recon = all_agents[AgentType.RECONNAISSANCE]
                        task = AgentTask(id=str(__import__('uuid').uuid4()), agent_type=AgentType.RECONNAISSANCE, objective=user_input, parameters={"queries": [user_input], "max_results": 30})
                        result = recon.execute_task(task, st.session_state.assistant_context)
                        discovered_artifacts = result.get("artifacts", {})
                        st.session_state.assistant_context["artifacts"] = discovered_artifacts
                        for r in result.get("results", [])[:15]:
                            urls_to_download.append({"link": r.get("link",""), "title": r.get("title","Result")})
                    if urls_to_download:
                        with st.spinner("📥 Initiating downloads..."):
                            job_id = download_manager.create_job(f"assistant_download_{datetime.now().strftime('%H%M%S')}", urls_to_download[:20], {"category": "assistant_requested", "auto_extract": True, "scan_malware": True})
                            download_manager.start_job(job_id)
                            initiated_downloads.append(job_id)
                            st.session_state.assistant_context["downloads"].append({"job": job_id, "urls": [u["link"] for u in urls_to_download], "time": datetime.now().isoformat()})
                            emit_chunk(f"📥 **Started download job:** `{job_id}` with **{len(urls_to_download[:20])}** URLs\n")
                    else:
                        emit_chunk("ℹ️ No URLs available to download. Paste a direct link or run a search first.\n")

                elif st.session_state.assistant_mode == "autonomous":
                    try:
                        with st.spinner("🧠 Planning autonomous investigation..."):
                            plan = orchestrator.create_investigation_plan(user_input, st.session_state.assistant_context)
                        
                        with st.spinner("🤖 Executing multi-agent investigation (7 specialized agents)..."):
                            def progress_cb(task, _result):
                                emit_chunk(f"\n\n✅ **{task.agent_type.value}** completed: {task.objective[:60]}...")
                            
                            synthesis = orchestrator.execute_plan(plan, progress_callback=progress_cb, context=st.session_state.assistant_context)
                    except Exception as e:
                        emit_chunk(f"\n\n⚠️ Autonomous planning/execution hit an issue: `{e}` — delivering best-effort synthesis from available context.\n")
                        # guaranteed fallback synthesis so AI ALWAYS answers
                        synthesis = {
                            "executive_summary": f"Investigation for '{user_input}' partially completed. Core reconnaissance ran; synthesis was limited due to transient LLM/network conditions. Use the artifacts and pivot queries below to continue.",
                            "key_findings": [f"Objective: {user_input}", f"Context artifacts: {list(st.session_state.assistant_context.get('artifacts', {}).keys())}", "Retry with a more specific 3-5 word query if results are sparse."],
                            "actionable_intelligence": ["Re-run in Search & Scrape mode for faster onion discovery.", "Check Sidebar → Health Checks → LLM Connection."],
                            "all_artifacts": st.session_state.assistant_context.get("artifacts", {}),
                            "confidence": 0.5,
                        }
                        # create minimal plan for saving
                        from agents import InvestigationPlan, AgentTask
                        import uuid as _uuid
                        plan = InvestigationPlan(id=str(_uuid.uuid4()), objective=user_input, tasks=[], status="partial")
                    
                    fname = save_agent_investigation(plan, synthesis.get("all_artifacts", {}), synthesis)
                    emit_chunk(f"\n\n💾 **Investigation saved:** `{fname}`")
                    
                    discovered_artifacts = synthesis.get("all_artifacts", {})
                    # merge with any prior direct_urls artifacts
                    if direct_urls:
                        discovered_artifacts.setdefault("direct_urls", []).extend(direct_urls)
                    st.session_state.assistant_context["artifacts"] = {**st.session_state.assistant_context.get("artifacts", {}), **discovered_artifacts}
                    st.session_state.assistant_context["investigations"].append({
                        "objective": user_input,
                        "plan_id": plan.id,
                        "timestamp": datetime.now().isoformat(),
                        "summary": synthesis.get("executive_summary", "")[:500],
                    })

                    emit_chunk(f"\n\n## 📋 Executive Summary\n{synthesis.get('executive_summary', 'Completed.')}")
                    emit_chunk("\n\n## 🔑 Key Findings")
                    for finding in synthesis.get("key_findings", [])[:7]:
                        emit_chunk(f"\n- {finding}")
                    
                    if synthesis.get("actionable_intelligence"):
                        emit_chunk("\n\n## 🎯 Actionable Intelligence")
                        for item in synthesis.get("actionable_intelligence", [])[:5]:
                            emit_chunk(f"\n- {item}")
                    # auto-offer downloads from findings
                    if discovered_artifacts:
                        emit_chunk("\n\n> 💡 **Tip:** Say `download all tools` or paste a link to fetch real files — they’ll appear in **📥 Download Manager** with malware scan & auto-extract.")

                elif st.session_state.assistant_mode == "search":
                    try:
                        with st.spinner("🔍 Searching dark web (Ahmia/OnionLand/Tor66/Excavator + 12 more via Tor)..."):
                            recon = all_agents[AgentType.RECONNAISSANCE]
                            task = AgentTask(id=str(__import__('uuid').uuid4()), agent_type=AgentType.RECONNAISSANCE, objective=user_input, parameters={"queries": [user_input], "max_results": 50})
                            result = recon.execute_task(task, st.session_state.assistant_context)
                            try:
                                analysis = recon.analyze_results(task, result)
                            except Exception as ae:
                                analysis = {"key_findings": [f"Search completed with {result.get('count',0)} results; AI analysis temporarily unavailable: {ae}"], "pivot_queries": []}
                    except Exception as e:
                        emit_chunk(f"⚠️ Search encountered an issue: `{e}` — returning best-effort context.\n")
                        result = {"count": 0, "results": [], "artifacts": st.session_state.assistant_context.get("artifacts", {})}
                        analysis = {"key_findings": [f"Search for '{user_input}' returned 0 results (Tor may be offline or engines rate-limited). Try a 3-5 word keyword query."], "pivot_queries": []}
                    
                    discovered_artifacts = result.get("artifacts", {})
                    if direct_urls:
                        discovered_artifacts.setdefault("direct_urls", []).extend(direct_urls)
                    st.session_state.assistant_context["artifacts"] = discovered_artifacts
                    
                    emit_chunk(f"## 🔍 Search Results\nFound **{result.get('count', 0)}** unique .onion results (deduped, Tor-proxied).")
                    # show top results with one-click download
                    for i, r in enumerate(result.get("results", [])[:10], 1):
                        emit_chunk(f"\n{i}. [{r.get('title','Untitled')}]({r.get('link','')})")
                    emit_chunk("\n\n## 🔑 Key Findings")
                    for finding in analysis.get("key_findings", [])[:7]:
                        emit_chunk(f"\n- {finding}")
                    emit_chunk("\n\n## 🔄 Suggested Pivots")
                    for pivot in analysis.get("pivot_queries", [])[:7]:
                        emit_chunk(f"\n- {pivot}")
                    emit_chunk("\n\n> Say **'download #3'** or **'download all'** to fetch real content — I’ll queue it with integrity & malware scan.")

                elif st.session_state.assistant_mode == "download" and not want_download:
                    emit_chunk("📥 **Download Focus mode:** paste any `http(s)://` or `.onion` link, or say `download all tools from last search`. I'll queue with auto-extract + checksum + scan.\n")
                    if st.session_state.assistant_context.get("artifacts", {}).get("onions"):
                        emit_chunk(f"Found **{len(st.session_state.assistant_context['artifacts']['onions'])}** onion(s) in context ready to download.\n")

                response_placeholder.markdown(response_buffer["text"])

                if discovered_artifacts:
                    with artifacts_placeholder.expander("🔍 Artifacts Discovered", expanded=True):
                        for k, v in discovered_artifacts.items():
                            if v:
                                st.markdown(f"**{k}:** {', '.join(v[:30])}")

                if initiated_downloads:
                    with downloads_placeholder.expander("📥 Downloads Initiated", expanded=True):
                        for d in initiated_downloads:
                            st.markdown(f"- Job ID: `{d}` — view in **📥 Download Manager**")
                            if st.button(f"Go to Download Manager — {d}", key=f"goto_{d}"):
                                st.toast("Open the Download Manager tab to monitor progress")

            except Exception as e:
                import traceback as _tb
                _tb.print_exc()
                error_msg = f"⚠️ Assistant encountered an error: `{e}`\n\n**I’m still here and recovered.** Try rephrasing, or use **Search & Scrape** mode for faster results, or check **Sidebar → Health Checks → LLM Connection**."
                if not response_buffer["text"].strip():
                    response_buffer["text"] = f"Thanks for your message: **{user_input}**\n\n"
                response_buffer["text"] += f"\n\n{error_msg}"
                response_placeholder.markdown(response_buffer["text"])

        st.session_state.assistant_chat.append({
            "role": "assistant",
            "content": response_buffer["text"],
            "artifacts": discovered_artifacts,
            "downloads": initiated_downloads,
        })

    col_clear1, col_clear2, col_clear3, col_clear4 = st.columns(4)
    with col_clear1:
        if st.button("🧹 Clear Chat", use_container_width=True):
            st.session_state.assistant_chat = []
            st.rerun()
    with col_clear2:
        if st.button("🧠 Clear Context", use_container_width=True):
            st.session_state.assistant_context = {"artifacts": {}, "investigations": [], "downloads": []}
            st.rerun()
    with col_clear3:
        if st.button("💾 Export Session", use_container_width=True):
            export_data = {
                "chat": st.session_state.assistant_chat,
                "context": st.session_state.assistant_context,
                "timestamp": datetime.now().isoformat(),
            }
            b64 = base64.b64encode(json.dumps(export_data, default=str).encode()).decode()
            href = f'<a href="data:file/json;base64,{b64}" download="assistant_session_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json">Download Session</a>'
            st.markdown(href, unsafe_allow_html=True)
    with col_clear4:
        if st.button("🔄 Clear Model Cache", use_container_width=True):
            clear_model_cache()
            st.success("Model cache cleared!")
            st.rerun()


with tab4:
    st.header("📥 Download Manager")
    st.markdown("**Download tools, apps, folders, archives, scripts, databases, and any content from investigations.**")

    col_dl1, col_dl2 = st.columns([2, 1])
    
    with col_dl1:
        st.subheader("Create Download Job")
        dl_name = st.text_input("Job Name", placeholder="e.g., malware_samples_2024", key="dl_job_name")
        
        url_input_method = st.radio("Input Method", ["Manual URLs", "From Investigation", "From Agent Investigation", "From Artifacts"], horizontal=True)
        
        urls_data = []
        
        if url_input_method == "Manual URLs":
            manual_urls = st.text_area("URLs (one per line, format: url | title)", placeholder="http://example.onion/file.zip | Malware Sample\nhttp://example.onion/tool.py | Exploit Script", height=150, key="manual_urls")
            for line in manual_urls.strip().split("\n"):
                if "|" in line:
                    url, title = line.split("|", 1)
                else:
                    url, title = line.strip(), "Download"
                if url.strip():
                    urls_data.append({"link": url.strip(), "title": title.strip()})
        
        elif url_input_method == "From Investigation":
            investigations = load_investigations()
            if investigations:
                inv_labels = [f"{inv['_filename'].replace('investigation_','').replace('.json','')} — {inv['query'][:40]}" for inv in investigations]
                selected = st.selectbox("Select Investigation", inv_labels, key="dl_from_inv")
                if selected:
                    inv = investigations[inv_labels.index(selected)]
                    for item in inv.get("sources", []):
                        urls_data.append({"link": item.get("link", ""), "title": item.get("title", "Source")})
            else:
                st.info("No investigations available.")
        
        elif url_input_method == "From Agent Investigation":
            agent_invs = load_agent_investigations()
            if agent_invs:
                inv_labels = [f"{inv['_filename'].replace('agent_investigation_','').replace('.json','')} — {inv['objective'][:40]}" for inv in agent_invs]
                selected = st.selectbox("Select Agent Investigation", inv_labels, key="dl_from_agent_inv")
                if selected:
                    inv = agent_invs[inv_labels.index(selected)]
                    artifacts = inv.get("synthesis", {}).get("all_artifacts", {})
                    for art_type, items in artifacts.items():
                        for item in items:
                            if isinstance(item, str) and (item.startswith("http") or ".onion" in item):
                                urls_data.append({"link": item, "title": f"{art_type}: {item[:50]}"})
            else:
                st.info("No agent investigations available.")
        
        elif url_input_method == "From Artifacts":
            if st.session_state.assistant_context.get("artifacts"):
                artifacts = st.session_state.assistant_context["artifacts"]
                for art_type, items in artifacts.items():
                    if items:
                        st.write(f"**{art_type}:** {len(items)} items")
                        for item in items[:20]:
                            if isinstance(item, str) and (item.startswith("http") or ".onion" in item):
                                urls_data.append({"link": item, "title": f"{art_type}: {item[:50]}"})
            else:
                st.info("No artifacts in context. Run an investigation first.")

        if urls_data:
            st.write(f"**{len(urls_data)} URLs ready for download**")
            with st.expander("Preview URLs", expanded=False):
                for i, u in enumerate(urls_data[:20]):
                    st.write(f"{i+1}. {u['title']} — {u['link'][:80]}")

        dl_options = {}
        col_o1, col_o2, col_o3 = st.columns(3)
        with col_o1:
            dl_options["auto_extract"] = st.checkbox("Auto-extract archives", value=True, key="dl_auto_extract")
        with col_o2:
            dl_options["verify_checksum"] = st.checkbox("Verify checksums", value=True, key="dl_verify_checksum")
        with col_o3:
            dl_options["scan_malware"] = st.checkbox("Scan for malware indicators", value=True, key="dl_scan_malware")

        if st.button("🚀 Create & Start Download Job", type="primary", disabled=not urls_data or not dl_name, use_container_width=True):
            job_id = download_manager.create_job(dl_name, urls_data, dl_options)
            download_manager.start_job(job_id)
            st.success(f"✅ Download job created: `{job_id}`")
            st.rerun()

    with col_dl2:
        st.subheader("Quick Actions")
        if st.button("📥 Download All Scraped Content", use_container_width=True):
            if st.session_state.get("active_investigation") and st.session_state["active_investigation"].get("scraped"):
                scraped = st.session_state["active_investigation"]["scraped"]
                urls = [{"link": url, "title": f"Scraped: {url[:50]}"} for url in scraped]
                job_id = download_manager.create_job(f"scraped_content_{datetime.now().strftime('%H%M%S')}", urls, {"auto_extract": True})
                download_manager.start_job(job_id)
                st.success(f"Started: `{job_id}`")
            else:
                st.warning("No active investigation with scraped content.")

        if st.button("📥 Download All Artifacts", use_container_width=True):
            artifacts = st.session_state.assistant_context.get("artifacts", {})
            urls = []
            for art_type, items in artifacts.items():
                for item in items:
                    if isinstance(item, str) and (item.startswith("http") or ".onion" in item):
                        urls.append({"link": item, "title": f"{art_type}: {item[:50]}"})
            if urls:
                job_id = download_manager.create_job(f"artifacts_{datetime.now().strftime('%H%M%S')}", urls, {"auto_extract": True})
                download_manager.start_job(job_id)
                st.success(f"Started: `{job_id}`")
            else:
                st.warning("No downloadable artifacts in context.")

    st.divider()
    st.subheader("Active Download Jobs")

    jobs = download_manager.list_jobs()
    if jobs:
        for job in jobs:
            with st.expander(f"📦 {job.name} (`{job.id}`) — {job.status.value.upper()}", expanded=job.status == DownloadStatus.IN_PROGRESS):
                col_j1, col_j2, col_j3, col_j4 = st.columns(4)
                col_j1.metric("Status", job.status.value.title())
                col_j2.metric("Items", len(job.items))
                col_j3.metric("Downloaded", polish.format_bytes(job.downloaded_size))
                col_j4.metric("Total", polish.format_bytes(job.total_size) if job.total_size > 0 else "Unknown")

                if job.status == DownloadStatus.IN_PROGRESS:
                    progress = job.downloaded_size / max(job.total_size, 1)
                    st.progress(min(progress, 1.0))

                for item in job.items[:10]:
                    i_col1, i_col2, i_col3, i_col4 = st.columns([3, 1, 1, 1])
                    i_col1.write(f"**{item.title[:40]}**")
                    i_col2.write(item.content_type.value)
                    i_col3.write(f"{item.progress*100:.0f}%" if item.progress > 0 else "Pending")
                    i_col4.write(item.status.value.title())
                    if item.error:
                        st.caption(f"Error: {item.error}")
                    if item.local_path:
                        st.caption(f"Saved: {item.local_path}")

                if len(job.items) > 10:
                    st.caption(f"... and {len(job.items) - 10} more items")

                btn_cols = st.columns(4)
                if job.status == DownloadStatus.IN_PROGRESS:
                    if btn_cols[0].button("⏸️ Pause", key=f"pause_{job.id}", use_container_width=True):
                        download_manager.pause_job(job.id)
                        st.rerun()
                    if btn_cols[1].button("❌ Cancel", key=f"cancel_{job.id}", use_container_width=True):
                        download_manager.cancel_job(job.id)
                        st.rerun()
                elif job.status == DownloadStatus.PENDING:
                    if btn_cols[0].button("▶️ Resume", key=f"resume_{job.id}", use_container_width=True):
                        download_manager.resume_job(job.id)
                        st.rerun()
                
                if btn_cols[2].button("🗑️ Delete", key=f"delete_{job.id}", use_container_width=True):
                    download_manager.delete_job(job.id, delete_files=True)
                    st.rerun()
                
                if btn_cols[3].button("📄 Export Metadata", key=f"export_{job.id}", use_container_width=True):
                    meta_file = Path(job.output_dir) / "job_metadata.json"
                    if meta_file.exists():
                        b64 = base64.b64encode(meta_file.read_bytes()).decode()
                        href = f'<a href="data:file/json;base64,{b64}" download="job_{job.id}_metadata.json">Download Metadata</a>'
                        st.markdown(href, unsafe_allow_html=True)
    else:
        st.info("No download jobs yet. Create one above.")


with tab5:
    st.header("🛡️ Security & Analytics")
    
    sec_tab1, sec_tab2, sec_tab3, sec_tab4 = st.tabs(["🔒 Security Dashboard", "📊 Performance", "🧠 AI Self-Awareness", "⚙️ Settings"])

    with sec_tab1:
        dashboard = security.get_security_dashboard()
        
        col_s1, col_s2, col_s3, col_s4 = st.columns(4)
        col_s1.metric("Events (24h)", dashboard["total_events_24h"])
        col_s2.metric("Blocked IPs", len(dashboard["blocked_ips"]))
        col_s3.metric("Active Sessions", dashboard["active_sessions"])
        col_s4.metric("High Severity", dashboard["by_severity"].get("high", 0))

        if dashboard["by_type"]:
            st.subheader("Events by Type")
            st.bar_chart(dashboard["by_type"])
        
        if dashboard["by_severity"]:
            st.subheader("Events by Severity")
            st.bar_chart(dashboard["by_severity"])

        if dashboard["recent_events"]:
            st.subheader("Recent Security Events")
            for event in dashboard["recent_events"][-20:]:
                severity_color = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(event["severity"], "⚪")
                st.markdown(f"{severity_color} **{event['type']}** — {event['timestamp'][:19]} — {event['details']}")

    with sec_tab2:
        perf = polish.get_performance_summary()
        errors = polish.get_error_summary()
        
        if perf:
            st.subheader("Performance Metrics")
            for name, metrics in perf.items():
                with st.expander(f"{name}", expanded=False):
                    mcols = st.columns(4)
                    mcols[0].metric("Avg", f"{metrics['avg']:.3f}s")
                    mcols[1].metric("Min", f"{metrics['min']:.3f}s")
                    mcols[2].metric("Max", f"{metrics['max']:.3f}s")
                    mcols[3].metric("P95", f"{metrics['p95']:.3f}s")
        else:
            st.info("No performance data yet.")

        if errors:
            st.subheader("Error Counts")
            st.bar_chart(errors)
        else:
            st.success("No errors recorded!")

    with sec_tab3:
        st.subheader("🧠 Orchestrator Self-Awareness Report")
        
        # Get model from session state or sidebar
        current_model = st.session_state.get("model_select", model)
        if not current_model:
            st.warning("No model selected. Please select a model from the sidebar.")
            st.stop()
        
        if "orchestrator_instance" not in st.session_state or st.session_state.get("orchestrator_model") != current_model:
            try:
                st.session_state.orchestrator_instance = get_orchestrator(current_model)
                st.session_state.orchestrator_model = current_model
            except Exception as e:
                st.error(f"Failed to create orchestrator: {e}")
                st.stop()
        
        orchestrator = st.session_state.orchestrator_instance
        if orchestrator is None:
            st.error("Failed to initialize orchestrator")
            st.stop()
            
        report = orchestrator.get_full_self_awareness_report()
        
        st.markdown("### Orchestrator Core")
        orch_metrics = report["orchestrator"]["metrics"]
        o_cols = st.columns(4)
        o_cols[0].metric("Tasks Completed", orch_metrics.get("tasks_completed", 0))
        o_cols[1].metric("Tasks Failed", orch_metrics.get("tasks_failed", 0))
        o_cols[2].metric("Artifacts Discovered", orch_metrics.get("artifacts_discovered", 0))
        o_cols[3].metric("Success Rate", f"{report['orchestrator']['success_rate']*100:.1f}%")

        st.markdown("### Agent Self-Awareness")
        for agent_type, agent_report in report["agents"].items():
            with st.expander(f"{agent_type}", expanded=False):
                metrics = agent_report["metrics"]
                a_cols = st.columns(4)
                a_cols[0].metric("Completed", metrics.get("tasks_completed", 0))
                a_cols[1].metric("Failed", metrics.get("tasks_failed", 0))
                a_cols[2].metric("Artifacts", metrics.get("artifacts_discovered", 0))
                a_cols[3].metric("Queries", metrics.get("queries_executed", 0))
                
                st.markdown("**Recent Patterns:**")
                for pattern in agent_report["recent_patterns"][-5:]:
                    st.caption(f"{pattern['timestamp'][:19]} — {pattern['objective'][:60]} (success: {pattern['success']})")
                
                st.markdown("**Lessons Learned:**")
                for lesson in agent_report["top_lessons"][-5:]:
                    st.caption(f"• {lesson}")

        st.markdown("### Global Memory")
        gm = report["global_memory"]
        g_cols = st.columns(4)
        g_cols[0].metric("Patterns Learned", gm["patterns"])
        g_cols[1].metric("Lessons", gm["lessons"])
        g_cols[2].metric("Successful Queries", gm["successful_queries"])
        g_cols[3].metric("Artifact Types", len(gm["artifact_types"]))
        
        if gm["artifact_types"]:
            st.markdown("**Discovered Artifact Types:**")
            st.write(", ".join(gm["artifact_types"]))

    with sec_tab4:
        st.subheader("⚙️ Feature Flags")
        for feature, enabled in polish.feature_flags.items():
            new_val = st.checkbox(feature.replace("_", " ").title(), value=enabled, key=f"flag_{feature}")
            if new_val != enabled:
                polish.toggle_feature(feature, new_val)
        
        st.divider()
        st.subheader("🔐 Security Settings")
        st.checkbox("Enable Input Sanitization", value=True, disabled=True, help="Always enabled")
        st.checkbox("Enable Rate Limiting", value=True, disabled=True, help="Always enabled")
        st.checkbox("Enable CSRF Protection", value=True, disabled=True, help="Always enabled")
        st.checkbox("Enable Path Traversal Protection", value=True, disabled=True, help="Always enabled")
        
        st.divider()
        st.subheader("🧪 Advanced")
        if st.button("🧹 Clear All Security Events"):
            security.security_events.clear()
            st.success("Cleared!")
            st.rerun()
        
        if st.button("🧹 Clear Performance Metrics"):
            polish.performance_metrics.clear()
            polish.error_counts.clear()
            st.success("Cleared!")
            st.rerun()
        
        if st.button("🔄 Reset Agent Learning"):
            if "orchestrator_instance" in st.session_state:
                del st.session_state.orchestrator_instance
            st.success("Agent learning reset!")
            st.rerun()