"""
Shared Session Module - Centralized session management for Tor and direct connections.
"""
import logging
import os
import random
import threading
from typing import Dict
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)

# Module-level constants
MAX_DOWNLOAD_BYTES = 5_000_000

#: Tor SOCKS5 endpoint. Overridable so Docker and remote-Tor deployments do not
#: have to patch the source. Defaults match a stock local Tor daemon.
TOR_SOCKS_HOST = os.environ.get("TOR_SOCKS_HOST", "127.0.0.1").strip() or "127.0.0.1"
try:
    TOR_SOCKS_PORT = int(os.environ.get("TOR_SOCKS_PORT", "9050").strip() or "9050")
except ValueError:
    logger.warning("Invalid TOR_SOCKS_PORT, falling back to 9050")
    TOR_SOCKS_PORT = 9050
TOR_PROXY_URL = f"socks5h://{TOR_SOCKS_HOST}:{TOR_SOCKS_PORT}"

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.7; rv:137.0) Gecko/20100101 Firefox/137.0",
    "Mozilla/5.0 (X11; Linux i686; rv:137.0) Gecko/20100101 Firefox/137.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 Edg/135.0.3179.54",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 Edg/135.0.3179.54",
]

_ONION_HOST_RE = None

def _get_onion_regex():
    global _ONION_HOST_RE
    if _ONION_HOST_RE is None:
        import re
        _ONION_HOST_RE = re.compile(r"^[a-z2-7]{16,56}\.onion$", re.IGNORECASE)
    return _ONION_HOST_RE


_thread_local = threading.local()
_session_cache: Dict[str, requests.Session] = {}
_session_lock = threading.Lock()


def _build_tor_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=2,
        read=2,
        connect=2,
        backoff_factor=0.5,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=frozenset(["GET", "HEAD"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=20)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.proxies = {"http": TOR_PROXY_URL, "https": TOR_PROXY_URL}
    return session


def _build_direct_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=2,
        read=2,
        connect=2,
        backoff_factor=0.3,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=frozenset(["GET", "HEAD"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=20)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def get_tor_session() -> requests.Session:
    """Get thread-local Tor-enabled session (thread-safe, no sharing freezes)."""
    if not hasattr(_thread_local, "tor_session"):
        _thread_local.tor_session = _build_tor_session()
    return _thread_local.tor_session


def get_direct_session() -> requests.Session:
    """Get thread-local direct session."""
    if not hasattr(_thread_local, "direct_session"):
        _thread_local.direct_session = _build_direct_session()
    return _thread_local.direct_session


def get_session_for_url(url: str) -> requests.Session:
    """Get appropriate session (Tor or direct) based on URL."""
    parsed = urlparse(url)
    hostname = parsed.hostname or ""
    is_onion = bool(_get_onion_regex().match(hostname))
    return get_tor_session() if is_onion else get_direct_session()


def is_onion_url(url: str) -> bool:
    """Check if URL is an .onion address."""
    try:
        parsed = urlparse(url)
        hostname = parsed.hostname or ""
        return bool(_get_onion_regex().match(hostname))
    except Exception:
        return False


def close_all_sessions() -> None:
    for attr in ("tor_session", "direct_session"):
        if hasattr(_thread_local, attr):
            try:
                getattr(_thread_local, attr).close()
            except Exception:
                pass
            delattr(_thread_local, attr)
    with _session_lock:
        for s in _session_cache.values():
            try:
                s.close()
            except Exception:
                pass
        _session_cache.clear()


def close_thread_sessions() -> None:
    """Close sessions for the current thread only."""
    for attr in ("tor_session", "direct_session"):
        if hasattr(_thread_local, attr):
            try:
                getattr(_thread_local, attr).close()
            except Exception:
                pass
            delattr(_thread_local, attr)


def get_random_user_agent() -> str:
    return random.choice(USER_AGENTS)