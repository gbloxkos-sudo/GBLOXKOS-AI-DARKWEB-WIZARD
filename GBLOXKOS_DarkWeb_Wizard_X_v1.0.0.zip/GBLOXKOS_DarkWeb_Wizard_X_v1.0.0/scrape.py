"""
Scrape Module - Production-grade web scraping with resource management, validation, and async support.
"""
import logging
import random
import re
import threading
import time
import weakref
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeoutError
from dataclasses import dataclass
from typing import Any, Dict, List, Set, Tuple
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

from llm_utils import CircuitBreaker, CircuitBreakerOpenError
from session import USER_AGENTS, is_onion_url, get_session_for_url

logger = logging.getLogger(__name__)

import warnings
warnings.filterwarnings("ignore")

# Module-level constants
MAX_DOWNLOAD_BYTES = 5_000_000
MAX_EXTRACTED_TEXT_CHARS = 100_000
MAX_RETURN_CHARS = 8_000
ALLOWED_CONTENT_TYPES = ("text/html", "application/xhtml+xml", "text/plain", "application/json")
DEFAULT_TIMEOUT_CONNECT = 10
DEFAULT_TIMEOUT_READ = 30
ONION_TIMEOUT_CONNECT = 15
ONION_TIMEOUT_READ = 60
MAX_SCRAPE_WORKERS = 16
SCRAPE_CIRCUIT_BREAKER_THRESHOLD = 5

# Regex patterns for IOC extraction
ONION_REGEX = re.compile(r'([a-z2-7]{16,56}\.onion)', re.IGNORECASE)
EMAIL_REGEX = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
# BTC: legacy (1/3), bech32 (bc1...), taproot (bc1p...) + validation length
BTC_REGEX = re.compile(r'\b(?:[13][a-km-zA-HJ-NP-Z1-9]{25,34}|bc1[a-z0-9]{25,90})\b')
XMR_REGEX = re.compile(r'\b4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}\b')
ETH_REGEX = re.compile(r'\b0x[a-fA-F0-9]{40}\b')
PGP_REGEX = re.compile(r'-----BEGIN PGP (PUBLIC KEY BLOCK|MESSAGE|SIGNED MESSAGE)-----')
# Phone: require stricter, avoid matching random digit sequences - must have delimiters or country code
PHONE_REGEX = re.compile(r'(?:\+?\d{1,3}[-.\s])?\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\b')
IP_REGEX = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
CREDIT_CARD_REGEX = re.compile(r'\b(?:\d{4}[-\s]?){3}\d{4}\b')
SSN_REGEX = re.compile(r'\b\d{3}-\d{2}-\d{4}\b')


# ── Session Management with Circuit Breaker ──────────────────────────────

_scrape_circuit_breakers: Dict[str, CircuitBreaker] = {}
_scrape_breaker_weakrefs: Dict[str, weakref.ref] = {}
_scrape_breaker_lock = threading.RLock()

def _get_scrape_breaker(host: str) -> CircuitBreaker:
    """Get circuit breaker for a specific host."""
    with _scrape_breaker_lock:
        # Clean up dead weakrefs
        dead_keys = [k for k, ref in _scrape_breaker_weakrefs.items() if ref() is None]
        for k in dead_keys:
            _scrape_breaker_weakrefs.pop(k, None)
            _scrape_circuit_breakers.pop(k, None)
        
        if host not in _scrape_circuit_breakers:
            _scrape_circuit_breakers[host] = CircuitBreaker(
                failure_threshold=SCRAPE_CIRCUIT_BREAKER_THRESHOLD,
                recovery_timeout=60.0,
                half_open_max_calls=2,
            )
            _scrape_breaker_weakrefs[host] = weakref.ref(_scrape_circuit_breakers[host])
        return _scrape_circuit_breakers[host]


# ── Validation ──────────────────────────────────────────────────────────

def validate_url(url: str) -> Tuple[bool, str]:
    """Validate URL format and scheme."""
    if not url:
        return False, "Empty URL"
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return False, f"Invalid scheme: {parsed.scheme}"
        if not parsed.netloc:
            return False, "Missing hostname"
        return True, ""
    except Exception as e:
        return False, f"URL parse error: {e}"


def _normalize_url_data(url_data: Any) -> Tuple[str, str]:
    """Normalize URL data from various input formats."""
    if not isinstance(url_data, dict):
        return "", "Untitled"
    url = str(url_data.get("link") or "").strip()
    title = str(url_data.get("title") or "Untitled").strip() or "Untitled"
    return url, title


# ── IOC Extraction ──────────────────────────────────────────────────────

def extract_iocs(text: str) -> Dict[str, List[str]]:
    """Extract indicators of compromise from text."""
    if not text:
        return {
            "onions": [], "emails": [], "btc_addresses": [], "xmr_addresses": [],
            "eth_addresses": [], "phones": [], "ips": [], "has_pgp": False,
        }
    
    return {
        "onions": list(set(ONION_REGEX.findall(text))),
        "emails": list(set(EMAIL_REGEX.findall(text))),
        "btc_addresses": list(set(BTC_REGEX.findall(text))),
        "xmr_addresses": list(set(XMR_REGEX.findall(text))),
        "eth_addresses": list(set(ETH_REGEX.findall(text))),
        "phones": list(set(PHONE_REGEX.findall(text))),
        "ips": list(set(IP_REGEX.findall(text))),
        "has_pgp": bool(PGP_REGEX.search(text)),
    }


# ── Metadata Extraction ─────────────────────────────────────────────────

def extract_metadata(soup: BeautifulSoup, url: str) -> Dict[str, Any]:
    """Extract metadata from HTML document."""
    metadata = {
        "url": url,
        "title": "",
        "description": "",
        "keywords": "",
        "language": "",
        "generator": "",
        "links": [],
        "forms": [],
        "scripts": [],
        "images": [],
    }
    
    try:
        # Title
        title_tag = soup.find('title')
        if title_tag:
            metadata["title"] = title_tag.get_text(strip=True)[:500]
        
        # Meta tags
        for meta in soup.find_all('meta'):
            name = meta.get('name', '').lower()
            prop = meta.get('property', '').lower()
            content = meta.get('content', '')
            
            if name == 'description' or prop == 'og:description':
                metadata["description"] = content[:1000]
            elif name == 'keywords':
                metadata["keywords"] = content[:500]
            elif name == 'generator':
                metadata["generator"] = content[:200]
            elif name == 'language' or prop == 'og:locale':
                metadata["language"] = content[:50]
        
        # HTML lang attribute
        html_tag = soup.find('html')
        if html_tag and html_tag.get('lang'):
            metadata["language"] = html_tag.get('lang')[:50]
        
        # Links (limit to prevent memory issues)
        for i, link in enumerate(soup.find_all('a', href=True)):
            if i >= 100:
                break
            href = link['href']
            text = link.get_text(strip=True)
            if href and not href.startswith('#'):
                metadata["links"].append({"url": href[:500], "text": text[:200]})
        
        # Forms
        for form in soup.find_all('form'):
            try:
                action = form.get('action', '')
                method = form.get('method', 'get')
                inputs = []
                for inp in form.find_all('input'):
                    inputs.append({
                        "name": inp.get('name', ''),
                        "type": inp.get('type', ''),
                        "value": str(inp.get('value', ''))[:100],
                    })
                metadata["forms"].append({"action": action, "method": method, "inputs": inputs})
            except Exception:
                continue
        
        # Scripts
        for i, script in enumerate(soup.find_all('script', src=True)):
            if i >= 50:
                break
            metadata["scripts"].append(script['src'][:500])
        
        # Images
        for i, img in enumerate(soup.find_all('img', src=True)):
            if i >= 50:
                break
            metadata["images"].append(img['src'][:500])
    
    except Exception as e:
        logger.debug(f"Metadata extraction error: {e}")
    
    return metadata


# ── Single Page Scraping ────────────────────────────────────────────────

@dataclass
class ScrapeResult:
    """Structured result from scraping a single URL."""
    url: str
    title: str
    content: str
    iocs: Dict[str, List[str]]
    metadata: Dict[str, Any]
    error: str | None = None
    status_code: int | None = None
    latency_ms: int = 0
    content_length: int = 0
    content_type: str = ""


def scrape_single(
    url_data: Any,
    timeout_connect: int = DEFAULT_TIMEOUT_CONNECT,
    timeout_read: int = DEFAULT_TIMEOUT_READ,
    max_bytes: int = MAX_DOWNLOAD_BYTES,
) -> ScrapeResult:
    """
    Scrape a single URL with full error handling and resource management.
    
    Args:
        url_data: Dict with 'link' and 'title' keys, or URL string
        timeout_connect: Connection timeout in seconds
        timeout_read: Read timeout in seconds
        max_bytes: Maximum bytes to download
    
    Returns:
        ScrapeResult with content, IOCs, metadata, and status
    """
    url, title = _normalize_url_data(url_data)
    
    if not url:
        return ScrapeResult(
            url="", title=title, content="", iocs={}, metadata={},
            error="No URL provided"
        )
    
    # Validate URL
    valid, error = validate_url(url)
    if not valid:
        return ScrapeResult(
            url=url, title=title, content="", iocs={}, metadata={},
            error=error
        )
    
    parsed = urlparse(url)
    host = parsed.netloc
    use_tor = is_onion_url(url)
    if use_tor:
        timeout_connect = ONION_TIMEOUT_CONNECT
        timeout_read = ONION_TIMEOUT_READ
    
    headers = {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive",
    }
    
    response = None
    start_time = time.time()
    
    def _do_scrape():
        nonlocal response
        session = get_session_for_url(url)
        response = session.get(
            url,
            headers=headers,
            timeout=(timeout_connect, timeout_read),
            stream=True,
            allow_redirects=True,
        )
        return response
    
    try:
        # Use circuit breaker for the host
        breaker = _get_scrape_breaker(host)
        breaker.call(host, _do_scrape, timeout=timeout_read + timeout_connect + 10)
        
        latency_ms = int((time.time() - start_time) * 1000)
        status_code = response.status_code
        
        if status_code != 200:
            return ScrapeResult(
                url=url, title=title, content=title, iocs={}, metadata={},
                error=f"HTTP {status_code}",
                status_code=status_code,
                latency_ms=latency_ms,
            )
        
        # Check content type
        content_type = (response.headers.get("Content-Type") or "").lower()
        if content_type and not any(t in content_type for t in ALLOWED_CONTENT_TYPES):
            return ScrapeResult(
                url=url, title=title, content="", iocs={}, metadata={},
                error=f"Unsupported content type: {content_type}",
                status_code=status_code,
                latency_ms=latency_ms,
                content_type=content_type,
            )
        
        # Stream download with byte limit
        chunks = []
        bytes_read = 0
        for chunk in response.iter_content(chunk_size=8192):
            if not chunk:
                continue
            bytes_read += len(chunk)
            if bytes_read > max_bytes:
                logger.debug(f"Download limit reached for {url}: {bytes_read} bytes")
                break
            chunks.append(chunk)
        
        content_length = bytes_read
        
        # Decode content
        html = b"".join(chunks).decode(response.encoding or "utf-8", errors="replace")
        
        # Parse HTML
        soup = BeautifulSoup(html, "html.parser")
        
        # Remove unwanted elements
        for tag in soup(["script", "style", "noscript", "iframe", "svg", "canvas"]):
            tag.decompose()
        
        # Extract text
        text = soup.get_text(separator=' ')
        text = ' '.join(text.split())
        text = text[:MAX_EXTRACTED_TEXT_CHARS]
        
        # Extract IOCs and metadata
        iocs = extract_iocs(text)
        metadata = extract_metadata(soup, url)
        
        scraped_text = f"{title} - {text}" if text else title
        
        return ScrapeResult(
            url=url,
            title=title,
            content=scraped_text,
            iocs=iocs,
            metadata=metadata,
            error=None,
            status_code=status_code,
            latency_ms=latency_ms,
            content_length=content_length,
            content_type=content_type,
        )
    
    except CircuitBreakerOpenError:
        latency_ms = int((time.time() - start_time) * 1000)
        logger.warning(f"Circuit breaker open for host {host}")
        return ScrapeResult(
            url=url, title=title, content=title, iocs={}, metadata={},
            error=f"Circuit breaker open for {host}",
            latency_ms=latency_ms,
        )
    except requests.Timeout:
        latency_ms = int((time.time() - start_time) * 1000)
        return ScrapeResult(
            url=url, title=title, content=title, iocs={}, metadata={},
            error="Timeout",
            latency_ms=latency_ms,
        )
    except requests.RequestException as e:
        latency_ms = int((time.time() - start_time) * 1000)
        logger.debug(f"Request failed for {url}: {e}")
        return ScrapeResult(
            url=url, title=title, content=title, iocs={}, metadata={},
            error=f"Request error: {e}",
            latency_ms=latency_ms,
        )
    except Exception as e:
        latency_ms = int((time.time() - start_time) * 1000)
        logger.debug(f"Scrape failed for {url}: {e}")
        return ScrapeResult(
            url=url, title=title, content=title, iocs={}, metadata={},
            error=f"Parse error: {e}",
            latency_ms=latency_ms,
        )
    finally:
        if response is not None:
            try:
                response.close()
            except Exception:
                pass


# ── Multi-Page Scraping ────────────────────────────────────────────────

def scrape_multiple(
    urls_data: List[Any],
    max_workers: int = 5,
    timeout_per_url: float = 60.0,
) -> Dict[str, str]:
    """
    Scrape multiple URLs concurrently.
    
    Args:
        urls_data: List of URL dicts or strings
        max_workers: Maximum concurrent workers
        timeout_per_url: Timeout per URL in seconds
    
    Returns:
        Dict mapping URL -> scraped content (truncated to MAX_RETURN_CHARS)
    """
    if not isinstance(urls_data, (list, tuple)):
        logger.warning("urls_data is not a list/tuple")
        return {}
    
    max_workers = max(1, min(int(max_workers), 16))
    
    # Deduplicate input
    unique_urls_data = []
    seen_links: Set[str] = set()
    for item in urls_data:
        url, title = _normalize_url_data(item)
        if not url or url in seen_links:
            continue
        seen_links.add(url)
        unique_urls_data.append({"link": url, "title": title})
    
    if not unique_urls_data:
        return {}
    
    results: Dict[str, str] = {}
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_url = {
            executor.submit(scrape_single, url_data): url_data
            for url_data in unique_urls_data
        }
        
        for future in as_completed(future_to_url):
            try:
                result: ScrapeResult = future.result(timeout=timeout_per_url + 5)
                if result.url:
                    content = result.content
                    # Truncate for return value
                    if len(content) > MAX_RETURN_CHARS:
                        suffix = "...(truncated)"
                        available = MAX_RETURN_CHARS - len(suffix)
                        if available > 0:
                            content = content[:available] + suffix
                        else:
                            content = suffix[:MAX_RETURN_CHARS]
                    results[result.url] = content
            except FuturesTimeoutError:
                url_data = future_to_url[future]
                url, _ = _normalize_url_data(url_data)
                logger.warning(f"Scrape timeout for {url}")
            except Exception as e:
                logger.debug(f"Worker failed: {e}")
    
    return results


def scrape_multiple_detailed(
    urls_data: List[Any],
    max_workers: int = 5,
    timeout_per_url: float = 60.0,
) -> List[ScrapeResult]:
    """
    Scrape multiple URLs and return full detailed results.
    
    Returns:
        List of ScrapeResult objects with full metadata
    """
    if not isinstance(urls_data, (list, tuple)):
        return []
    
    max_workers = max(1, min(int(max_workers), 16))
    
    unique_urls_data = []
    seen_links: Set[str] = set()
    for item in urls_data:
        url, title = _normalize_url_data(item)
        if not url or url in seen_links:
            continue
        seen_links.add(url)
        unique_urls_data.append({"link": url, "title": title})
    
    results: List[ScrapeResult] = []
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_url = {
            executor.submit(scrape_single, url_data): url_data
            for url_data in unique_urls_data
        }
        
        for future in as_completed(future_to_url):
            try:
                result: ScrapeResult = future.result(timeout=timeout_per_url + 5)
                if result.url:
                    results.append(result)
            except FuturesTimeoutError:
                url_data = future_to_url[future]
                url, _ = _normalize_url_data(url_data)
                results.append(ScrapeResult(
                    url=url, title="", content="", iocs={}, metadata={},
                    error="Timeout", latency_ms=int(timeout_per_url * 1000)
                ))
            except Exception as e:
                logger.debug(f"Worker failed: {e}")
    
    return results

def clear_scrape_circuit_breakers() -> None:
    """Clear all scrape circuit breakers."""
    with _scrape_breaker_lock:
        _scrape_circuit_breakers.clear()
        _scrape_breaker_weakrefs.clear()
