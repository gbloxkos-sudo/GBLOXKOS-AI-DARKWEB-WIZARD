#!/bin/bash
set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$PROJECT_DIR/.venv"

echo "=== GBLOXKOS AI DARKWEB WIZARD X - Setup ==="
echo "Project directory: $PROJECT_DIR"

# Check Python version
PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "Python version: $PYTHON_VERSION"

if python3 -c 'import sys; exit(0 if sys.version_info >= (3, 10) else 1)'; then
    echo "✓ Python 3.10+ detected"
else
    echo "✗ Python 3.10+ required"
    exit 1
fi

# Check Tor
if command -v tor &> /dev/null; then
    echo "✓ Tor found: $(tor --version | head -1)"
else
    echo "✗ Tor not found. Installing..."
    if command -v apt &> /dev/null; then
        sudo apt update && sudo apt install -y tor
    elif command -v brew &> /dev/null; then
        brew install tor
    else
        echo "Please install Tor manually"
        exit 1
    fi
fi

# Check Ollama
if command -v ollama &> /dev/null; then
    echo "✓ Ollama found: $(ollama --version)"
    echo "  Available models:"
    ollama list | tail -n +2 | awk '{print "    - " $1}'
else
    echo "⚠ Ollama not found. Local models won't be available."
fi

# Create virtual environment (idiomatic + fallback)
if [ ! -d "$VENV_DIR" ]; then
    echo "Creating virtual environment..."
    if python3 -m venv --help >/dev/null 2>&1; then
        python3 -m venv "$VENV_DIR"
    elif command -v virtualenv >/dev/null 2>&1; then
        virtualenv -p python3 "$VENV_DIR"
    else
        echo "Installing virtualenv..."
        pip install --quiet virtualenv && virtualenv -p python3 "$VENV_DIR"
    fi
else
    echo "Virtual environment already exists"
fi

# Activate venv and install dependencies
echo "Installing Python dependencies..."
source "$VENV_DIR/bin/activate"
pip install --upgrade pip
pip install -r "$PROJECT_DIR/requirements.txt"

# Create .env file if it doesn't exist
if [ ! -f "$PROJECT_DIR/.env" ]; then
    echo "Creating .env file from template..."
    cat > "$PROJECT_DIR/.env" << 'EOF'
# GBLOXKOS AI DARKWEB WIZARD X Configuration
# For Ollama (local models), use the local endpoint
OLLAMA_BASE_URL=http://127.0.0.1:11434

# API Keys for cloud providers (optional - leave blank to use only local models)
# OPENAI_API_KEY=your_openai_api_key
# ANTHROPIC_API_KEY=your_anthropic_api_key
# GOOGLE_API_KEY=your_google_api_key
# OPENROUTER_API_KEY=your_openrouter_api_key
# OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
# LLAMA_CPP_BASE_URL=http://127.0.0.1:8080
# CUSTOM_API_BASE_URL=
# CUSTOM_API_KEY=
# CUSTOM_API_MODEL=
EOF
    echo "✓ .env file created with Ollama configuration"
else
    echo "✓ .env file already exists"
fi

# Ensure Ollama is running and accessible
echo "Checking Ollama connectivity..."
if curl -s http://127.0.0.1:11434/api/tags > /dev/null 2>&1; then
    echo "✓ Ollama is running and accessible"
else
    echo "⚠ Ollama not responding on http://127.0.0.1:11434"
    echo "  Starting Ollama server in background..."
    OLLAMA_HOST=0.0.0.0 ollama serve &
    sleep 3
    if curl -s http://127.0.0.1:11434/api/tags > /dev/null 2>&1; then
        echo "✓ Ollama started successfully"
    else
        echo "✗ Failed to start Ollama. Please run 'ollama serve' manually."
    fi
fi

echo ""
echo "=== Setup Complete ==="
echo ""
echo "To run GBLOXKOS AI DARKWEB WIZARD X, use the launcher script:"
echo "  $PROJECT_DIR/run_gbloxkos.sh"
echo ""
echo "Or manually:"
echo "  source $VENV_DIR/bin/activate"
echo "  cd $PROJECT_DIR"
echo "  streamlit run ui.py"