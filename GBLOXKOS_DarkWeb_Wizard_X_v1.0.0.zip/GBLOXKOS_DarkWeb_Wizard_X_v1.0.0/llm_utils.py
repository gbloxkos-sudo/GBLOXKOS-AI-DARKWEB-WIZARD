"""
LLM Utilities - Production-grade model management with circuit breakers, retries, and async support.
"""
import concurrent.futures
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any, Callable, Dict, List
from urllib.parse import urljoin

import requests
from langchain_anthropic import ChatAnthropic
from langchain_core.callbacks.base import BaseCallbackHandler
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_ollama import ChatOllama
from langchain_openai import ChatOpenAI

from config import (
    ANTHROPIC_API_KEY,
    CUSTOM_API_BASE_URL,
    CUSTOM_API_KEY,
    CUSTOM_API_MODEL,
    GOOGLE_API_KEY,
    LLAMA_CPP_BASE_URL,
    OLLAMA_BASE_URL,
    OPENROUTER_API_KEY,
    OPENROUTER_BASE_URL,
    OPENAI_API_KEY,
)

logger = logging.getLogger(__name__)

# Module-level constants
MAX_RESOLVE_CACHE_SIZE = 100
MAX_MODEL_CACHE_SIZE = 50
MODEL_CACHE_TTL = 60.0


# ── Circuit Breaker ────────────────────────────────────────────────────────

@dataclass
class CircuitBreakerState:
    failures: int = 0
    last_failure: float = 0
    state: str = "closed"  # closed, open, half-open
    success_count: int = 0


class CircuitBreaker:
    """Circuit breaker for external API calls with automatic cleanup."""
    
    MAX_STATES = 1000
    CLEANUP_INTERVAL = 3600  # 1 hour
    
    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        half_open_max_calls: int = 3,
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max_calls = half_open_max_calls
        self._states: Dict[str, CircuitBreakerState] = {}
        self._lock = threading.Lock()
        self._last_cleanup = time.time()
        self._cleanup_counter = 0
    
    def _cleanup_expired_states(self, force: bool = False) -> None:
        """Clean up expired circuit breaker states to prevent memory leaks."""
        now = time.time()
        self._cleanup_counter += 1
        
        # Cleanup every N calls or when interval exceeded
        if not force and self._cleanup_counter % 100 != 0 and now - self._last_cleanup < self.CLEANUP_INTERVAL:
            return
        
        with self._lock:
            # Re-check under lock
            if not force and self._cleanup_counter % 100 != 0 and now - self._last_cleanup < self.CLEANUP_INTERVAL:
                return
            
            expired_keys = []
            for key, state in self._states.items():
                # Remove states that have been closed for a long time or are old open states
                if state.state == "closed" and now - state.last_failure > self.recovery_timeout * 2 or state.state == "open" and now - state.last_failure > self.recovery_timeout * 10:
                    expired_keys.append(key)
            
            for key in expired_keys:
                self._states.pop(key, None)
            
            # Also enforce max size with LRU-style removal
            if len(self._states) > self.MAX_STATES:
                keys_to_remove = list(self._states.keys())[:len(self._states) - self.MAX_STATES]
                for key in keys_to_remove:
                    self._states.pop(key, None)
            
            self._last_cleanup = now
    
    def call(self, key: str, func: Callable, timeout: float | None = None, *args, **kwargs) -> Any:
        # Cleanup expired states periodically
        self._cleanup_expired_states()
        
        with self._lock:
            state = self._states.setdefault(key, CircuitBreakerState())
            
            if state.state == "open":
                if time.time() - state.last_failure > self.recovery_timeout:
                    state.state = "half-open"
                    state.success_count = 0
                    logger.info(f"Circuit breaker {key}: half-open")
                else:
                    raise CircuitBreakerOpenError(f"Circuit breaker open for {key}")
            
            if state.state == "half-open" and state.success_count >= self.half_open_max_calls:
                raise CircuitBreakerOpenError(f"Circuit breaker half-open limit reached for {key}")
        
        def _execute():
            return func(*args, **kwargs)
        
        try:
            if timeout is not None:
                try:
                    with ThreadPoolExecutor(max_workers=1) as pool:
                        future = pool.submit(_execute)
                        try:
                            result = future.result(timeout=timeout)
                        except concurrent.futures.TimeoutError:
                            try:
                                future.cancel()
                            except Exception:
                                pass
                            raise TimeoutError(
                                f"Circuit breaker call timed out for {key} after {timeout}s"
                            ) from None
                except RuntimeError as re:
                    # interpreter shutdown - e.g. "cannot schedule new futures after interpreter shutdown"
                    if "cannot schedule" in str(re).lower() or "shutdown" in str(re).lower():
                        raise TimeoutError(
                            f"Circuit breaker aborted (shutdown) for {key}: {re}"
                        ) from re
                    raise
            else:
                result = _execute()
            
            with self._lock:
                state = self._states[key]
                if state.state == "half-open":
                    state.success_count += 1
                    if state.success_count >= self.half_open_max_calls:
                        state.state = "closed"
                        state.failures = 0
                        logger.info(f"Circuit breaker {key}: closed")
                elif state.state == "closed":
                    state.failures = 0
            return result
        
        except (TimeoutError, CircuitBreakerOpenError):
            raise
        except Exception:
            with self._lock:
                state = self._states[key]
                state.failures += 1
                state.last_failure = time.time()
                if state.failures >= self.failure_threshold:
                    state.state = "open"
                    logger.warning(f"Circuit breaker {key}: opened after {state.failures} failures")
            raise
        finally:
            # Periodic forced cleanup
            self._cleanup_expired_states(force=False)
    
    def clear(self) -> None:
        """Clear all circuit breaker states."""
        with self._lock:
            self._states.clear()
    
    def get_state(self, key: str) -> str | None:
        """Get current state for a key."""
        with self._lock:
            state = self._states.get(key)
            return state.state if state else None


class CircuitBreakerOpenError(Exception):
    """Raised when circuit breaker is open."""


# ── Streaming Handler ──────────────────────────────────────────────────────

class BufferedStreamingHandler(BaseCallbackHandler):
    """Thread-safe buffered streaming handler with configurable flush rules."""
    
    def __init__(
        self,
        buffer_limit: int = 60,
        ui_callback: Callable[[str], None] | None = None,
        flush_on_newline: bool = True,
    ):
        self.buffer = ""
        self.buffer_limit = buffer_limit
        self.ui_callback = ui_callback
        self.flush_on_newline = flush_on_newline
        self._lock = threading.RLock()
    
    def on_llm_new_token(self, token: str, **kwargs) -> None:
        with self._lock:
            self.buffer += token
            should_flush = (
                (self.flush_on_newline and "\n" in token) or
                len(self.buffer) >= self.buffer_limit
            )
            if should_flush:
                self._flush_locked()
    
    def on_llm_end(self, response, **kwargs) -> None:
        with self._lock:
            self._flush_locked()
    
    def _flush_locked(self) -> None:
        if not self.buffer:
            return
        buf = self.buffer
        self.buffer = ""
        # Call UI callback if provided (no stdout spam in Streamlit)
        if self.ui_callback:
            try:
                self.ui_callback(buf)
            except Exception as e:
                logger.debug(f"UI callback error: {e}")
        # Note: No stdout printing in Streamlit context - UI callback handles display


# ── Model Configuration ────────────────────────────────────────────────────

def _normalize_model_name(name: str) -> str:
    return name.strip().lower()


def _get_ollama_base_url() -> str | None:
    if not OLLAMA_BASE_URL:
        return None
    return OLLAMA_BASE_URL.rstrip("/") + "/"


def _is_set(v: str | None) -> bool:
    return bool(v and str(v).strip() and "your_" not in str(v))


# Predefined model configurations
_LLM_CONFIG_MAP: Dict[str, Dict[str, Any]] = {
    # OpenAI
    "gpt-4.1": {"class": ChatOpenAI, "constructor_params": {"model_name": "gpt-4.1"}},
    "gpt-4o": {"class": ChatOpenAI, "constructor_params": {"model_name": "gpt-4o"}},
    "gpt-4o-mini": {"class": ChatOpenAI, "constructor_params": {"model_name": "gpt-4o-mini"}},
    "gpt-3.5-turbo": {"class": ChatOpenAI, "constructor_params": {"model_name": "gpt-3.5-turbo"}},
    # Anthropic
    "claude-3-5-sonnet-latest": {"class": ChatAnthropic, "constructor_params": {"model": "claude-3-5-sonnet-latest"}},
    "claude-3-5-haiku-latest": {"class": ChatAnthropic, "constructor_params": {"model": "claude-3-5-haiku-latest"}},
    "claude-3-opus-latest": {"class": ChatAnthropic, "constructor_params": {"model": "claude-3-opus-latest"}},
    # Google
    "gemini-2.5-flash": {"class": ChatGoogleGenerativeAI, "constructor_params": {"model": "gemini-2.5-flash", "google_api_key": GOOGLE_API_KEY}},
    "gemini-2.5-flash-lite": {"class": ChatGoogleGenerativeAI, "constructor_params": {"model": "gemini-2.5-flash-lite", "google_api_key": GOOGLE_API_KEY}},
    "gemini-2.5-pro": {"class": ChatGoogleGenerativeAI, "constructor_params": {"model": "gemini-2.5-pro", "google_api_key": GOOGLE_API_KEY}},
    "gemini-1.5-flash": {"class": ChatGoogleGenerativeAI, "constructor_params": {"model": "gemini-1.5-flash", "google_api_key": GOOGLE_API_KEY}},
    "gemini-1.5-pro": {"class": ChatGoogleGenerativeAI, "constructor_params": {"model": "gemini-1.5-pro", "google_api_key": GOOGLE_API_KEY}},
    # OpenRouter (free models)
    "qwen3-80b-openrouter": {
        "class": ChatOpenAI,
        "constructor_params": {
            "model_name": "qwen/qwen3-next-80b-a3b-instruct:free",
            "base_url": OPENROUTER_BASE_URL,
            "api_key": OPENROUTER_API_KEY,
        },
    },
    "nemotron-nano-9b-openrouter": {
        "class": ChatOpenAI,
        "constructor_params": {
            "model_name": "nvidia/nemotron-nano-9b-v2:free",
            "base_url": OPENROUTER_BASE_URL,
            "api_key": OPENROUTER_API_KEY,
        },
    },
    "gpt-oss-120b-openrouter": {
        "class": ChatOpenAI,
        "constructor_params": {
            "model_name": "openai/gpt-oss-120b:free",
            "base_url": OPENROUTER_BASE_URL,
            "api_key": OPENROUTER_API_KEY,
        },
    },
    "deepseek-chat-openrouter": {
        "class": ChatOpenAI,
        "constructor_params": {
            "model_name": "deepseek/deepseek-chat",
            "base_url": OPENROUTER_BASE_URL,
            "api_key": OPENROUTER_API_KEY,
        },
    },
    "llama-3.3-70b-openrouter": {
        "class": ChatOpenAI,
        "constructor_params": {
            "model_name": "meta-llama/llama-3.3-70b-instruct:free",
            "base_url": OPENROUTER_BASE_URL,
            "api_key": OPENROUTER_API_KEY,
        },
    },
}


# Common LLM parameters - tuned for multi-million dollar UX: fast fail, no freeze
_COMMON_LLM_PARAMS = {
    "temperature": 0,
    "streaming": True,
    "max_retries": 1,
    "request_timeout": 75,
    "timeout": 75,
}


# ── Model Discovery ────────────────────────────────────────────────────────

_circuit_breaker = CircuitBreaker(failure_threshold=3, recovery_timeout=30.0)
_model_cache: Dict[str, List[str]] = {}
_model_cache_time: Dict[str, float] = {}
_model_cache_lock = threading.Lock()


def _fetch_with_circuit(url: str, key: str, timeout: float = 5.0) -> Dict | None:
    """Fetch JSON with circuit breaker protection."""
    def _fetch():
        resp = requests.get(url, timeout=timeout)
        resp.raise_for_status()
        return resp.json()
    
    try:
        return _circuit_breaker.call(key, _fetch)
    except CircuitBreakerOpenError:
        logger.debug(f"Circuit breaker open for {key}, using cache")
        return None
    except Exception as e:
        logger.debug(f"Fetch failed for {key}: {e}")
        return None


def _is_chat_model(name: str) -> bool:
    """Filter out embedding/reranker models that cannot chat."""
    low = name.lower()
    blocked = ("embed", "mxbai", "bge-", "e5-", "nomic-embed", "all-minilm", "rerank", "whisper", "tts", "clip", "bert")
    # also block very small context embedding families by capability if known
    if "335m" in low and "mxbai" in low:
        return False
    return not any(b in low for b in blocked)

def fetch_ollama_models() -> List[str]:
    """Retrieve locally available Ollama models (non-blocking, cached)."""
    base_url = _get_ollama_base_url()
    if not base_url:
        return []
    cache_key = f"ollama:{base_url}"
    now = time.time()
    
    with _model_cache_lock:
        if cache_key in _model_cache and now - _model_cache_time.get(cache_key, 0) < MODEL_CACHE_TTL:
            return _model_cache[cache_key]
    
    url = urljoin(base_url, "api/tags")
    data = _fetch_with_circuit(url, cache_key, timeout=2.0)
    if not data:
        with _model_cache_lock:
            return _model_cache.get(cache_key, [])
    
    models = data.get("models", [])
    raw = [m.get("name") or m.get("model") for m in models if (m.get("name") or m.get("model"))]
    available = [m for m in raw if _is_chat_model(m)]
    
    with _model_cache_lock:
        # Limit cache size
        if len(_model_cache) >= MAX_MODEL_CACHE_SIZE:
            keys_to_remove = list(_model_cache.keys())[:len(_model_cache) // 4]
            for k in keys_to_remove:
                _model_cache.pop(k, None)
                _model_cache_time.pop(k, None)
        _model_cache[cache_key] = available
        _model_cache_time[cache_key] = now
    
    return available


def fetch_llama_cpp_models() -> List[str]:
    """Retrieve models from llama.cpp OpenAI-compatible server."""
    if not LLAMA_CPP_BASE_URL:
        return []
    
    cache_key = f"llama_cpp:{LLAMA_CPP_BASE_URL}"
    now = time.time()
    
    with _model_cache_lock:
        if cache_key in _model_cache and now - _model_cache_time.get(cache_key, 0) < MODEL_CACHE_TTL:
            return _model_cache[cache_key]
    
    base = LLAMA_CPP_BASE_URL.rstrip("/")
    url = f"{base}/v1/models"
    data = _fetch_with_circuit(url, cache_key, timeout=3.0)
    if not data:
        with _model_cache_lock:
            return _model_cache.get(cache_key, [])
    
    models = data.get("data", [])
    available = [m["id"] for m in models if "id" in m]
    
    with _model_cache_lock:
        if len(_model_cache) >= MAX_MODEL_CACHE_SIZE:
            keys_to_remove = list(_model_cache.keys())[:len(_model_cache) // 4]
            for k in keys_to_remove:
                _model_cache.pop(k, None)
                _model_cache_time.pop(k, None)
        _model_cache[cache_key] = available
        _model_cache_time[cache_key] = now
    
    return available


def fetch_custom_api_models() -> List[str]:
    """Retrieve models from custom OpenAI-compatible API."""
    if not CUSTOM_API_BASE_URL:
        return []
    
    cache_key = f"custom:{CUSTOM_API_BASE_URL}"
    now = time.time()
    
    with _model_cache_lock:
        if cache_key in _model_cache and now - _model_cache_time.get(cache_key, 0) < MODEL_CACHE_TTL:
            return _model_cache[cache_key]
    
    base = CUSTOM_API_BASE_URL.rstrip("/")
    if not base.endswith("/v1"):
        base += "/v1"
    url = f"{base}/models"
    data = _fetch_with_circuit(url, cache_key, timeout=3.0)
    if not data:
        with _model_cache_lock:
            return _model_cache.get(cache_key, [])
    
    models = data.get("data", [])
    available = [m["id"] for m in models if "id" in m]
    
    with _model_cache_lock:
        if len(_model_cache) >= MAX_MODEL_CACHE_SIZE:
            keys_to_remove = list(_model_cache.keys())[:len(_model_cache) // 4]
            for k in keys_to_remove:
                _model_cache.pop(k, None)
                _model_cache_time.pop(k, None)
        _model_cache[cache_key] = available
        _model_cache_time[cache_key] = now
    
    return available


# ── Model Resolution ──────────────────────────────────────────────────────

def get_model_choices() -> List[str]:
    """Get all available models (configured + discovered)."""
    gated_base_models: List[str] = []
    
    openai_ok = _is_set(OPENAI_API_KEY)
    anthropic_ok = _is_set(ANTHROPIC_API_KEY)
    google_ok = _is_set(GOOGLE_API_KEY)
    openrouter_ok = _is_set(OPENROUTER_API_KEY) and _is_set(OPENROUTER_BASE_URL)
    
    for k, cfg in _LLM_CONFIG_MAP.items():
        cls = cfg.get("class")
        ctor = cfg.get("constructor_params", {}) or {}
        
        # OpenRouter models
        if cls is ChatOpenAI and (ctor.get("base_url") == OPENROUTER_BASE_URL or "openrouter" in k):
            if openrouter_ok:
                gated_base_models.append(k)
            continue
        
        # Direct OpenAI models
        if cls is ChatOpenAI:
            if openai_ok:
                gated_base_models.append(k)
            continue
        
        # Anthropic
        if cls is ChatAnthropic:
            if anthropic_ok:
                gated_base_models.append(k)
            continue
        
        # Google Gemini
        if cls is ChatGoogleGenerativeAI:
            if google_ok:
                gated_base_models.append(k)
            continue
        
        # Anything else: keep
        gated_base_models.append(k)
    
    # Dynamic local models
    dynamic_models: List[str] = []
    dynamic_models += fetch_ollama_models()
    dynamic_models += fetch_llama_cpp_models()
    dynamic_models += fetch_custom_api_models()
    
    # Manual model from sidebar
    if CUSTOM_API_MODEL and CUSTOM_API_MODEL.strip():
        manual = CUSTOM_API_MODEL.strip()
        if _normalize_model_name(manual) not in {_normalize_model_name(m) for m in dynamic_models}:
            dynamic_models.append(manual)
    
    # Deduplicate: prefer gated models, then dynamic
    normalized: Dict[str, str] = {_normalize_model_name(m): m for m in gated_base_models}
    for dm in dynamic_models:
        key = _normalize_model_name(dm)
        if key not in normalized:
            normalized[key] = dm
    
    ordered_dynamic = sorted(
        [name for key, name in normalized.items() if name not in gated_base_models],
        key=_normalize_model_name,
    )
    return gated_base_models + ordered_dynamic


_resolve_cache: Dict[str, Dict[str, Any] | None] = {}
_resolve_cache_lock = threading.Lock()

def resolve_model_config(model_choice: str) -> Dict[str, Any] | None:
    """Resolve model choice to configuration dict (cached to prevent repeated network storms)."""
    cache_key = _normalize_model_name(model_choice)
    
    with _resolve_cache_lock:
        if cache_key in _resolve_cache:
            return _resolve_cache[cache_key]
    
    model_choice_lower = _normalize_model_name(model_choice)
    result = None
    
    # Predefined config
    cfg = _LLM_CONFIG_MAP.get(model_choice_lower)
    if cfg:
        result = cfg
    else:
        # llama.cpp
        for llama_model in fetch_llama_cpp_models():
            if _normalize_model_name(llama_model) == model_choice_lower:
                base = (LLAMA_CPP_BASE_URL or "").rstrip("/")
                if not base.endswith("/v1"):
                    base += "/v1"
                result = {
                    "class": ChatOpenAI,
                    "constructor_params": {
                        "model_name": llama_model,
                        "base_url": base,
                        "api_key": OPENAI_API_KEY or "sk-local",
                        "streaming": False,
                    },
                }
                break
        
        # Custom API
        if result is None:
            custom_candidates = list(fetch_custom_api_models())
            if CUSTOM_API_MODEL and CUSTOM_API_MODEL.strip():
                manual = CUSTOM_API_MODEL.strip()
                if _normalize_model_name(manual) not in {_normalize_model_name(m) for m in custom_candidates}:
                    custom_candidates.append(manual)
            for custom_model in custom_candidates:
                if _normalize_model_name(custom_model) == model_choice_lower:
                    base = (CUSTOM_API_BASE_URL or "").rstrip("/")
                    if not base.endswith("/v1"):
                        base += "/v1"
                    result = {
                        "class": ChatOpenAI,
                        "constructor_params": {
                            "model_name": custom_model,
                            "base_url": base,
                            "api_key": CUSTOM_API_KEY or "sk-custom",
                            "streaming": False,
                        },
                    }
                    break
        
        # Ollama
        if result is None:
            for ollama_model in fetch_ollama_models():
                if _normalize_model_name(ollama_model) == model_choice_lower:
                    result = {
                        "class": ChatOllama,
                        "constructor_params": {"model": ollama_model, "base_url": OLLAMA_BASE_URL},
                    }
                    break
    
    with _resolve_cache_lock:
        # Limit cache size
        if len(_resolve_cache) >= MAX_RESOLVE_CACHE_SIZE:
            # Remove oldest entries (simple FIFO)
            keys_to_remove = list(_resolve_cache.keys())[:len(_resolve_cache) // 4]
            for k in keys_to_remove:
                _resolve_cache.pop(k, None)
        _resolve_cache[cache_key] = result
    
    return result


def get_model_display_names(model_keys: List[str]) -> Dict[str, str]:
    """Get display names for model keys."""
    ollama_set = set(fetch_ollama_models())
    llama_cpp_set = set(fetch_llama_cpp_models())
    custom_set = set(fetch_custom_api_models())
    
    display = {}
    for key in model_keys:
        cfg = _LLM_CONFIG_MAP.get(_normalize_model_name(key))
        if cfg:
            cls = cfg.get("class")
            ctor = cfg.get("constructor_params", {}) or {}
            base_url = str(ctor.get("base_url", "")).lower()
            if "openrouter" in base_url or "openrouter" in key.lower():
                prefix = "openrouter"
            elif cls is ChatAnthropic:
                prefix = "anthropic"
            elif cls is ChatGoogleGenerativeAI:
                prefix = "google"
            elif cls is ChatOpenAI:
                prefix = "openai"
            else:
                prefix = "other"
        elif key in ollama_set:
            prefix = "ollama"
        elif key in llama_cpp_set:
            prefix = "llama.cpp"
        elif key in custom_set:
            prefix = "custom"
        else:
            prefix = "local"
        display[key] = f"[{prefix}] {key}"
    return display


def clear_model_cache() -> None:
    """Clear model discovery cache."""
    with _model_cache_lock:
        _model_cache.clear()
        _model_cache_time.clear()
    with _resolve_cache_lock:
        _resolve_cache.clear()