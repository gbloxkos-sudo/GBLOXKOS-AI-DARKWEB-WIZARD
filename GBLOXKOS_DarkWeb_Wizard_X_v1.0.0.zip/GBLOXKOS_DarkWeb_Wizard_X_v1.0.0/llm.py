"""
LLM Module - Production-grade LLM wrapper with retries, validation, and structured outputs.
"""
import json
import logging
import re
import time
import threading
from dataclasses import dataclass
from typing import Any, Dict, List, Union

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import BaseMessage

from llm_utils import (
    _COMMON_LLM_PARAMS,
    resolve_model_config,
    get_model_choices,
    CircuitBreaker,
    CircuitBreakerOpenError,
)
from config import (
    ANTHROPIC_API_KEY,
    CUSTOM_API_BASE_URL,
    CUSTOM_API_KEY,
    GOOGLE_API_KEY,
    OPENAI_API_KEY,
    OPENROUTER_API_KEY,
    LLAMA_CPP_BASE_URL,
)

logger = logging.getLogger(__name__)

# Suppress noisy warnings
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

# Module-level constants - production tuned for no-freeze UX
MAX_RETRIES = 2
BASE_RETRY_DELAY = 0.8
MAX_RETRY_DELAY = 8.0
RETRY_EXPONENTIAL_BASE = 2.0
LLM_CALL_TIMEOUT = 65.0
MAX_RESOLVE_CACHE_SIZE = 100


# ── Data Classes ──────────────────────────────────────────────────────────

@dataclass
class LLMResult:
    """Structured result from LLM calls."""
    text: str
    model: str
    latency_ms: int
    tokens_estimated: int = 0
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""
    max_attempts: int = 2
    base_delay: float = 1.5
    max_delay: float = 15.0
    exponential_base: float = 2.0
    retryable_errors: tuple = (
        ConnectionError,
        TimeoutError,
        IOError,
    )
    retryable_status_codes: tuple = (429, 500, 502, 503, 504)


# ── LLM Factory ───────────────────────────────────────────────────────────

def get_llm(model_choice: str, streaming: bool = True, callbacks: List | None = None):
    """
    Create LLM instance with proper configuration and credential validation.
    
    Args:
        model_choice: Model identifier
        streaming: Enable streaming mode
        callbacks: Optional callback handlers
    
    Returns:
        Configured LLM instance
    
    Raises:
        ValueError: If model is unsupported or credentials missing
    """
    config = resolve_model_config(model_choice)
    
    if config is None:
        supported_models = get_model_choices()
        raise ValueError(
            f"Unsupported LLM model: '{model_choice}'. "
            f"Supported models (case-insensitive match) are: {', '.join(supported_models)}"
        )
    
    llm_class = config["class"]
    model_specific_params = config.get("constructor_params", {}).copy()
    
    # Validate credentials
    _ensure_credentials(model_choice, llm_class, model_specific_params)
    
    # Merge parameters
    all_params = {**_COMMON_LLM_PARAMS, **model_specific_params}
    all_params["streaming"] = streaming
    
    if callbacks:
        all_params["callbacks"] = callbacks
    
    try:
        llm_instance = llm_class(**all_params)
        logger.debug(f"Created LLM: {model_choice} ({llm_class.__name__})")
        return llm_instance
    except Exception as e:
        logger.error(f"Failed to create LLM {model_choice}: {e}")
        raise


def _ensure_credentials(model_choice: str, llm_class, model_params: dict) -> None:
    """Validate required credentials for the model."""
    
    def _require(key_value: str | None, env_var: str, provider_name: str) -> None:
        if key_value and str(key_value).strip() and "your_" not in str(key_value):
            return
        raise ValueError(
            f"{provider_name} model '{model_choice}' selected but `{env_var}` is not set or is a placeholder.\n"
            "Add it to your .env file or export it before running the app."
        )
    
    class_name = getattr(llm_class, "__name__", str(llm_class))
    
    if "ChatAnthropic" in class_name:
        _require(ANTHROPIC_API_KEY, "ANTHROPIC_API_KEY", "Anthropic")
    elif "ChatGoogleGenerativeAI" in class_name:
        _require(GOOGLE_API_KEY, "GOOGLE_API_KEY", "Google Gemini")
    elif "ChatOllama" in class_name:
        # Ollama doesn't need API key, just base URL
        pass
    elif "ChatOpenAI" in class_name:
        base_url = (model_params or {}).get("base_url", "").lower()
        if "openrouter" in base_url:
            _require(OPENROUTER_API_KEY, "OPENROUTER_API_KEY", "OpenRouter")
        elif base_url and ("localhost" in base_url or "127.0.0.1" in base_url):
            pass  # Local models don't need API keys
        elif CUSTOM_API_BASE_URL and base_url and CUSTOM_API_BASE_URL.lower().rstrip("/") in base_url:
            if CUSTOM_API_KEY:
                pass  # Custom API with key
            else:
                logger.warning("Custom API base URL set but no CUSTOM_API_KEY provided")
        elif LLAMA_CPP_BASE_URL and base_url and LLAMA_CPP_BASE_URL.lower().rstrip("/") in base_url:
            pass  # llama.cpp local server
        else:
            _require(OPENAI_API_KEY, "OPENAI_API_KEY", "OpenAI")
    else:
        logger.warning(f"Unknown LLM class: {class_name}, skipping credential validation")


# ── Retry Logic ───────────────────────────────────────────────────────────

_llm_circuit_breaker = CircuitBreaker(failure_threshold=5, recovery_timeout=60.0, half_open_max_calls=3)
_llm_circuit_lock = threading.Lock()

def _invoke_with_retry(
    chain,
    invoke_vars: Dict[str, Any],
    retry_config: RetryConfig | None = None,
    model_name: str = "unknown",
    timeout: float = LLM_CALL_TIMEOUT,
) -> str:
    """Invoke chain with exponential backoff retry and circuit breaker."""
    if retry_config is None:
        retry_config = RetryConfig()
    
    last_exception = None
    delay = retry_config.base_delay
    
    for attempt in range(retry_config.max_attempts):
        try:
            start = time.time()
            
            # Use circuit breaker for the actual call
            def _call_chain():
                return chain.invoke(invoke_vars)
            
            result = _llm_circuit_breaker.call(model_name, _call_chain, timeout=timeout)
            
            latency_ms = int((time.time() - start) * 1000)
            logger.debug(f"LLM call succeeded: {model_name} ({latency_ms}ms, attempt {attempt + 1})")
            return result
            
        except CircuitBreakerOpenError:
            logger.warning(f"Circuit breaker open for {model_name}, attempt {attempt + 1}")
            last_exception = RuntimeError(f"Circuit breaker open for {model_name}")
            if attempt < retry_config.max_attempts - 1:
                time.sleep(min(delay, retry_config.max_delay))
                delay *= retry_config.exponential_base
            continue
        except TimeoutError as e:
            last_exception = e
            logger.warning(f"LLM call timed out (attempt {attempt + 1}/{retry_config.max_attempts}): {e}")
            if attempt < retry_config.max_attempts - 1:
                time.sleep(min(delay, retry_config.max_delay))
                delay *= retry_config.exponential_base
            continue
        except retry_config.retryable_errors as e:
            last_exception = e
            logger.warning(f"LLM call failed (attempt {attempt + 1}/{retry_config.max_attempts}): {e}")
            if attempt < retry_config.max_attempts - 1:
                time.sleep(min(delay, retry_config.max_delay))
                delay *= retry_config.exponential_base
            continue
        except Exception as e:
            error_str = str(e).lower()
            # graceful shutdown - do not retry, bubble quickly to fallback
            if "cannot schedule" in error_str or "interpreter shutdown" in error_str or "event loop is closed" in error_str:
                logger.warning(f"LLM call aborted due to shutdown: {e}")
                raise TimeoutError(f"LLM aborted (shutdown): {e}") from e
            is_rate_limit = any(kw in error_str for kw in ("429", "rate limit", "too many requests", "quota exceeded", "rate_limit"))
            is_transient = any(kw in error_str for kw in ("500", "502", "503", "504", "server error", "internal error", "overloaded", "capacity"))
            if is_rate_limit or is_transient:
                last_exception = e
                logger.warning(f"LLM call failed with transient error (attempt {attempt + 1}/{retry_config.max_attempts}): {e}")
                if attempt < retry_config.max_attempts - 1:
                    time.sleep(min(delay, retry_config.max_delay))
                    delay *= retry_config.exponential_base
                continue
            # Non-retryable error
            logger.error(f"LLM call failed with non-retryable error: {e}")
            raise
    
    raise last_exception or RuntimeError(f"Max retries exceeded for {model_name}")

def clear_llm_circuit_breaker() -> None:
    """Clear the LLM circuit breaker state."""
    with _llm_circuit_lock:
        _llm_circuit_breaker._states.clear()


# ── Core Functions ────────────────────────────────────────────────────────

def _clean_llm_output(text: str) -> str:
    """Clean LLM output by removing markdown code fences."""
    if not text:
        return ""
    text = text.strip()
    text = re.sub(r"^```(?:markdown|json|)?\n?", "", text)
    text = re.sub(r"\n?```$", "", text)
    return text.strip()


def refine_query(llm, user_input: str) -> str:
    """Refine user query into optimal dark web search query. Always returns a usable query even if LLM fails."""
    if not user_input or not user_input.strip():
        return "dark web threat intel"
    # fast path: if LLM is unavailable, return keyword-stripped fallback without calling LLM
    system_prompt = """You are a Dark Web OSINT Expert specializing in cybercrime threat intelligence, darknet market analysis, ransomware operations, and underground forum intelligence.

Your task is to refine the user's query into an optimal search query for dark web search engines (Ahmia, OnionLand, Tor66, Excavator, etc.).

EXPERT GUIDELINES:
1. Dark web search engines work best with SHORT, SPECIFIC keywords (3-5 words max)
2. Use terminology that threat actors, vendors, and forum users actually use
3. Include relevant slang, codenames, market names, forum names, malware families
4. Avoid logical operators (AND, OR, NOT) - most onion search engines don't support them
5. Focus on: threat actor handles, market names, malware names, CVE numbers, cryptocurrency addresses, onion service names, data breach names, ransomware group names
6. Translate natural language into "dark web dialect" - e.g., "stolen credit cards" -> "fullz dumps cc shop", "ransomware attack" -> "lockbit alphv ransom note"

EXAMPLES:
- "Find ransomware groups targeting healthcare" -> "lockbit alphv healthcare ransom"
- "Stolen credit card shops" -> "fullz cc shop dumps vendor"
- "Personal data breach" -> "pii database leak dump"
- "Dark web drug markets" -> "hydra whitehouse market onion"
- "Malware source code leaks" -> "source code leak github malware"
- "Cryptocurrency money laundering" -> "mixer tumbler bitcoin laundry"

OUTPUT: Return ONLY the refined query (3-5 words), nothing else. No markdown, no explanation.

INPUT:"""
    prompt_template = ChatPromptTemplate([("system", system_prompt), ("user", "{query}")])
    chain = prompt_template | llm | StrOutputParser()
    
    try:
        result = _invoke_with_retry(chain, {"query": user_input}, model_name="refine_query")
        cleaned = _clean_llm_output(result)
        if cleaned.strip():
            # enforce 3-5 words sanity, strip operators
            cleaned = re.sub(r'\b(AND|OR|NOT)\b', '', cleaned, flags=re.I)
            cleaned = ' '.join(cleaned.split())[:80]
            if 2 <= len(cleaned.split()) <= 6:
                return cleaned
            return cleaned
    except Exception as e:
        logger.warning(f"refine_query LLM failed, using keyword fallback: {e}")
    # deterministic keyword fallback ensures AI always responds and pipeline never freezes
    fallback = re.sub(r'[^a-zA-Z0-9\s\-]', ' ', user_input).strip()
    words = fallback.split()
    # keep first 4 meaningful words (drop stopwords length <3 unless needed)
    filtered = [w for w in words if len(w) > 2][:5]
    return ' '.join(filtered[:4]) if filtered else fallback[:40] or "dark web intel"


def _generate_final_string(results: List[Dict], truncate: bool = False) -> str:
    """Generate formatted string of search results for LLM consumption."""
    if truncate:
        max_title_length = 30
        max_link_length = 0
    else:
        max_title_length = 200
        max_link_length = 100
    
    final_str = []
    for i, res in enumerate(results):
        truncated_link = re.sub(r"(?<=\.onion).*", "", res.get("link", ""))
        title = re.sub(r"[^0-9a-zA-Z\-\.]", " ", res.get("title", ""))
        if not truncated_link and not title:
            continue
        
        if truncate:
            title = title[:max_title_length] + "..." if len(title) > max_title_length else title
            truncated_link = truncated_link[:max_link_length] + "..." if len(truncated_link) > max_link_length else truncated_link
        
        final_str.append(f"{i+1}. {truncated_link} - {title}")
    
    return "\n".join(final_str)


def filter_results(llm, query: str, results: List[Dict], max_results: int = 20) -> List[Dict]:
    """Filter search results to top relevant ones using LLM. Falls back to heuristic ranking if LLM fails so pipeline never stalls."""
    if not results:
        return []
    
    system_prompt = """You are a Dark Web OSINT Analyst. You are given a search query and a list of search results (index, .onion link, title). 

Select the TOP 20 most relevant results for a CYBERCRIME THREAT INTELLIGENCE investigation.

PRIORITIZE results that indicate:
- Active darknet markets/vendors/shops
- Threat actor forums, Telegram channels, blogs
- Ransomware leak sites, data dump sites
- Malware/exploit distribution, C2 infrastructure
- Stolen data: credentials, PII, financial, corporate
- Cryptocurrency services: mixers, tumblers, exchanges
- Hacking tools, tutorials, services for hire
- Vulnerability exploits, zero-days, PoCs
- OpSec guides, anonymity tools, counter-forensics

DEPRIORITIZE:
- Dead/offline links, parked domains
- Clearweb mirrors, legitimate sites
- Generic search pages, index pages
- Adult content, scams, low-quality noise
- Irrelevant/off-topic results

OUTPUT: Comma-separated list of indices (1-based) ONLY. Max 20 indices. No explanation. No markdown.

Search Query: {query}
Search Results:"""
    
    final_str = _generate_final_string(results)
    
    prompt_template = ChatPromptTemplate([("system", system_prompt), ("user", "{results}")])
    chain = prompt_template | llm | StrOutputParser()
    
    def _heuristic_rank(items: List[Dict], q: str) -> List[int]:
        """Heuristic ranking when LLM is unavailable - never crashes, never freezes."""
        keywords = set(re.findall(r'\w+', q.lower()))
        scored = []
        for idx, item in enumerate(items, 1):
            title = (item.get("title") or "").lower()
            link = (item.get("link") or "").lower()
            score = 0
            # keyword match boost
            for kw in keywords:
                if len(kw) > 2 and (kw in title or kw in link):
                    score += 3
            # dark web signal boost
            dark_signals = ("market","leak","ransom","dump","onion","forum","breach","stealer","vendor","shop","c2")
            for sig in dark_signals:
                if sig in title:
                    score += 1
            # penalize generic
            if "search" in title or "index" in title:
                score -= 2
            scored.append((score, idx))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [idx for _, idx in scored]

    try:
        result_indices = _invoke_with_retry(chain, {"query": query, "results": final_str}, model_name="filter_results")
    except Exception as e:
        logger.warning(f"Filter results failed, using truncated fallback: {e}")
        try:
            final_str_trunc = _generate_final_string(results, truncate=True)
            result_indices = _invoke_with_retry(chain, {"query": query, "results": final_str_trunc}, model_name="filter_results_fallback")
        except Exception as e2:
            logger.warning(f"Filter fallback also failed, using heuristic rank: {e2}")
            heuristic = _heuristic_rank(results, query)
            # return heuristic directly to guarantee 100% feature availability
            return [results[i - 1] for i in heuristic[:max_results] if 1 <= i <= len(results)]
    
    result_indices = _clean_llm_output(result_indices)
    
    parsed_indices = []
    for match in re.findall(r"\d+", result_indices):
        try:
            idx = int(match)
            if 1 <= idx <= len(results):
                parsed_indices.append(idx)
        except ValueError:
            continue
    
    # Deduplicate preserving order
    seen = set()
    parsed_indices = [i for i in parsed_indices if not (i in seen or seen.add(i))]
    
    if not parsed_indices:
        logger.warning(
            "Unable to interpret LLM result selection ('%s'). Defaulting to top %d results.",
            result_indices, min(len(results), 20)
        )
        parsed_indices = list(range(1, min(len(results), max_results) + 1))
    
    top_results = [results[i - 1] for i in parsed_indices[:max_results]]
    return top_results


# ── Preset Prompts ────────────────────────────────────────────────────────

PRESET_PROMPTS = {
    "threat_intel": """You are an ELITE Cybercrime Threat Intelligence Analyst with 20+ years experience in dark web OSINT, cybercrime underground economy, ransomware operations, APT attribution, and digital forensics. You have deep knowledge of:
- Major darknet markets (Hydra legacy, White House, Abacus, Archetyp, etc.) and vendor reputations
- Ransomware groups (LockBit, ALPHV/BlackCat, Play, Akira, RansomHub, etc.) - TTPs, affiliates, leak sites
- Malware families (RedLine, Raccoon, Vidar, Lumma, StealC, etc.) - capabilities, distribution, C2
- Initial Access Brokers (IABs), credential markets, cookie/log markets
- Cryptocurrency tracing: mixers (Tornado, Sinbad), swaps, chain-hopping, privacy coins
- Underground forums (Exploit, XSS, BreachForums, Dread, RAMP, etc.) - culture, slang, key actors
- OpSec failures that lead to arrests, doxxing, infrastructure seizure

RULES:
0. STRICT GROUNDING: Only report artifacts, IOCs, and claims EXPLICITLY present in the provided INPUT data. Do not infer, extrapolate, or fabricate. If evidence isn't there, OMIT it.
1. Analyze the Darkweb OSINT data using links and their raw scraped content.
2. Output the Source Links referenced for the analysis.
3. Provide a detailed, contextual, evidence-based technical analysis.
4. Extract intelligence artifacts WITH THEIR CONTEXT from the data.
5. Artifacts include: threat actor handles/aliases, onion service addresses, marketplace/vendor names, forum names, malware names/versions, C2 IPs/domains, cryptocurrency addresses (BTC/XMR/ETH), PGP keys, email addresses, phone numbers, exploited CVEs, TTPs mapped to MITRE ATT&CK, victim organizations, data types exposed, pricing/tier information.
6. Generate 5-7 key insights - specific, actionable, evidence-based, intelligence-driven.
7. Include suggested next steps and pivot queries for deeper investigation.
8. Be objective, analytical, and precise. Ignore NSFW content.
9. Use professional CTI report structure and terminology.

OUTPUT FORMAT - Respond in Markdown. Every section as `## Heading`. Use bullet points (`-`) for ALL lists. NO numbered lists.

## Input Query
{query}

## Source Links Referenced for Analysis
- every source link used for the analysis

## Investigation Artifacts
- each technical artifact with its context (threat actor handle, onion address, marketplace, forum, malware, C2, crypto address, CVE, TTP, victim, data type, pricing, etc.)

## Key Insights
- each insight as its own bullet — specific, actionable, evidence-based

## Next Steps
- each next investigative step or follow-up search query as its own bullet

INPUT:""",
    
    "ransomware_malware": """You are an ELITE Malware & Ransomware Intelligence Analyst specializing in ransomware-as-a-service (RaaS) ecosystems, malware reverse engineering, C2 infrastructure tracking, and threat actor profiling.

DEEP EXPERTISE IN:
- RaaS programs: LockBit 3.0, ALPHV/BlackCat, Play, Akira, RansomHub, Black Basta, Cl0p, BianLian, 8Base, etc. - affiliate models, revenue splits, leak site operations
- Loader/stealer malware: RedLine, Raccoon, Vidar, Lumma, StealC, MetaStealer, RisePro, Amadey - distribution, panel features, exfiltration
- Ransomware encryptors: Babuk, Conti, Hive, Royal, BlackByte - encryption schemes, anti-analysis, lateral movement
- Exploit kits: SocGholish, GootLoader, BATLOADER - delivery chains, traffic distribution systems (TDS)
- C2 frameworks: Cobalt Strike, Sliver, Brute Ratel, Mythic, Havoc - malleable profiles, beacon configs
- Initial Access: VPN creds, RDP, Citrix, Fortinet, Pulse Secure, Exchange (ProxyShell/ProxyLogon), CitrixBleed
- Data extortion: double/triple extortion, leak site publishing schedules, victim shaming tactics
- Cryptocurrency laundering: BTC -> XMR swaps, chain hopping, nested services, exchange deposit addresses

RULES:
0. STRICT GROUNDING: Only report from provided INPUT. No fabrication.
1. Analyze Darkweb OSINT data from links and raw text.
2. Output Source Links referenced.
3. FOCUS: Ransomware groups, malware families, exploit kits, attack infrastructure.
4. Identify malware indicators: file hashes (MD5/SHA256), C2 domains/IPs, staging URLs, payload names, packers, obfuscation, YARA rules, mutexes, registry keys.
5. Map TTPs to MITRE ATT&CK (provide technique IDs: T1xxx).
6. Identify victim orgs, sectors, geographies.
7. Generate 5-7 key insights on threat actor behavior & malware evolution.
8. Include next steps: hunting queries, detection rules (Sigma/YARA/Snort), further investigation.
9. Objective, analytical. Ignore NSFW.

OUTPUT FORMAT - Markdown, `## Heading` sections, bullets only.

## Input Query
{query}

## Source Links Referenced for Analysis
- every source link used

## Malware / Ransomware Indicators
- each indicator as bullet (hashes, C2s, payloads, TTPs with MITRE IDs)

## Threat Actor Profile
- group name, aliases, known victims, sector targeting, RaaS program — one bullet each

## Key Insights
- each insight on threat actor behavior and malware evolution

## Next Steps
- each hunting query, detection rule, or investigation step

INPUT:""",
    
    "personal_identity": """You are an ELITE Personal Threat Intelligence Analyst specializing in PII exposure, identity theft ecosystems, credential stuffing, doxxing, and personal data supply chains on the dark web.

DEEP EXPERTISE IN:
- PII types: Fullz (complete identity kits), SSN/DOB, driver's license, passport scans, utility bills, bank statements, tax returns, medical records
- Credential markets: logs (cookies/sessions), combolists, config files, account takeovers (ATO)
- Data brokers & shops: Genesis Market (seized), Russian Market, 2easy, SpyCloud, breach compilations
- Identity documents: templates, generators, counterfeit services, "verified" accounts
- Financial fraud: credit card dumps (Track 1/2), CVV shops, BIN lists, cashout methods, drop services
- SIM swapping, port-out fraud, 2FA bypass, session hijacking
- Doxxing services, swatting, harassment-as-a-service
- Privacy tools: synthetic identities, CPN/SCN, credit profile numbers

RULES:
0. STRICT GROUNDING: Only from INPUT. No fabrication.
1. Analyze Darkweb OSINT data.
2. Output Source Links.
3. FOCUS: PII - names, emails, phones, addresses, SSN, passport, financial, medical, login credentials.
4. Identify breach sources, data brokers, marketplaces selling personal data.
5. Assess exposure severity: what data, how actionable for threat actor, freshness, completeness.
6. Generate 5-7 key insights on individual's exposure risk.
7. Include protective actions & further queries.
8. Objective, discretion with personal data. Ignore NSFW.

OUTPUT FORMAT - Markdown, `## Heading`, bullets only.

## Input Query
{query}

## Source Links Referenced for Analysis
- every source link

## Exposed PII Artifacts
- each artifact as bullet (type, value, source context, freshness)

## Breach / Marketplace Sources Identified
- each breach or marketplace as bullet (name, date, data types, volume)

## Exposure Risk Assessment
- what data available, how actionable for threat actor, risk level

## Key Insights
- each insight on exposure risk

## Next Steps
- each protective action or further query

INPUT:""",
    
    "corporate_espionage": """You are an ELITE Corporate Intelligence Analyst specializing in corporate data leaks, intellectual property theft, insider threats, supply chain compromise, and business-targeted cybercrime.

DEEP EXPERTISE IN:
- Leaked corporate data: source code (GitHub/GitLab/Bitbucket), internal docs (Confluence/SharePoint), financial records, M&A docs, legal, HR, customer databases
- Credential leaks: corporate VPN, SSO (Okta/Azure AD), cloud (AWS/GCP/Azure), CI/CD, database, admin panels
- Threat actors targeting corps: APTs (Lazarus, APT28/29, Charming Kitten), ransomware affiliates, IABs, insiders, hacktivists
- Data brokers: IntelBroker, USDoD, KelvinSecurity, ShinyHunters, Pompompurin - breach forums, auction sites
- Supply chain: software supply chain (dependency confusion, typo-squatting), hardware, MSP compromise
- Competitive intelligence: trade secrets, patents, R&D, pricing, customer lists, roadmaps
- Regulatory impact: GDPR, CCPA, SEC, HIPAA, SOX - notification obligations, fines
- Incident response: containment, forensics, legal privilege, law enforcement engagement

RULES:
0. STRICT GROUNDING: Only from INPUT. No fabrication.
1. Analyze Darkweb OSINT data.
2. Output Source Links.
3. FOCUS: Corporate leaks - credentials, source code, docs, financials, employee/customer data.
4. Identify threat actors, insider indicators, broker activity targeting the org.
5. Assess business impact: competitive damage, operational disruption, regulatory, reputational.
6. Generate 5-7 key insights on corporate risk posture.
7. Include IR steps, legal considerations, further queries.
8. Objective, analytical. Ignore NSFW.

OUTPUT FORMAT - Markdown, `## Heading`, bullets only.

## Input Query
{query}

## Source Links Referenced for Analysis
- every source link

## Leaked Corporate Artifacts
- each artifact as bullet (credentials, documents, source code, databases, config files)

## Threat Actor / Broker Activity
- each threat actor or broker as bullet (handle, forum, evidence, motivation)

## Business Impact Assessment
- competitive/operational/regulatory/reputational damage

## Key Insights
- each insight on corporate risk posture

## Next Steps
- each IR action, legal consideration, or further query

INPUT:""",
}


def generate_summary(
    llm,
    query: str,
    content: Union[str, Dict],
    preset: str = "threat_intel",
    custom_instructions: str = "",
) -> str:
    """Generate investigation summary from scraped content. Guaranteed to return a string even on LLM failure."""
    system_prompt = PRESET_PROMPTS.get(preset, PRESET_PROMPTS["threat_intel"])
    # normalize content to string with size cap to prevent token explosion / freezes
    if isinstance(content, dict):
        content_str = "\n\n".join(f"{k}: {v}" for k, v in content.items())
    else:
        content_str = str(content) if content is not None else ""
    is_empty = not content_str.strip() or content_str.strip() == "(no scraped content available — searched sources may be offline or blocked)"
    if not content_str.strip():
        content_str = "(no scraped content available — searched sources may be offline or blocked. Tor may need more time, or engines returned 0 results. Suggestions: retry with shorter 2-3 word keywords, verify Tor, or try different model.)"
        is_empty = True
    # adaptive cap: Ollama 3B CPU needs ~3.5k chars for <20s (8000 → 65s timeout in your logs)
    _is_local = False
    try:
        _model_name = getattr(llm, "model", "") or getattr(llm, "model_name", "") or ""
        _base = getattr(llm, "base_url", "") or getattr(llm, "baseUrl", "") or ""
        if "ollama" in str(type(llm)).lower() or "127.0.0.1" in str(_base) or "ollama" in str(_model_name).lower() or "qwen" in str(_model_name).lower() or "llama" in str(_model_name).lower():
            _is_local = True
    except Exception:
        pass
    _cap = 3500 if _is_local else 8000
    if len(content_str) > _cap:
        content_str = content_str[:_cap] + "\n\n[...truncated for token budget...]"
    invoke_vars = {"query": query, "content": content_str}

    # INSTANT fallback for empty content - avoids 65s LLM wait that caused your freeze
    if is_empty and len(content_str) < 500:
        logger.info("generate_summary: empty content - returning instant fallback without LLM call")
        return (
            f"## Input Query\n{query}\n\n"
            f"## Source Links Referenced for Analysis\n- No sources returned (search found 0 results)\n\n"
            f"## Investigation Artifacts\n- No artifacts extracted — try a shorter 2-3 word query (e.g. 'lockbit ransom' or 'fullz shop')\n\n"
            f"## Key Insights\n- Search returned 0 results via Tor/clearnet mirrors. Engines may be rate-limited or query too narrow.\n"
            f"- Tor was verified at startup but dark-web search engines are intermittent — retry in 30s or try broader keywords.\n"
            f"- No scraped content available to analyze. Pipeline still completed without crash.\n\n"
            f"## Next Steps\n- Retry with: `lockbit` or `breach forum` or `cc shop` (2-3 words)\n"
            f"- Check Sidebar → Health Checks → Check LLM Connection and Search Engines\n"
            f"- If Ollama 3B is slow, try a faster model or reduce Max Results to 20\n\n"
            f"## Raw Content (truncated)\n{content_str[:2000]}"
        )
    
    if custom_instructions and custom_instructions.strip():
        system_prompt = system_prompt.rstrip() + "\n\nAdditionally focus on: {custom_focus}"
        invoke_vars["custom_focus"] = custom_instructions.strip()
    
    prompt_template = ChatPromptTemplate([("system", system_prompt), ("user", "{content}")])
    chain = prompt_template | llm | StrOutputParser()
    
    try:
        # For local Ollama 3B: single attempt only → fallback after 45s not 130s (your logs showed 65+65 timeout = Ctrl+C)
        _is_local_gen = False
        try:
            _m = getattr(llm, "model", "") or getattr(llm, "model_name", "") or ""
            if "ollama" in str(type(llm)).lower() or "qwen" in str(_m).lower() or "llama" in str(_m).lower():
                _is_local_gen = True
        except Exception:
            pass
        _gen_timeout = 45.0 if _is_local_gen else LLM_CALL_TIMEOUT
        _gen_retries = RetryConfig(max_attempts=1) if _is_local_gen else None
        result = _invoke_with_retry(chain, invoke_vars, retry_config=_gen_retries, model_name=f"generate_summary:{preset}", timeout=_gen_timeout)
        cleaned = _clean_llm_output(result) if result else ""
        if cleaned.strip():
            return cleaned
    except Exception as e:
        logger.warning(f"generate_summary failed: {e}")
    # Fallback: produce a structured minimal report so AI always responds and features stay 100%
    fallback = (
        f"## Input Query\n{query}\n\n"
        f"## Source Links Referenced for Analysis\n- (see {len(content_str.splitlines())} scraped fragments)\n\n"
        f"## Investigation Artifacts\n- No structured artifacts extracted — raw content below may contain leads.\n\n"
        f"## Key Insights\n- Investigation relied on raw scraped content due to temporary LLM unavailability.\n"
        f"- Review the raw fragments and pivot queries for next steps.\n\n"
        f"## Next Steps\n- Retry with a smaller query or different model.\n"
        f"- Check API key / Ollama health via Sidebar → Health Checks.\n\n"
        f"## Raw Content (truncated)\n{content_str[:4000]}"
    )
    return fallback


# ── Follow-up Chat ────────────────────────────────────────────────────────

_FOLLOWUP_PERSONAS = {
    "threat_intel": "an Elite Cybercrime Threat Intelligence Analyst",
    "ransomware_malware": "an Elite Malware & Ransomware Intelligence Analyst",
    "personal_identity": "an Elite Personal Threat Intelligence Analyst",
    "corporate_espionage": "an Elite Corporate Intelligence Analyst",
}

_FOLLOWUP_SYSTEM = """You are {persona}, answering follow-up questions about a completed dark web OSINT investigation.

RULES:
1. STRICT GROUNDING: Answer ONLY from the INVESTIGATION CONTEXT below and conversation history. If answer not in context, say so plainly — do not infer or fabricate.
2. Answer directly and conversationally. Do NOT reproduce full report format.
3. When referencing artifacts/claims, cite the source link or section.
4. Be concise, analytical, precise. Ignore NSFW.
5. Use your deep domain expertise to connect dots, explain significance, suggest pivots.
{extra_instructions}

INVESTIGATION CONTEXT:
{context}"""


def build_followup_context(
    query: str,
    refined: str,
    sources: List[Dict],
    scraped: Union[str, Dict] | None,
    summary: str,
    char_budget: int = 15000,
) -> str:
    """Build context for follow-up questions."""
    parts = [f"ORIGINAL QUERY: {query}", f"REFINED QUERY: {refined}"]
    
    if sources:
        src_lines = "\n".join(
            f"- {s.get('title', 'Untitled')} ({s.get('link', '')})" for s in sources
        )
        parts.append("SOURCES:\n" + src_lines)
    
    if summary:
        parts.append("INVESTIGATION SUMMARY:\n" + str(summary))
    
    if scraped:
        if isinstance(scraped, dict):
            raw = "\n\n".join(f"{k}: {v}" for k, v in scraped.items())
        else:
            raw = str(scraped)
        
        if len(raw) > char_budget:
            raw = raw[:char_budget] + "\n\n[...truncated...]"
        parts.append("RAW SCRAPED CONTENT (may be truncated):\n" + raw)
    
    return "\n\n".join(parts)


def answer_followup(
    llm,
    question: str,
    context: str,
    history: List[BaseMessage] | None = None,
    preset: str = "threat_intel",
    custom_instructions: str = "",
) -> str:
    """Answer follow-up question grounded in investigation context. Never crashes — always returns an answer."""
    if not question or not question.strip():
        return "Please ask a specific follow-up question about the investigation."
    if not context or not context.strip():
        context = "(no investigation context available — run an investigation first)"
    # cap context to avoid token overflow
    if len(context) > 12000:
        context = context[:12000] + "\n[...context truncated...]"
    persona = _FOLLOWUP_PERSONAS.get(preset, _FOLLOWUP_PERSONAS["threat_intel"])
    extra_instructions = ""
    if custom_instructions and custom_instructions.strip():
        extra_instructions = f"\nAlso keep in mind: {custom_instructions.strip()}\n"
    
    prompt_template = ChatPromptTemplate([
        ("system", _FOLLOWUP_SYSTEM),
        MessagesPlaceholder("history"),
        ("user", "{question}"),
    ])
    chain = prompt_template | llm | StrOutputParser()
    
    try:
        result = _invoke_with_retry(chain, {
            "persona": persona,
            "context": context,
            "extra_instructions": extra_instructions,
            "history": history or [],
            "question": question,
        }, model_name="answer_followup")
        cleaned = _clean_llm_output(result) if result else ""
        if cleaned.strip():
            return cleaned
    except Exception as e:
        logger.warning(f"answer_followup failed: {e}")
        # Return grounded fallback so chat never appears frozen/empty
        snippet = context[:600].replace("\n", " ")
        return (
            f"I couldn't reach the LLM for a live answer ({e}).\n\n"
            f"**Your question:** {question}\n\n"
            f"**What I can tell from the saved context:** {snippet}...\n\n"
            f"Try again, or check Sidebar → Health Checks → Check LLM Connection and verify your API key / Ollama is running."
        )
    return "I'm here — could you rephrase your question? The investigation context is loaded and I'm ready to help."


# ── Pivot Suggestions ─────────────────────────────────────────────────────

def suggest_pivots(
    llm,
    query: str,
    content: Union[str, Dict, List],
    preset: str = "threat_intel",
    max_pivots: int = 7,
) -> List[str]:
    """Generate pivot queries for deeper investigation."""
    persona = _FOLLOWUP_PERSONAS.get(preset, _FOLLOWUP_PERSONAS["threat_intel"])
    system_prompt = f"""You are {persona}, working a completed dark web OSINT investigation. Based on the completed investigation data below, propose concise follow-up SEARCH QUERIES that would pivot the investigation toward related leads — new artifacts, threat actor handles, marketplaces, forums, breach names, malware families, cryptocurrency addresses, C2 infrastructure, exploit CVEs, etc. that actually appear in or are strongly implied by the data.

RULES:
1. Each query must be 3-5 words, NO logical operators (AND, OR, etc.).
2. Propose 3-{max_pivots} queries — ONLY ones grounded in the data.
3. Use dark web terminology: threat actor handles, market names, forum names, malware names, onion addresses, crypto addresses, CVE numbers, data types (fullz, logs, dumps, source code).
4. Output ONLY a valid JSON array of strings, nothing else. No markdown, no code fences, no explanation.
5. Example format: ["lockbit affiliate panel", "alphv leak site new victims", "redline stealer c2 config"]

INVESTIGATION QUERY: {query}
INVESTIGATION DATA:"""
    
    if isinstance(content, dict):
        raw_content = "\n\n".join(f"{k}: {v}" for k, v in content.items())
    elif isinstance(content, list):
        raw_content = "\n\n".join(str(x) for x in content)
    else:
        raw_content = str(content)
    
    prompt_template = ChatPromptTemplate([("system", system_prompt), ("user", "{content}")])
    chain = prompt_template | llm | StrOutputParser()
    
    try:
        raw = _invoke_with_retry(chain, {"query": query, "content": raw_content[:10000]}, model_name=f"suggest_pivots:{preset}")
    except Exception as e:
        logger.warning("Pivot suggestion call failed: %s", e)
        return []
    
    text = raw.strip()
    text = re.sub(r"^```(?:json|)?\n?", "", text)
    text = re.sub(r"\n?```$", "", text)
    text = text.strip()
    
    match = re.search(r"\[.*\]", text, re.DOTALL)
    if match:
        text = match.group(0)
    
    try:
        pivots = json.loads(text)
    except json.JSONDecodeError as e:
        logger.warning("Failed to parse pivot JSON: %s | Raw: %s", e, text[:200])
        return []
    except Exception:
        return []
    
    if not isinstance(pivots, list):
        return []
    
    cleaned = []
    for p in pivots:
        if isinstance(p, str):
            p_clean = p.strip()
            if p_clean and len(p_clean.split()) <= 6:
                cleaned.append(p_clean)
    return cleaned[:max_pivots]