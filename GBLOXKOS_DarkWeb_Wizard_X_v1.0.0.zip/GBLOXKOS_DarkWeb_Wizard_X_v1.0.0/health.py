"""
Health Check Module - Production-grade health monitoring with circuit breakers.
"""
import logging
import random
import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeoutError
from typing import Any, Dict, List

import requests

from llm import get_llm
from llm_utils import resolve_model_config
from session import USER_AGENTS, get_tor_session
from search import SEARCH_ENGINES

logger = logging.getLogger(__name__)

# Module-level constants
HEALTH_CHECK_TIMEOUT = 30.0
MAX_HEALTH_WORKERS = 8
SEARCH_ENGINE_TIMEOUT = 15.0
TOR_PROXY_TIMEOUT = 5.0


def check_tor_proxy(timeout: float = TOR_PROXY_TIMEOUT) -> Dict[str, Any]:
    """
    Test that the Tor SOCKS5 proxy on 127.0.0.1:9050 is accepting connections.
    
    Args:
        timeout: Connection timeout in seconds
    
    Returns:
        Dict with status, latency_ms, and error
    """
    start = time.time()
    try:
        sock = socket.create_connection(("127.0.0.1", 9050), timeout=timeout)
        sock.close()
        latency_ms = round((time.time() - start) * 1000)
        return {"status": "up", "latency_ms": latency_ms, "error": None}
    except TimeoutError:
        return {"status": "down", "latency_ms": None, "error": f"Connection timeout after {timeout}s"}
    except ConnectionRefusedError:
        return {"status": "down", "latency_ms": None, "error": "Connection refused - is Tor running?"}
    except OSError as e:
        return {"status": "down", "latency_ms": None, "error": f"OS error: {e}"}
    except Exception as e:
        logger.debug(f"Tor proxy check failed: {e}")
        return {"status": "down", "latency_ms": None, "error": str(e)}


def check_llm_health(model_choice: str, timeout: float = HEALTH_CHECK_TIMEOUT) -> Dict[str, Any]:
    """
    Test actual connectivity to the selected LLM by sending a minimal prompt.
    
    Args:
        model_choice: Model identifier
        timeout: Request timeout in seconds
    
    Returns:
        Dict with status, latency_ms, error, and provider
    """
    config = resolve_model_config(model_choice)
    if config is None:
        return {
            "status": "error",
            "latency_ms": None,
            "error": f"Unknown model: {model_choice}",
            "provider": "unknown",
        }
    
    # Determine provider name for display
    class_name = getattr(config["class"], "__name__", str(config["class"]))
    ctor = config.get("constructor_params", {}) or {}
    if "ChatAnthropic" in class_name:
        provider = "Anthropic"
    elif "ChatGoogleGenerativeAI" in class_name:
        provider = "Google Gemini"
    elif "ChatOllama" in class_name:
        provider = "Ollama (local)"
    elif "ChatOpenAI" in class_name:
        base_url = (ctor.get("base_url") or "").lower()
        if "openrouter" in base_url:
            provider = "OpenRouter"
        elif "llama" in base_url or "localhost" in base_url or "127.0.0.1" in base_url:
            provider = "llama.cpp (local)"
        else:
            provider = "OpenAI"
    else:
        provider = class_name
    
    start = time.time()
    try:
        llm = get_llm(model_choice)
        # Send a tiny prompt — cheapest possible API call; wrap in timeout via ThreadPool to avoid freeze
        import concurrent.futures as _cf
        def _inv():
            return llm.invoke("OK")
        with _cf.ThreadPoolExecutor(max_workers=1) as _pool:
            fut = _pool.submit(_inv)
            try:
                response = fut.result(timeout=timeout)
            except _cf.TimeoutError as exc:
                raise TimeoutError(f"LLM health check timed out after {timeout}s") from exc
        latency_ms = round((time.time() - start) * 1000)
        text = getattr(response, "content", str(response))
        if text and len(text.strip()) > 0:
            return {
                "status": "up",
                "latency_ms": latency_ms,
                "error": None,
                "provider": provider,
            }
        return {
            "status": "down",
            "latency_ms": latency_ms,
            "error": "Empty response from API",
            "provider": provider,
        }
    except requests.Timeout:
        latency_ms = round((time.time() - start) * 1000)
        return {
            "status": "down",
            "latency_ms": latency_ms,
            "error": f"Request timeout after {timeout}s",
            "provider": provider,
        }
    except FuturesTimeoutError:
        latency_ms = round((time.time() - start) * 1000)
        return {
            "status": "down",
            "latency_ms": latency_ms,
            "error": f"Future timeout after {timeout}s",
            "provider": provider,
        }
    except Exception as e:
        latency_ms = round((time.time() - start) * 1000)
        logger.debug(f"LLM health check failed for {model_choice}: {e}")
        return {
            "status": "down",
            "latency_ms": latency_ms,
            "error": str(e)[:200],
            "provider": provider,
        }


def _ping_single_engine(engine: Dict, timeout: float = SEARCH_ENGINE_TIMEOUT) -> Dict[str, Any]:
    """Ping a single search engine via Tor and return its status."""
    name = engine["name"]
    url_template = engine["url"]
    url = url_template.format(query="test")
    
    start = time.time()
    try:
        session = get_tor_session()
        headers = {"User-Agent": random.choice(USER_AGENTS)}
        resp = session.get(url, headers=headers, timeout=timeout)
        latency_ms = round((time.time() - start) * 1000)
        return {
            "name": name,
            "status": "up" if resp.status_code == 200 else "down",
            "latency_ms": latency_ms,
            "error": None if resp.status_code == 200 else f"HTTP {resp.status_code}",
        }
    except requests.Timeout:
        latency_ms = round((time.time() - start) * 1000)
        return {
            "name": name,
            "status": "down",
            "latency_ms": latency_ms,
            "error": f"Timeout after {timeout}s",
        }
    except requests.RequestException as e:
        latency_ms = round((time.time() - start) * 1000)
        logger.debug(f"Search engine {name} request failed: {e}")
        return {
            "name": name,
            "status": "down",
            "latency_ms": latency_ms,
            "error": f"Request error: {str(e)[:100]}",
        }
    except Exception as e:
        latency_ms = round((time.time() - start) * 1000)
        logger.debug(f"Search engine {name} check failed: {e}")
        return {
            "name": name,
            "status": "down",
            "latency_ms": latency_ms,
            "error": str(e)[:100],
        }


def check_search_engines(
    max_workers: int = MAX_HEALTH_WORKERS,
    timeout_per_engine: float = SEARCH_ENGINE_TIMEOUT,
) -> List[Dict[str, Any]]:
    """
    Concurrently ping all search engines via Tor.
    
    Args:
        max_workers: Maximum concurrent workers
        timeout_per_engine: Timeout per engine in seconds
    
    Returns:
        List of per-engine status dicts
    """
    max_workers = max(1, min(max_workers, len(SEARCH_ENGINES), MAX_HEALTH_WORKERS))
    results = []
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_engine = {
            executor.submit(_ping_single_engine, eng, timeout_per_engine): eng
            for eng in SEARCH_ENGINES
        }
        for future in as_completed(future_to_engine):
            try:
                results.append(future.result(timeout=timeout_per_engine + 5))
            except FuturesTimeoutError:
                engine = future_to_engine[future]
                results.append({
                    "name": engine["name"],
                    "status": "down",
                    "latency_ms": None,
                    "error": f"Future timeout after {timeout_per_engine + 5}s",
                })
            except Exception as e:
                engine = future_to_engine[future]
                logger.debug(f"Search engine {engine['name']} future failed: {e}")
                results.append({
                    "name": engine["name"],
                    "status": "down",
                    "latency_ms": None,
                    "error": str(e)[:100],
                })
    
    # Sort by original engine order
    name_order = {e["name"]: i for i, e in enumerate(SEARCH_ENGINES)}
    results.sort(key=lambda r: name_order.get(r["name"], 999))
    return results


def check_all_health(model_choice: str) -> Dict[str, Any]:
    """
    Comprehensive health check for all components.
    
    Returns:
        Dict with tor, llm, and search engine statuses
    """
    tor_result = check_tor_proxy()
    llm_result = check_llm_health(model_choice)
    search_results = check_search_engines()
    
    up_count = sum(1 for r in search_results if r["status"] == "up")
    total = len(search_results)
    
    return {
        "tor": tor_result,
        "llm": llm_result,
        "search_engines": {
            "total": total,
            "up": up_count,
            "down": total - up_count,
            "engines": search_results,
        },
        "overall": "healthy" if (tor_result["status"] == "up" and llm_result["status"] == "up" and up_count > 0) else "degraded",
    }